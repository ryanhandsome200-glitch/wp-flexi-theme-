<?php
/**
 * Custom Widgets
 * 
 * @package FlexiPro
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Recent Posts Widget
class FlexiPro_Recent_Posts_Widget extends WP_Widget {
    
    public function __construct() {
        parent::__construct(
            'flexipro_recent_posts',
            __('FlexiPro Recent Posts', 'flexipro'),
            array('description' => __('Display recent posts with thumbnails', 'flexipro'))
        );
    }
    
    public function widget($args, $instance) {
        $title = apply_filters('widget_title', $instance['title']);
        $number = !empty($instance['number']) ? $instance['number'] : 5;
        $show_thumbnail = !empty($instance['show_thumbnail']) ? true : false;
        $show_date = !empty($instance['show_date']) ? true : false;
        $show_excerpt = !empty($instance['show_excerpt']) ? true : false;
        
        echo $args['before_widget'];
        
        if (!empty($title)) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
        
        $query_args = array(
            'post_type' => 'post',
            'posts_per_page' => $number,
            'post_status' => 'publish'
        );
        
        $recent_posts = new WP_Query($query_args);
        
        if ($recent_posts->have_posts()) {
            echo '<div class="flexipro-recent-posts">';
            while ($recent_posts->have_posts()) {
                $recent_posts->the_post();
                echo '<div class="recent-post-item">';
                
                if ($show_thumbnail && has_post_thumbnail()) {
                    echo '<div class="post-thumbnail">';
                    echo '<a href="' . get_permalink() . '">';
                    the_post_thumbnail('thumbnail');
                    echo '</a>';
                    echo '</div>';
                }
                
                echo '<div class="post-content">';
                echo '<h4 class="post-title"><a href="' . get_permalink() . '">' . get_the_title() . '</a></h4>';
                
                if ($show_date) {
                    echo '<span class="post-date">' . get_the_date() . '</span>';
                }
                
                if ($show_excerpt) {
                    echo '<div class="post-excerpt">' . wp_trim_words(get_the_excerpt(), 15) . '</div>';
                }
                
                echo '</div>';
                echo '</div>';
            }
            echo '</div>';
        }
        
        wp_reset_postdata();
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : '';
        $number = !empty($instance['number']) ? $instance['number'] : 5;
        $show_thumbnail = !empty($instance['show_thumbnail']) ? true : false;
        $show_date = !empty($instance['show_date']) ? true : false;
        $show_excerpt = !empty($instance['show_excerpt']) ? true : false;
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'flexipro'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('number'); ?>"><?php _e('Number of posts:', 'flexipro'); ?></label>
            <input class="tiny-text" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="number" value="<?php echo esc_attr($number); ?>" min="1" max="20">
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_thumbnail); ?> id="<?php echo $this->get_field_id('show_thumbnail'); ?>" name="<?php echo $this->get_field_name('show_thumbnail'); ?>">
            <label for="<?php echo $this->get_field_id('show_thumbnail'); ?>"><?php _e('Show thumbnail', 'flexipro'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_date); ?> id="<?php echo $this->get_field_id('show_date'); ?>" name="<?php echo $this->get_field_name('show_date'); ?>">
            <label for="<?php echo $this->get_field_id('show_date'); ?>"><?php _e('Show date', 'flexipro'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_excerpt); ?> id="<?php echo $this->get_field_id('show_excerpt'); ?>" name="<?php echo $this->get_field_name('show_excerpt'); ?>">
            <label for="<?php echo $this->get_field_id('show_excerpt'); ?>"><?php _e('Show excerpt', 'flexipro'); ?></label>
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        $instance['number'] = (!empty($new_instance['number'])) ? absint($new_instance['number']) : 5;
        $instance['show_thumbnail'] = !empty($new_instance['show_thumbnail']);
        $instance['show_date'] = !empty($new_instance['show_date']);
        $instance['show_excerpt'] = !empty($new_instance['show_excerpt']);
        return $instance;
    }
}

// Social Media Widget
class FlexiPro_Social_Media_Widget extends WP_Widget {
    
    public function __construct() {
        parent::__construct(
            'flexipro_social_media',
            __('FlexiPro Social Media', 'flexipro'),
            array('description' => __('Display social media links', 'flexipro'))
        );
    }
    
    public function widget($args, $instance) {
        $title = apply_filters('widget_title', $instance['title']);
        
        echo $args['before_widget'];
        
        if (!empty($title)) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
        
        $social_links = array(
            'facebook' => get_theme_mod('flexipro_facebook_url', ''),
            'twitter' => get_theme_mod('flexipro_twitter_url', ''),
            'instagram' => get_theme_mod('flexipro_instagram_url', ''),
            'linkedin' => get_theme_mod('flexipro_linkedin_url', ''),
            'youtube' => get_theme_mod('flexipro_youtube_url', ''),
            'pinterest' => get_theme_mod('flexipro_pinterest_url', ''),
        );
        
        echo '<div class="flexipro-social-media">';
        foreach ($social_links as $platform => $url) {
            if (!empty($url)) {
                echo '<a href="' . esc_url($url) . '" class="social-link social-' . $platform . '" target="_blank" rel="noopener">';
                echo '<i class="fab fa-' . $platform . '"></i>';
                echo '</a>';
            }
        }
        echo '</div>';
        
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : '';
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'flexipro'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p><?php _e('Social media URLs are configured in the Customizer under Social Media section.', 'flexipro'); ?></p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        return $instance;
    }
}

// Contact Info Widget
class FlexiPro_Contact_Info_Widget extends WP_Widget {
    
    public function __construct() {
        parent::__construct(
            'flexipro_contact_info',
            __('FlexiPro Contact Info', 'flexipro'),
            array('description' => __('Display contact information', 'flexipro'))
        );
    }
    
    public function widget($args, $instance) {
        $title = apply_filters('widget_title', $instance['title']);
        $address = !empty($instance['address']) ? $instance['address'] : '';
        $phone = !empty($instance['phone']) ? $instance['phone'] : '';
        $email = !empty($instance['email']) ? $instance['email'] : '';
        $hours = !empty($instance['hours']) ? $instance['hours'] : '';
        
        echo $args['before_widget'];
        
        if (!empty($title)) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
        
        echo '<div class="flexipro-contact-info">';
        
        if (!empty($address)) {
            echo '<div class="contact-item">';
            echo '<i class="fas fa-map-marker-alt"></i>';
            echo '<span>' . esc_html($address) . '</span>';
            echo '</div>';
        }
        
        if (!empty($phone)) {
            echo '<div class="contact-item">';
            echo '<i class="fas fa-phone"></i>';
            echo '<span><a href="tel:' . esc_attr($phone) . '">' . esc_html($phone) . '</a></span>';
            echo '</div>';
        }
        
        if (!empty($email)) {
            echo '<div class="contact-item">';
            echo '<i class="fas fa-envelope"></i>';
            echo '<span><a href="mailto:' . esc_attr($email) . '">' . esc_html($email) . '</a></span>';
            echo '</div>';
        }
        
        if (!empty($hours)) {
            echo '<div class="contact-item">';
            echo '<i class="fas fa-clock"></i>';
            echo '<span>' . esc_html($hours) . '</span>';
            echo '</div>';
        }
        
        echo '</div>';
        
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : '';
        $address = !empty($instance['address']) ? $instance['address'] : '';
        $phone = !empty($instance['phone']) ? $instance['phone'] : '';
        $email = !empty($instance['email']) ? $instance['email'] : '';
        $hours = !empty($instance['hours']) ? $instance['hours'] : '';
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'flexipro'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('address'); ?>"><?php _e('Address:', 'flexipro'); ?></label>
            <textarea class="widefat" id="<?php echo $this->get_field_id('address'); ?>" name="<?php echo $this->get_field_name('address'); ?>" rows="3"><?php echo esc_textarea($address); ?></textarea>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('phone'); ?>"><?php _e('Phone:', 'flexipro'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('phone'); ?>" name="<?php echo $this->get_field_name('phone'); ?>" type="text" value="<?php echo esc_attr($phone); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('email'); ?>"><?php _e('Email:', 'flexipro'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('email'); ?>" name="<?php echo $this->get_field_name('email'); ?>" type="email" value="<?php echo esc_attr($email); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('hours'); ?>"><?php _e('Business Hours:', 'flexipro'); ?></label>
            <textarea class="widefat" id="<?php echo $this->get_field_id('hours'); ?>" name="<?php echo $this->get_field_name('hours'); ?>" rows="3"><?php echo esc_textarea($hours); ?></textarea>
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        $instance['address'] = (!empty($new_instance['address'])) ? sanitize_textarea_field($new_instance['address']) : '';
        $instance['phone'] = (!empty($new_instance['phone'])) ? sanitize_text_field($new_instance['phone']) : '';
        $instance['email'] = (!empty($new_instance['email'])) ? sanitize_email($new_instance['email']) : '';
        $instance['hours'] = (!empty($new_instance['hours'])) ? sanitize_textarea_field($new_instance['hours']) : '';
        return $instance;
    }
}

// Newsletter Widget
class FlexiPro_Newsletter_Widget extends WP_Widget {
    
    public function __construct() {
        parent::__construct(
            'flexipro_newsletter',
            __('FlexiPro Newsletter', 'flexipro'),
            array('description' => __('Display newsletter signup form', 'flexipro'))
        );
    }
    
    public function widget($args, $instance) {
        $title = apply_filters('widget_title', $instance['title']);
        $description = !empty($instance['description']) ? $instance['description'] : '';
        $button_text = !empty($instance['button_text']) ? $instance['button_text'] : 'Subscribe';
        
        echo $args['before_widget'];
        
        if (!empty($title)) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
        
        if (!empty($description)) {
            echo '<p class="newsletter-description">' . esc_html($description) . '</p>';
        }
        
        echo '<form class="newsletter-form" method="post" action="">';
        echo '<div class="newsletter-input-group">';
        echo '<input type="email" name="newsletter_email" placeholder="' . __('Enter your email', 'flexipro') . '" required>';
        echo '<button type="submit" class="newsletter-button">' . esc_html($button_text) . '</button>';
        echo '</div>';
        echo '</form>';
        
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : '';
        $description = !empty($instance['description']) ? $instance['description'] : '';
        $button_text = !empty($instance['button_text']) ? $instance['button_text'] : 'Subscribe';
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'flexipro'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('description'); ?>"><?php _e('Description:', 'flexipro'); ?></label>
            <textarea class="widefat" id="<?php echo $this->get_field_id('description'); ?>" name="<?php echo $this->get_field_name('description'); ?>" rows="3"><?php echo esc_textarea($description); ?></textarea>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('button_text'); ?>"><?php _e('Button Text:', 'flexipro'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('button_text'); ?>" name="<?php echo $this->get_field_name('button_text'); ?>" type="text" value="<?php echo esc_attr($button_text); ?>">
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        $instance['description'] = (!empty($new_instance['description'])) ? sanitize_textarea_field($new_instance['description']) : '';
        $instance['button_text'] = (!empty($new_instance['button_text'])) ? sanitize_text_field($new_instance['button_text']) : 'Subscribe';
        return $instance;
    }
}

// Register Widgets
function flexipro_register_widgets() {
    register_widget('FlexiPro_Recent_Posts_Widget');
    register_widget('FlexiPro_Social_Media_Widget');
    register_widget('FlexiPro_Contact_Info_Widget');
    register_widget('FlexiPro_Newsletter_Widget');
}
add_action('widgets_init', 'flexipro_register_widgets');
