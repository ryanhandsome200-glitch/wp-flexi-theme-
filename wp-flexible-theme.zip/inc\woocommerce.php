<?php
/**
 * WooCommerce Integration
 * 
 * @package FlexiPro
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Check if WooCommerce is active
if (!class_exists('WooCommerce')) {
    return;
}

// WooCommerce theme support
function flexipro_woocommerce_support() {
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
}
add_action('after_setup_theme', 'flexipro_woocommerce_support');

// Remove WooCommerce default styles
add_filter('woocommerce_enqueue_styles', '__return_empty_array');

// Custom WooCommerce styles
function flexipro_woocommerce_styles() {
    wp_enqueue_style('flexipro-woocommerce', FLEXIPRO_THEME_URL . '/css/woocommerce.css', array(), FLEXIPRO_VERSION);
}
add_action('wp_enqueue_scripts', 'flexipro_woocommerce_styles');

// Customize WooCommerce wrapper
remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

add_action('woocommerce_before_main_content', 'flexipro_woocommerce_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'flexipro_woocommerce_wrapper_end', 10);

function flexipro_woocommerce_wrapper_start() {
    echo '<div class="container"><div class="woocommerce-wrapper">';
}

function flexipro_woocommerce_wrapper_end() {
    echo '</div></div>';
}

// Customize WooCommerce breadcrumbs
add_filter('woocommerce_breadcrumb_defaults', 'flexipro_woocommerce_breadcrumbs');
function flexipro_woocommerce_breadcrumbs($defaults) {
    $defaults['delimiter'] = ' <span class="breadcrumb-separator">/</span> ';
    $defaults['wrap_before'] = '<nav class="woocommerce-breadcrumb">';
    $defaults['wrap_after'] = '</nav>';
    return $defaults;
}

// Customize WooCommerce pagination
add_filter('woocommerce_pagination_args', 'flexipro_woocommerce_pagination');
function flexipro_woocommerce_pagination($args) {
    $args['prev_text'] = '<i class="fas fa-chevron-left"></i> ' . __('Previous', 'flexipro');
    $args['next_text'] = __('Next', 'flexipro') . ' <i class="fas fa-chevron-right"></i>';
    return $args;
}

// Customize WooCommerce product loop
add_action('woocommerce_before_shop_loop_item', 'flexipro_woocommerce_product_wrapper_start', 5);
add_action('woocommerce_after_shop_loop_item', 'flexipro_woocommerce_product_wrapper_end', 25);

function flexipro_woocommerce_product_wrapper_start() {
    echo '<div class="product-wrapper">';
}

function flexipro_woocommerce_product_wrapper_end() {
    echo '</div>';
}

// Add product quick view
add_action('woocommerce_after_shop_loop_item', 'flexipro_woocommerce_quick_view_button', 20);
function flexipro_woocommerce_quick_view_button() {
    global $product;
    echo '<a href="#" class="quick-view-btn" data-product-id="' . $product->get_id() . '">' . __('Quick View', 'flexipro') . '</a>';
}

// Customize WooCommerce checkout
add_filter('woocommerce_checkout_fields', 'flexipro_woocommerce_checkout_fields');
function flexipro_woocommerce_checkout_fields($fields) {
    // Customize billing fields
    $fields['billing']['billing_first_name']['placeholder'] = __('First Name', 'flexipro');
    $fields['billing']['billing_last_name']['placeholder'] = __('Last Name', 'flexipro');
    $fields['billing']['billing_email']['placeholder'] = __('Email Address', 'flexipro');
    $fields['billing']['billing_phone']['placeholder'] = __('Phone Number', 'flexipro');
    
    // Customize shipping fields
    $fields['shipping']['shipping_first_name']['placeholder'] = __('First Name', 'flexipro');
    $fields['shipping']['shipping_last_name']['placeholder'] = __('Last Name', 'flexipro');
    
    return $fields;
}

// Add custom WooCommerce widgets
function flexipro_woocommerce_widgets() {
    register_sidebar(array(
        'name'          => __('WooCommerce Sidebar', 'flexipro'),
        'id'            => 'woocommerce-sidebar',
        'description'   => __('Add widgets here for WooCommerce pages.', 'flexipro'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'flexipro_woocommerce_widgets');

// Customize WooCommerce messages
add_filter('woocommerce_add_to_cart_message', 'flexipro_woocommerce_add_to_cart_message');
function flexipro_woocommerce_add_to_cart_message($message) {
    return '<div class="woocommerce-message">' . $message . '</div>';
}

// Add product image zoom
add_action('wp_footer', 'flexipro_woocommerce_product_zoom');
function flexipro_woocommerce_product_zoom() {
    if (is_product()) {
        ?>
        <script>
        jQuery(document).ready(function($) {
            $('.woocommerce-product-gallery__image img').click(function() {
                $(this).toggleClass('zoomed');
            });
        });
        </script>
        <style>
        .woocommerce-product-gallery__image img.zoomed {
            transform: scale(2);
            cursor: zoom-out;
        }
        </style>
        <?php
    }
}

// Customize WooCommerce product tabs
add_filter('woocommerce_product_tabs', 'flexipro_woocommerce_product_tabs');
function flexipro_woocommerce_product_tabs($tabs) {
    // Rename tabs
    $tabs['description']['title'] = __('Product Description', 'flexipro');
    $tabs['reviews']['title'] = __('Customer Reviews', 'flexipro');
    
    // Add custom tab
    $tabs['shipping'] = array(
        'title'    => __('Shipping Info', 'flexipro'),
        'priority' => 25,
        'callback' => 'flexipro_woocommerce_shipping_tab'
    );
    
    return $tabs;
}

function flexipro_woocommerce_shipping_tab() {
    echo '<h3>' . __('Shipping Information', 'flexipro') . '</h3>';
    echo '<p>' . __('Free shipping on orders over $50. Standard shipping takes 3-5 business days.', 'flexipro') . '</p>';
}

// Add WooCommerce shortcodes
add_shortcode('flexipro_products', 'flexipro_products_shortcode');
function flexipro_products_shortcode($atts) {
    $atts = shortcode_atts(array(
        'limit' => '8',
        'columns' => '4',
        'orderby' => 'date',
        'order' => 'DESC',
        'category' => '',
        'featured' => 'false'
    ), $atts);
    
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => intval($atts['limit']),
        'orderby' => $atts['orderby'],
        'order' => $atts['order']
    );
    
    if ($atts['featured'] === 'true') {
        $args['meta_query'] = array(
            array(
                'key' => '_featured',
                'value' => 'yes'
            )
        );
    }
    
    if (!empty($atts['category'])) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'slug',
                'terms' => $atts['category']
            )
        );
    }
    
    $products = new WP_Query($args);
    
    ob_start();
    
    if ($products->have_posts()) {
        echo '<div class="flexipro-products columns-' . $atts['columns'] . '">';
        while ($products->have_posts()) {
            $products->the_post();
            wc_get_template_part('content', 'product');
        }
        echo '</div>';
    }
    
    wp_reset_postdata();
    
    return ob_get_clean();
}

// Add WooCommerce AJAX cart
add_action('wp_ajax_flexipro_add_to_cart', 'flexipro_ajax_add_to_cart');
add_action('wp_ajax_nopriv_flexipro_add_to_cart', 'flexipro_ajax_add_to_cart');

function flexipro_ajax_add_to_cart() {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);
    
    $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity);
    
    if ($cart_item_key) {
        wp_send_json_success(array(
            'message' => __('Product added to cart', 'flexipro'),
            'cart_count' => WC()->cart->get_cart_contents_count()
        ));
    } else {
        wp_send_json_error(array(
            'message' => __('Failed to add product to cart', 'flexipro')
        ));
    }
}

// Add WooCommerce mini cart
add_action('wp_footer', 'flexipro_woocommerce_mini_cart');
function flexipro_woocommerce_mini_cart() {
    ?>
    <div id="mini-cart" class="mini-cart">
        <div class="mini-cart-content">
            <h3><?php _e('Shopping Cart', 'flexipro'); ?></h3>
            <div class="mini-cart-items">
                <?php woocommerce_mini_cart(); ?>
            </div>
        </div>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('.cart-trigger').click(function(e) {
            e.preventDefault();
            $('#mini-cart').toggleClass('active');
        });
        
        $(document).click(function(e) {
            if (!$(e.target).closest('.cart-trigger, #mini-cart').length) {
                $('#mini-cart').removeClass('active');
            }
        });
    });
    </script>
    <?php
}
