<?php
/**
 * Advanced Page Builder - Similar to Avada Pro
 * 
 * @package FlexiPro
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class FlexiPro_Page_Builder {
    
    private $elements;
    private $sections;
    
    public function __construct() {
        $this->init_elements();
        $this->init_sections();
        add_action('add_meta_boxes', array($this, 'add_page_builder_meta_box'));
        add_action('save_post', array($this, 'save_page_builder_data'));
        add_action('wp_ajax_flexipro_save_element', array($this, 'ajax_save_element'));
        add_action('wp_ajax_flexipro_delete_element', array($this, 'ajax_delete_element'));
        add_action('wp_ajax_flexipro_duplicate_element', array($this, 'ajax_duplicate_element'));
        add_action('wp_ajax_flexipro_import_section', array($this, 'ajax_import_section'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    private function init_elements() {
        $this->elements = array(
            'text' => array(
                'name' => __('Text Block', 'flexipro'),
                'icon' => 'fas fa-font',
                'category' => 'content',
                'settings' => array(
                    'content' => array('type' => 'textarea', 'label' => 'Content'),
                    'text_align' => array('type' => 'select', 'label' => 'Text Align', 'options' => array('left' => 'Left', 'center' => 'Center', 'right' => 'Right')),
                    'font_size' => array('type' => 'number', 'label' => 'Font Size (px)'),
                    'font_weight' => array('type' => 'select', 'label' => 'Font Weight', 'options' => array('300' => 'Light', '400' => 'Normal', '500' => 'Medium', '600' => 'Semi Bold', '700' => 'Bold')),
                    'color' => array('type' => 'color', 'label' => 'Text Color'),
                    'margin' => array('type' => 'text', 'label' => 'Margin (CSS)'),
                    'padding' => array('type' => 'text', 'label' => 'Padding (CSS)')
                )
            ),
            'heading' => array(
                'name' => __('Heading', 'flexipro'),
                'icon' => 'fas fa-heading',
                'category' => 'content',
                'settings' => array(
                    'text' => array('type' => 'text', 'label' => 'Heading Text'),
                    'tag' => array('type' => 'select', 'label' => 'HTML Tag', 'options' => array('h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'h5' => 'H5', 'h6' => 'H6')),
                    'text_align' => array('type' => 'select', 'label' => 'Text Align', 'options' => array('left' => 'Left', 'center' => 'Center', 'right' => 'Right')),
                    'font_size' => array('type' => 'number', 'label' => 'Font Size (px)'),
                    'font_weight' => array('type' => 'select', 'label' => 'Font Weight', 'options' => array('300' => 'Light', '400' => 'Normal', '500' => 'Medium', '600' => 'Semi Bold', '700' => 'Bold')),
                    'color' => array('type' => 'color', 'label' => 'Text Color'),
                    'margin' => array('type' => 'text', 'label' => 'Margin (CSS)'),
                    'padding' => array('type' => 'text', 'label' => 'Padding (CSS)')
                )
            ),
            'image' => array(
                'name' => __('Image', 'flexipro'),
                'icon' => 'fas fa-image',
                'category' => 'media',
                'settings' => array(
                    'image_id' => array('type' => 'image', 'label' => 'Select Image'),
                    'alt_text' => array('type' => 'text', 'label' => 'Alt Text'),
                    'link_url' => array('type' => 'url', 'label' => 'Link URL'),
                    'link_target' => array('type' => 'select', 'label' => 'Link Target', 'options' => array('_self' => 'Same Window', '_blank' => 'New Window')),
                    'image_align' => array('type' => 'select', 'label' => 'Image Align', 'options' => array('left' => 'Left', 'center' => 'Center', 'right' => 'Right')),
                    'border_radius' => array('type' => 'number', 'label' => 'Border Radius (px)'),
                    'box_shadow' => array('type' => 'checkbox', 'label' => 'Enable Box Shadow'),
                    'hover_effect' => array('type' => 'select', 'label' => 'Hover Effect', 'options' => array('none' => 'None', 'zoom' => 'Zoom', 'fade' => 'Fade', 'slide' => 'Slide'))
                )
            ),
            'button' => array(
                'name' => __('Button', 'flexipro'),
                'icon' => 'fas fa-mouse-pointer',
                'category' => 'content',
                'settings' => array(
                    'text' => array('type' => 'text', 'label' => 'Button Text'),
                    'url' => array('type' => 'url', 'label' => 'Button URL'),
                    'target' => array('type' => 'select', 'label' => 'Link Target', 'options' => array('_self' => 'Same Window', '_blank' => 'New Window')),
                    'style' => array('type' => 'select', 'label' => 'Button Style', 'options' => array('primary' => 'Primary', 'secondary' => 'Secondary', 'outline' => 'Outline', 'ghost' => 'Ghost')),
                    'size' => array('type' => 'select', 'label' => 'Button Size', 'options' => array('small' => 'Small', 'medium' => 'Medium', 'large' => 'Large')),
                    'align' => array('type' => 'select', 'label' => 'Button Align', 'options' => array('left' => 'Left', 'center' => 'Center', 'right' => 'Right')),
                    'icon' => array('type' => 'text', 'label' => 'Icon Class (FontAwesome)'),
                    'icon_position' => array('type' => 'select', 'label' => 'Icon Position', 'options' => array('left' => 'Left', 'right' => 'Right')),
                    'animation' => array('type' => 'select', 'label' => 'Hover Animation', 'options' => array('none' => 'None', 'bounce' => 'Bounce', 'pulse' => 'Pulse', 'shake' => 'Shake'))
                )
            ),
            'spacer' => array(
                'name' => __('Spacer', 'flexipro'),
                'icon' => 'fas fa-arrows-alt-v',
                'category' => 'layout',
                'settings' => array(
                    'height' => array('type' => 'number', 'label' => 'Height (px)', 'default' => 50),
                    'background_color' => array('type' => 'color', 'label' => 'Background Color'),
                    'border' => array('type' => 'text', 'label' => 'Border (CSS)')
                )
            ),
            'video' => array(
                'name' => __('Video', 'flexipro'),
                'icon' => 'fas fa-video',
                'category' => 'media',
                'settings' => array(
                    'video_url' => array('type' => 'url', 'label' => 'Video URL (YouTube/Vimeo)'),
                    'poster_image' => array('type' => 'image', 'label' => 'Poster Image'),
                    'autoplay' => array('type' => 'checkbox', 'label' => 'Autoplay'),
                    'muted' => array('type' => 'checkbox', 'label' => 'Muted'),
                    'loop' => array('type' => 'checkbox', 'label' => 'Loop'),
                    'controls' => array('type' => 'checkbox', 'label' => 'Show Controls', 'default' => true),
                    'width' => array('type' => 'number', 'label' => 'Width (%)', 'default' => 100),
                    'height' => array('type' => 'number', 'label' => 'Height (px)', 'default' => 400)
                )
            ),
            'gallery' => array(
                'name' => __('Gallery', 'flexipro'),
                'icon' => 'fas fa-images',
                'category' => 'media',
                'settings' => array(
                    'images' => array('type' => 'gallery', 'label' => 'Select Images'),
                    'columns' => array('type' => 'select', 'label' => 'Columns', 'options' => array('2' => '2 Columns', '3' => '3 Columns', '4' => '4 Columns', '5' => '5 Columns')),
                    'gutter' => array('type' => 'number', 'label' => 'Gutter (px)', 'default' => 10),
                    'lightbox' => array('type' => 'checkbox', 'label' => 'Enable Lightbox'),
                    'hover_effect' => array('type' => 'select', 'label' => 'Hover Effect', 'options' => array('none' => 'None', 'zoom' => 'Zoom', 'fade' => 'Fade', 'slide' => 'Slide')),
                    'border_radius' => array('type' => 'number', 'label' => 'Border Radius (px)')
                )
            ),
            'testimonials' => array(
                'name' => __('Testimonials', 'flexipro'),
                'icon' => 'fas fa-quote-left',
                'category' => 'content',
                'settings' => array(
                    'testimonials' => array('type' => 'repeater', 'label' => 'Testimonials', 'fields' => array(
                        'name' => array('type' => 'text', 'label' => 'Name'),
                        'position' => array('type' => 'text', 'label' => 'Position'),
                        'company' => array('type' => 'text', 'label' => 'Company'),
                        'content' => array('type' => 'textarea', 'label' => 'Testimonial'),
                        'avatar' => array('type' => 'image', 'label' => 'Avatar'),
                        'rating' => array('type' => 'number', 'label' => 'Rating (1-5)')
                    )),
                    'layout' => array('type' => 'select', 'label' => 'Layout', 'options' => array('grid' => 'Grid', 'carousel' => 'Carousel', 'list' => 'List')),
                    'columns' => array('type' => 'select', 'label' => 'Columns', 'options' => array('1' => '1 Column', '2' => '2 Columns', '3' => '3 Columns')),
                    'autoplay' => array('type' => 'checkbox', 'label' => 'Autoplay (Carousel)'),
                    'show_rating' => array('type' => 'checkbox', 'label' => 'Show Star Rating'),
                    'show_avatar' => array('type' => 'checkbox', 'label' => 'Show Avatar')
                )
            ),
            'portfolio' => array(
                'name' => __('Portfolio Grid', 'flexipro'),
                'icon' => 'fas fa-th',
                'category' => 'content',
                'settings' => array(
                    'posts_per_page' => array('type' => 'number', 'label' => 'Posts Per Page', 'default' => 6),
                    'columns' => array('type' => 'select', 'label' => 'Columns', 'options' => array('2' => '2 Columns', '3' => '3 Columns', '4' => '4 Columns')),
                    'filter' => array('type' => 'checkbox', 'label' => 'Enable Filter'),
                    'lightbox' => array('type' => 'checkbox', 'label' => 'Enable Lightbox'),
                    'hover_effect' => array('type' => 'select', 'label' => 'Hover Effect', 'options' => array('none' => 'None', 'zoom' => 'Zoom', 'fade' => 'Fade', 'slide' => 'Slide')),
                    'show_title' => array('type' => 'checkbox', 'label' => 'Show Title'),
                    'show_excerpt' => array('type' => 'checkbox', 'label' => 'Show Excerpt'),
                    'show_categories' => array('type' => 'checkbox', 'label' => 'Show Categories')
                )
            ),
            'blog' => array(
                'name' => __('Blog Grid', 'flexipro'),
                'icon' => 'fas fa-blog',
                'category' => 'content',
                'settings' => array(
                    'posts_per_page' => array('type' => 'number', 'label' => 'Posts Per Page', 'default' => 6),
                    'columns' => array('type' => 'select', 'label' => 'Columns', 'options' => array('1' => '1 Column', '2' => '2 Columns', '3' => '3 Columns')),
                    'layout' => array('type' => 'select', 'label' => 'Layout', 'options' => array('grid' => 'Grid', 'list' => 'List', 'masonry' => 'Masonry')),
                    'show_meta' => array('type' => 'checkbox', 'label' => 'Show Meta'),
                    'show_excerpt' => array('type' => 'checkbox', 'label' => 'Show Excerpt'),
                    'excerpt_length' => array('type' => 'number', 'label' => 'Excerpt Length', 'default' => 55),
                    'show_read_more' => array('type' => 'checkbox', 'label' => 'Show Read More'),
                    'read_more_text' => array('type' => 'text', 'label' => 'Read More Text', 'default' => 'Read More')
                )
            ),
            'contact_form' => array(
                'name' => __('Contact Form', 'flexipro'),
                'icon' => 'fas fa-envelope',
                'category' => 'forms',
                'settings' => array(
                    'form_title' => array('type' => 'text', 'label' => 'Form Title'),
                    'form_description' => array('type' => 'textarea', 'label' => 'Form Description'),
                    'fields' => array('type' => 'repeater', 'label' => 'Form Fields', 'fields' => array(
                        'type' => array('type' => 'select', 'label' => 'Field Type', 'options' => array('text' => 'Text', 'email' => 'Email', 'tel' => 'Phone', 'textarea' => 'Textarea', 'select' => 'Select')),
                        'name' => array('type' => 'text', 'label' => 'Field Name'),
                        'label' => array('type' => 'text', 'label' => 'Field Label'),
                        'required' => array('type' => 'checkbox', 'label' => 'Required'),
                        'placeholder' => array('type' => 'text', 'label' => 'Placeholder')
                    )),
                    'submit_text' => array('type' => 'text', 'label' => 'Submit Button Text', 'default' => 'Send Message'),
                    'success_message' => array('type' => 'text', 'label' => 'Success Message', 'default' => 'Thank you! Your message has been sent.'),
                    'email_to' => array('type' => 'email', 'label' => 'Email To'),
                    'email_subject' => array('type' => 'text', 'label' => 'Email Subject')
                )
            ),
            'map' => array(
                'name' => __('Google Map', 'flexipro'),
                'icon' => 'fas fa-map-marker-alt',
                'category' => 'media',
                'settings' => array(
                    'address' => array('type' => 'text', 'label' => 'Address'),
                    'latitude' => array('type' => 'text', 'label' => 'Latitude'),
                    'longitude' => array('type' => 'text', 'label' => 'Longitude'),
                    'zoom' => array('type' => 'number', 'label' => 'Zoom Level', 'default' => 15),
                    'height' => array('type' => 'number', 'label' => 'Height (px)', 'default' => 400),
                    'marker_text' => array('type' => 'text', 'label' => 'Marker Text'),
                    'map_style' => array('type' => 'select', 'label' => 'Map Style', 'options' => array('default' => 'Default', 'satellite' => 'Satellite', 'terrain' => 'Terrain', 'hybrid' => 'Hybrid'))
                )
            ),
            'counter' => array(
                'name' => __('Counter', 'flexipro'),
                'icon' => 'fas fa-calculator',
                'category' => 'content',
                'settings' => array(
                    'counters' => array('type' => 'repeater', 'label' => 'Counters', 'fields' => array(
                        'number' => array('type' => 'number', 'label' => 'Number'),
                        'label' => array('type' => 'text', 'label' => 'Label'),
                        'icon' => array('type' => 'text', 'label' => 'Icon Class'),
                        'color' => array('type' => 'color', 'label' => 'Color')
                    )),
                    'columns' => array('type' => 'select', 'label' => 'Columns', 'options' => array('2' => '2 Columns', '3' => '3 Columns', '4' => '4 Columns')),
                    'animation' => array('type' => 'checkbox', 'label' => 'Enable Animation'),
                    'animation_duration' => array('type' => 'number', 'label' => 'Animation Duration (ms)', 'default' => 2000)
                )
            ),
            'accordion' => array(
                'name' => __('Accordion', 'flexipro'),
                'icon' => 'fas fa-list',
                'category' => 'content',
                'settings' => array(
                    'items' => array('type' => 'repeater', 'label' => 'Accordion Items', 'fields' => array(
                        'title' => array('type' => 'text', 'label' => 'Title'),
                        'content' => array('type' => 'textarea', 'label' => 'Content'),
                        'icon' => array('type' => 'text', 'label' => 'Icon Class')
                    )),
                    'style' => array('type' => 'select', 'label' => 'Style', 'options' => array('default' => 'Default', 'minimal' => 'Minimal', 'boxed' => 'Boxed')),
                    'multiple_open' => array('type' => 'checkbox', 'label' => 'Allow Multiple Open'),
                    'animation' => array('type' => 'select', 'label' => 'Animation', 'options' => array('slide' => 'Slide', 'fade' => 'Fade'))
                )
            ),
            'tabs' => array(
                'name' => __('Tabs', 'flexipro'),
                'icon' => 'fas fa-folder',
                'category' => 'content',
                'settings' => array(
                    'tabs' => array('type' => 'repeater', 'label' => 'Tabs', 'fields' => array(
                        'title' => array('type' => 'text', 'label' => 'Tab Title'),
                        'content' => array('type' => 'textarea', 'label' => 'Tab Content'),
                        'icon' => array('type' => 'text', 'label' => 'Icon Class')
                    )),
                    'style' => array('type' => 'select', 'label' => 'Style', 'options' => array('default' => 'Default', 'minimal' => 'Minimal', 'boxed' => 'Boxed')),
                    'position' => array('type' => 'select', 'label' => 'Tab Position', 'options' => array('top' => 'Top', 'left' => 'Left', 'right' => 'Right')),
                    'animation' => array('type' => 'select', 'label' => 'Animation', 'options' => array('slide' => 'Slide', 'fade' => 'Fade'))
                )
            ),
            'pricing_table' => array(
                'name' => __('Pricing Table', 'flexipro'),
                'icon' => 'fas fa-dollar-sign',
                'category' => 'content',
                'settings' => array(
                    'plans' => array('type' => 'repeater', 'label' => 'Pricing Plans', 'fields' => array(
                        'name' => array('type' => 'text', 'label' => 'Plan Name'),
                        'price' => array('type' => 'text', 'label' => 'Price'),
                        'period' => array('type' => 'text', 'label' => 'Period'),
                        'features' => array('type' => 'textarea', 'label' => 'Features (one per line)'),
                        'button_text' => array('type' => 'text', 'label' => 'Button Text'),
                        'button_url' => array('type' => 'url', 'label' => 'Button URL'),
                        'featured' => array('type' => 'checkbox', 'label' => 'Featured Plan'),
                        'color' => array('type' => 'color', 'label' => 'Plan Color')
                    )),
                    'columns' => array('type' => 'select', 'label' => 'Columns', 'options' => array('2' => '2 Columns', '3' => '3 Columns', '4' => '4 Columns')),
                    'style' => array('type' => 'select', 'label' => 'Style', 'options' => array('default' => 'Default', 'minimal' => 'Minimal', 'boxed' => 'Boxed'))
                )
            )
        );
    }
    
    private function init_sections() {
        $this->sections = array(
            'hero' => array(
                'name' => __('Hero Section', 'flexipro'),
                'icon' => 'fas fa-star',
                'settings' => array(
                    'background_type' => array('type' => 'select', 'label' => 'Background Type', 'options' => array('color' => 'Color', 'image' => 'Image', 'video' => 'Video')),
                    'background_color' => array('type' => 'color', 'label' => 'Background Color'),
                    'background_image' => array('type' => 'image', 'label' => 'Background Image'),
                    'background_video' => array('type' => 'url', 'label' => 'Background Video URL'),
                    'overlay' => array('type' => 'checkbox', 'label' => 'Enable Overlay'),
                    'overlay_color' => array('type' => 'color', 'label' => 'Overlay Color'),
                    'overlay_opacity' => array('type' => 'number', 'label' => 'Overlay Opacity', 'default' => 50),
                    'height' => array('type' => 'select', 'label' => 'Section Height', 'options' => array('auto' => 'Auto', 'full' => 'Full Height', 'custom' => 'Custom')),
                    'custom_height' => array('type' => 'number', 'label' => 'Custom Height (px)'),
                    'content_align' => array('type' => 'select', 'label' => 'Content Alignment', 'options' => array('left' => 'Left', 'center' => 'Center', 'right' => 'Right')),
                    'padding_top' => array('type' => 'number', 'label' => 'Padding Top (px)'),
                    'padding_bottom' => array('type' => 'number', 'label' => 'Padding Bottom (px)')
                )
            ),
            'content' => array(
                'name' => __('Content Section', 'flexipro'),
                'icon' => 'fas fa-align-left',
                'settings' => array(
                    'background_color' => array('type' => 'color', 'label' => 'Background Color'),
                    'text_color' => array('type' => 'color', 'label' => 'Text Color'),
                    'padding_top' => array('type' => 'number', 'label' => 'Padding Top (px)'),
                    'padding_bottom' => array('type' => 'number', 'label' => 'Padding Bottom (px)'),
                    'margin_top' => array('type' => 'number', 'label' => 'Margin Top (px)'),
                    'margin_bottom' => array('type' => 'number', 'label' => 'Margin Bottom (px)')
                )
            ),
            'parallax' => array(
                'name' => __('Parallax Section', 'flexipro'),
                'icon' => 'fas fa-mountain',
                'settings' => array(
                    'background_image' => array('type' => 'image', 'label' => 'Background Image'),
                    'parallax_speed' => array('type' => 'number', 'label' => 'Parallax Speed', 'default' => 0.5),
                    'overlay' => array('type' => 'checkbox', 'label' => 'Enable Overlay'),
                    'overlay_color' => array('type' => 'color', 'label' => 'Overlay Color'),
                    'overlay_opacity' => array('type' => 'number', 'label' => 'Overlay Opacity', 'default' => 50),
                    'height' => array('type' => 'select', 'label' => 'Section Height', 'options' => array('auto' => 'Auto', 'full' => 'Full Height', 'custom' => 'Custom')),
                    'custom_height' => array('type' => 'number', 'label' => 'Custom Height (px)')
                )
            )
        );
    }
    
    public function add_page_builder_meta_box() {
        add_meta_box(
            'flexipro-page-builder',
            __('FlexiPro Page Builder', 'flexipro'),
            array($this, 'page_builder_meta_box_callback'),
            array('page', 'post'),
            'normal',
            'high'
        );
    }
    
    public function page_builder_meta_box_callback($post) {
        wp_nonce_field('flexipro_page_builder_nonce', 'flexipro_page_builder_nonce');
        $page_builder_data = get_post_meta($post->ID, '_flexipro_page_builder', true);
        ?>
        <div id="flexipro-page-builder" class="flexipro-builder">
            <div class="flexipro-builder-header">
                <div class="flexipro-builder-tabs">
                    <button type="button" class="flexipro-tab active" data-tab="elements">Elements</button>
                    <button type="button" class="flexipro-tab" data-tab="sections">Sections</button>
                    <button type="button" class="flexipro-tab" data-tab="templates">Templates</button>
                </div>
                <div class="flexipro-builder-actions">
                    <button type="button" class="button button-primary" id="flexipro-save-page">Save Page</button>
                    <button type="button" class="button" id="flexipro-preview-page">Preview</button>
                </div>
            </div>
            
            <div class="flexipro-builder-content">
                <div class="flexipro-builder-sidebar">
                    <div id="flexipro-elements-tab" class="flexipro-tab-content active">
                        <h3>Elements</h3>
                        <div class="flexipro-elements-grid">
                            <?php foreach ($this->elements as $key => $element) : ?>
                                <div class="flexipro-element-item" data-element="<?php echo $key; ?>">
                                    <i class="<?php echo $element['icon']; ?>"></i>
                                    <span><?php echo $element['name']; ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <div id="flexipro-sections-tab" class="flexipro-tab-content">
                        <h3>Sections</h3>
                        <div class="flexipro-sections-grid">
                            <?php foreach ($this->sections as $key => $section) : ?>
                                <div class="flexipro-section-item" data-section="<?php echo $key; ?>">
                                    <i class="<?php echo $section['icon']; ?>"></i>
                                    <span><?php echo $section['name']; ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <div id="flexipro-templates-tab" class="flexipro-tab-content">
                        <h3>Templates</h3>
                        <div class="flexipro-templates-grid">
                            <div class="flexipro-template-item" data-template="hero-about">
                                <img src="<?php echo FLEXIPRO_THEME_URL; ?>/admin/images/templates/hero-about.jpg" alt="Hero About">
                                <span>Hero About</span>
                            </div>
                            <div class="flexipro-template-item" data-template="services">
                                <img src="<?php echo FLEXIPRO_THEME_URL; ?>/admin/images/templates/services.jpg" alt="Services">
                                <span>Services</span>
                            </div>
                            <div class="flexipro-template-item" data-template="portfolio">
                                <img src="<?php echo FLEXIPRO_THEME_URL; ?>/admin/images/templates/portfolio.jpg" alt="Portfolio">
                                <span>Portfolio</span>
                            </div>
                            <div class="flexipro-template-item" data-template="contact">
                                <img src="<?php echo FLEXIPRO_THEME_URL; ?>/admin/images/templates/contact.jpg" alt="Contact">
                                <span>Contact</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flexipro-builder-canvas">
                    <div id="flexipro-sections-container">
                        <?php
                        if ($page_builder_data) {
                            echo $this->render_page_builder_data($page_builder_data);
                        } else {
                            echo '<div class="flexipro-empty-state">
                                <i class="fas fa-plus-circle"></i>
                                <h3>Start Building Your Page</h3>
                                <p>Choose an element or section from the sidebar to begin</p>
                            </div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
            
            <textarea name="flexipro_page_builder_data" id="flexipro_page_builder_data" style="display: none;"><?php echo esc_textarea($page_builder_data); ?></textarea>
        </div>
        
        <style>
        .flexipro-builder {
            background: #f1f1f1;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            margin: 20px 0;
        }
        .flexipro-builder-header {
            background: #fff;
            border-bottom: 1px solid #ccd0d4;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .flexipro-builder-tabs {
            display: flex;
            gap: 10px;
        }
        .flexipro-tab {
            padding: 8px 16px;
            border: 1px solid #ccd0d4;
            background: #f1f1f1;
            cursor: pointer;
            border-radius: 4px;
        }
        .flexipro-tab.active {
            background: #0073aa;
            color: #fff;
            border-color: #0073aa;
        }
        .flexipro-builder-content {
            display: flex;
            min-height: 600px;
        }
        .flexipro-builder-sidebar {
            width: 300px;
            background: #fff;
            border-right: 1px solid #ccd0d4;
            padding: 20px;
            overflow-y: auto;
        }
        .flexipro-tab-content {
            display: none;
        }
        .flexipro-tab-content.active {
            display: block;
        }
        .flexipro-elements-grid,
        .flexipro-sections-grid,
        .flexipro-templates-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }
        .flexipro-element-item,
        .flexipro-section-item,
        .flexipro-template-item {
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .flexipro-element-item:hover,
        .flexipro-section-item:hover,
        .flexipro-template-item:hover {
            border-color: #0073aa;
            background: #f0f8ff;
        }
        .flexipro-element-item i,
        .flexipro-section-item i {
            font-size: 24px;
            color: #0073aa;
            display: block;
            margin-bottom: 8px;
        }
        .flexipro-template-item img {
            width: 100%;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
            margin-bottom: 8px;
        }
        .flexipro-builder-canvas {
            flex: 1;
            padding: 20px;
            background: #fff;
        }
        .flexipro-empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }
        .flexipro-empty-state i {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 20px;
        }
        .flexipro-section {
            border: 2px dashed #ddd;
            margin-bottom: 20px;
            padding: 20px;
            border-radius: 4px;
            position: relative;
        }
        .flexipro-section:hover {
            border-color: #0073aa;
        }
        .flexipro-section-controls {
            position: absolute;
            top: -10px;
            right: -10px;
            display: none;
        }
        .flexipro-section:hover .flexipro-section-controls {
            display: block;
        }
        .flexipro-element {
            border: 1px dashed #ddd;
            margin: 10px 0;
            padding: 15px;
            border-radius: 4px;
            position: relative;
        }
        .flexipro-element:hover {
            border-color: #0073aa;
        }
        .flexipro-element-controls {
            position: absolute;
            top: -10px;
            right: -10px;
            display: none;
        }
        .flexipro-element:hover .flexipro-element-controls {
            display: block;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            // Tab switching
            $('.flexipro-tab').click(function() {
                var tab = $(this).data('tab');
                $('.flexipro-tab').removeClass('active');
                $(this).addClass('active');
                $('.flexipro-tab-content').removeClass('active');
                $('#flexipro-' + tab + '-tab').addClass('active');
            });
            
            // Element drag and drop
            $('.flexipro-element-item').draggable({
                helper: 'clone',
                revert: 'invalid',
                cursor: 'move'
            });
            
            $('.flexipro-builder-canvas').droppable({
                accept: '.flexipro-element-item',
                drop: function(event, ui) {
                    var element = ui.draggable.data('element');
                    addElement(element);
                }
            });
            
            // Section drag and drop
            $('.flexipro-section-item').draggable({
                helper: 'clone',
                revert: 'invalid',
                cursor: 'move'
            });
            
            $('.flexipro-builder-canvas').droppable({
                accept: '.flexipro-section-item',
                drop: function(event, ui) {
                    var section = ui.draggable.data('section');
                    addSection(section);
                }
            });
            
            // Template import
            $('.flexipro-template-item').click(function() {
                var template = $(this).data('template');
                importTemplate(template);
            });
            
            function addElement(elementType) {
                var elementId = 'element_' + Date.now();
                var elementData = {
                    id: elementId,
                    type: elementType,
                    settings: {}
                };
                
                // Set default settings
                if (flexipro_elements[elementType]) {
                    var settings = flexipro_elements[elementType].settings;
                    for (var key in settings) {
                        if (settings[key].default !== undefined) {
                            elementData.settings[key] = settings[key].default;
                        }
                    }
                }
                
                var elementHtml = renderElement(elementData);
                $('#flexipro-sections-container').append(elementHtml);
                updatePageBuilderData();
            }
            
            function addSection(sectionType) {
                var sectionId = 'section_' + Date.now();
                var sectionData = {
                    id: sectionId,
                    type: sectionType,
                    settings: {},
                    elements: []
                };
                
                // Set default settings
                if (flexipro_sections[sectionType]) {
                    var settings = flexipro_sections[sectionType].settings;
                    for (var key in settings) {
                        if (settings[key].default !== undefined) {
                            sectionData.settings[key] = settings[key].default;
                        }
                    }
                }
                
                var sectionHtml = renderSection(sectionData);
                $('#flexipro-sections-container').append(sectionHtml);
                updatePageBuilderData();
            }
            
            function renderElement(elementData) {
                var element = flexipro_elements[elementData.type];
                if (!element) return '';
                
                var html = '<div class="flexipro-element" data-id="' + elementData.id + '">';
                html += '<div class="flexipro-element-content">';
                
                switch (elementData.type) {
                    case 'text':
                        html += '<p>' + (elementData.settings.content || 'Text content') + '</p>';
                        break;
                    case 'heading':
                        var tag = elementData.settings.tag || 'h2';
                        html += '<' + tag + '>' + (elementData.settings.text || 'Heading') + '</' + tag + '>';
                        break;
                    case 'image':
                        if (elementData.settings.image_id) {
                            html += '<img src="' + elementData.settings.image_url + '" alt="' + (elementData.settings.alt_text || '') + '">';
                        } else {
                            html += '<div class="flexipro-placeholder-image">Click to add image</div>';
                        }
                        break;
                    case 'button':
                        var style = elementData.settings.style || 'primary';
                        html += '<a href="' + (elementData.settings.url || '#') + '" class="btn btn-' + style + '">' + (elementData.settings.text || 'Button') + '</a>';
                        break;
                    case 'spacer':
                        var height = elementData.settings.height || 50;
                        html += '<div style="height: ' + height + 'px; background: #f0f0f0; border: 1px dashed #ccc;"></div>';
                        break;
                    case 'video':
                        if (elementData.settings.video_url) {
                            html += '<div class="flexipro-video-placeholder">Video: ' + elementData.settings.video_url + '</div>';
                        } else {
                            html += '<div class="flexipro-placeholder-video">Click to add video</div>';
                        }
                        break;
                }
                
                html += '</div>';
                html += '<div class="flexipro-element-controls">';
                html += '<button type="button" class="button button-small edit-element" data-id="' + elementData.id + '">Edit</button>';
                html += '<button type="button" class="button button-small delete-element" data-id="' + elementData.id + '">Delete</button>';
                html += '<button type="button" class="button button-small duplicate-element" data-id="' + elementData.id + '">Duplicate</button>';
                html += '</div>';
                html += '</div>';
                
                return html;
            }
            
            function renderSection(sectionData) {
                var section = flexipro_sections[sectionData.type];
                if (!section) return '';
                
                var html = '<div class="flexipro-section" data-id="' + sectionData.id + '">';
                html += '<div class="flexipro-section-header">';
                html += '<h4>' + section.name + '</h4>';
                html += '<div class="flexipro-section-controls">';
                html += '<button type="button" class="button button-small edit-section" data-id="' + sectionData.id + '">Edit</button>';
                html += '<button type="button" class="button button-small delete-section" data-id="' + sectionData.id + '">Delete</button>';
                html += '<button type="button" class="button button-small add-element" data-section="' + sectionData.id + '">Add Element</button>';
                html += '</div>';
                html += '</div>';
                html += '<div class="flexipro-section-content">';
                html += '<div class="flexipro-section-placeholder">Drop elements here</div>';
                html += '</div>';
                html += '</div>';
                
                return html;
            }
            
            function updatePageBuilderData() {
                var data = [];
                $('#flexipro-sections-container .flexipro-section').each(function() {
                    var sectionId = $(this).data('id');
                    var sectionData = {
                        id: sectionId,
                        type: 'content', // Default section type
                        settings: {},
                        elements: []
                    };
                    
                    $(this).find('.flexipro-element').each(function() {
                        var elementId = $(this).data('id');
                        var elementData = {
                            id: elementId,
                            type: 'text', // This would be determined from the element
                            settings: {}
                        };
                        sectionData.elements.push(elementData);
                    });
                    
                    data.push(sectionData);
                });
                
                $('#flexipro_page_builder_data').val(JSON.stringify(data));
            }
            
            // Element controls
            $(document).on('click', '.edit-element', function() {
                var elementId = $(this).data('id');
                openElementSettings(elementId);
            });
            
            $(document).on('click', '.delete-element', function() {
                if (confirm('Are you sure you want to delete this element?')) {
                    $(this).closest('.flexipro-element').remove();
                    updatePageBuilderData();
                }
            });
            
            $(document).on('click', '.duplicate-element', function() {
                var element = $(this).closest('.flexipro-element');
                var cloned = element.clone();
                cloned.attr('data-id', 'element_' + Date.now());
                element.after(cloned);
                updatePageBuilderData();
            });
            
            function openElementSettings(elementId) {
                // This would open a modal with element settings
                alert('Element settings for: ' + elementId);
            }
            
            // Save page
            $('#flexipro-save-page').click(function() {
                updatePageBuilderData();
                $('#post').submit();
            });
            
            // Preview page
            $('#flexipro-preview-page').click(function() {
                var previewUrl = '<?php echo get_preview_post_link(); ?>';
                window.open(previewUrl, '_blank');
            });
        });
        
        // Make elements and sections available to JavaScript
        var flexipro_elements = <?php echo json_encode($this->elements); ?>;
        var flexipro_sections = <?php echo json_encode($this->sections); ?>;
        </script>
        <?php
    }
    
    public function save_page_builder_data($post_id) {
        if (!isset($_POST['flexipro_page_builder_nonce']) || !wp_verify_nonce($_POST['flexipro_page_builder_nonce'], 'flexipro_page_builder_nonce')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (isset($_POST['flexipro_page_builder_data'])) {
            update_post_meta($post_id, '_flexipro_page_builder', $_POST['flexipro_page_builder_data']);
        }
    }
    
    public function ajax_save_element() {
        check_ajax_referer('flexipro_nonce', 'nonce');
        
        $element_data = $_POST['element_data'];
        $element_html = $this->render_element($element_data);
        
        wp_send_json_success(array('html' => $element_html));
    }
    
    public function ajax_delete_element() {
        check_ajax_referer('flexipro_nonce', 'nonce');
        wp_send_json_success();
    }
    
    public function ajax_duplicate_element() {
        check_ajax_referer('flexipro_nonce', 'nonce');
        wp_send_json_success();
    }
    
    public function ajax_import_section() {
        check_ajax_referer('flexipro_nonce', 'nonce');
        
        $template = $_POST['template'];
        $template_data = $this->get_template_data($template);
        
        wp_send_json_success(array('data' => $template_data));
    }
    
    private function get_template_data($template) {
        $templates = array(
            'hero-about' => array(
                'type' => 'hero',
                'settings' => array(
                    'background_type' => 'image',
                    'background_image' => FLEXIPRO_THEME_URL . '/admin/images/hero-bg.jpg',
                    'overlay' => true,
                    'overlay_color' => '#000000',
                    'overlay_opacity' => 50,
                    'height' => 'full',
                    'content_align' => 'center'
                ),
                'elements' => array(
                    array(
                        'type' => 'heading',
                        'settings' => array(
                            'text' => 'About Our Company',
                            'tag' => 'h1',
                            'text_align' => 'center',
                            'color' => '#ffffff'
                        )
                    ),
                    array(
                        'type' => 'text',
                        'settings' => array(
                            'content' => 'We are a creative agency focused on delivering exceptional digital experiences.',
                            'text_align' => 'center',
                            'color' => '#ffffff'
                        )
                    ),
                    array(
                        'type' => 'button',
                        'settings' => array(
                            'text' => 'Learn More',
                            'url' => '#about',
                            'style' => 'primary',
                            'align' => 'center'
                        )
                    )
                )
            )
        );
        
        return isset($templates[$template]) ? $templates[$template] : array();
    }
    
    private function render_page_builder_data($data) {
        if (empty($data)) {
            return '';
        }
        
        $html = '';
        $sections = json_decode($data, true);
        
        if (is_array($sections)) {
            foreach ($sections as $section) {
                $html .= $this->render_section($section);
            }
        }
        
        return $html;
    }
    
    private function render_section($section_data) {
        $html = '<div class="flexipro-section" data-id="' . esc_attr($section_data['id']) . '">';
        $html .= '<div class="flexipro-section-content">';
        
        if (isset($section_data['elements']) && is_array($section_data['elements'])) {
            foreach ($section_data['elements'] as $element) {
                $html .= $this->render_element($element);
            }
        }
        
        $html .= '</div>';
        $html .= '</div>';
        
        return $html;
    }
    
    private function render_element($element_data) {
        $element_type = $element_data['type'];
        $element_settings = $element_data['settings'];
        
        ob_start();
        
        switch ($element_type) {
            case 'text':
                echo '<div class="flexipro-text-element">';
                echo '<div class="element-content">' . wp_kses_post($element_settings['content']) . '</div>';
                echo '</div>';
                break;
                
            case 'heading':
                $tag = isset($element_settings['tag']) ? $element_settings['tag'] : 'h2';
                echo '<div class="flexipro-heading-element">';
                echo '<' . esc_attr($tag) . '>' . esc_html($element_settings['text']) . '</' . esc_attr($tag) . '>';
                echo '</div>';
                break;
                
            case 'image':
                echo '<div class="flexipro-image-element">';
                if (!empty($element_settings['image_id'])) {
                    echo wp_get_attachment_image($element_settings['image_id'], 'full');
                }
                echo '</div>';
                break;
                
            case 'button':
                echo '<div class="flexipro-button-element">';
                $style = isset($element_settings['style']) ? $element_settings['style'] : 'primary';
                echo '<a href="' . esc_url($element_settings['url']) . '" class="btn btn-' . esc_attr($style) . '">' . esc_html($element_settings['text']) . '</a>';
                echo '</div>';
                break;
                
            case 'spacer':
                $height = isset($element_settings['height']) ? $element_settings['height'] : 50;
                echo '<div class="flexipro-spacer-element" style="height: ' . esc_attr($height) . 'px;"></div>';
                break;
                
            case 'video':
                echo '<div class="flexipro-video-element">';
                if (!empty($element_settings['video_url'])) {
                    echo '<iframe src="' . esc_url($element_settings['video_url']) . '" width="100%" height="400" frameborder="0" allowfullscreen></iframe>';
                }
                echo '</div>';
                break;
        }
        
        return ob_get_clean();
    }
    
    public function enqueue_scripts() {
        if (is_admin()) {
            wp_enqueue_script('jquery-ui-draggable');
            wp_enqueue_script('jquery-ui-droppable');
            wp_enqueue_script('jquery-ui-sortable');
        }
    }
}

// Initialize page builder
new FlexiPro_Page_Builder();
