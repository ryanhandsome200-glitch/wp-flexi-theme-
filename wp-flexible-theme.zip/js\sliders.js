/*
 * FlexiPro Theme - Universal Slider JavaScript
 * Compatible with all popular WordPress slider plugins
 */

(function($) {
    'use strict';
    
    var FlexiProSliders = {
        
        init: function() {
            this.initRevolutionSlider();
            this.initSmartSlider3();
            this.initMetaSlider();
            this.initOwlCarousel();
            this.initSwiperSlider();
            this.initFlexslider();
            this.initNivoSlider();
            this.initCustomSliders();
            this.bindEvents();
        },
        
        initRevolutionSlider: function() {
            if (typeof window.revslider_showDoubleJqueryError === 'undefined') {
                window.revslider_showDoubleJqueryError = function() {
                    console.log('Revolution Slider: jQuery conflict detected');
                };
            }
            
            // Initialize Revolution Slider if available
            if (typeof window.revapi !== 'undefined') {
                $('.rev_slider_wrapper').each(function() {
                    var $slider = $(this);
                    var sliderId = $slider.attr('id');
                    
                    if (sliderId && window.revapi[sliderId]) {
                        window.revapi[sliderId].on('revolution.slide.onloaded', function() {
                            FlexiProSliders.enhanceSliderContent($slider);
                        });
                    }
                });
            }
        },
        
        initSmartSlider3: function() {
            // Initialize Smart Slider 3 if available
            if (typeof window.N2 !== 'undefined' && window.N2.ready) {
                window.N2.ready(function() {
                    $('.smartslider3').each(function() {
                        FlexiProSliders.enhanceSliderContent($(this));
                    });
                });
            }
        },
        
        initMetaSlider: function() {
            // Initialize Meta Slider if available
            $('.metaslider').each(function() {
                var $slider = $(this);
                FlexiProSliders.enhanceSliderContent($slider);
                
                // Add custom navigation if not present
                if (!$slider.find('.metaslider-nav').length) {
                    FlexiProSliders.addCustomNavigation($slider);
                }
            });
        },
        
        initOwlCarousel: function() {
            // Initialize Owl Carousel if available
            if (typeof $.fn.owlCarousel !== 'undefined') {
                $('.owl-carousel').each(function() {
                    var $slider = $(this);
                    
                    if (!$slider.hasClass('owl-loaded')) {
                        $slider.owlCarousel({
                            items: 1,
                            loop: true,
                            autoplay: true,
                            autoplayTimeout: 5000,
                            autoplayHoverPause: true,
                            nav: true,
                            navText: ['<i class="fas fa-chevron-left"></i>', '<i class="fas fa-chevron-right"></i>'],
                            dots: true,
                            animateOut: 'fadeOut',
                            animateIn: 'fadeIn',
                            responsive: {
                                0: {
                                    items: 1
                                },
                                768: {
                                    items: 1
                                },
                                1024: {
                                    items: 1
                                }
                            }
                        });
                        
                        FlexiProSliders.enhanceSliderContent($slider);
                    }
                });
            }
        },
        
        initSwiperSlider: function() {
            // Initialize Swiper if available
            if (typeof window.Swiper !== 'undefined') {
                $('.swiper-container').each(function() {
                    var $slider = $(this);
                    
                    if (!$slider.hasClass('swiper-initialized')) {
                        new window.Swiper($slider[0], {
                            loop: true,
                            autoplay: {
                                delay: 5000,
                                disableOnInteraction: false,
                            },
                            navigation: {
                                nextEl: '.swiper-button-next',
                                prevEl: '.swiper-button-prev',
                            },
                            pagination: {
                                el: '.swiper-pagination',
                                clickable: true,
                            },
                            effect: 'fade',
                            fadeEffect: {
                                crossFade: true
                            }
                        });
                        
                        FlexiProSliders.enhanceSliderContent($slider);
                    }
                });
            }
        },
        
        initFlexslider: function() {
            // Initialize Flexslider if available
            if (typeof $.fn.flexslider !== 'undefined') {
                $('.flexslider').each(function() {
                    var $slider = $(this);
                    
                    if (!$slider.hasClass('flexslider-loaded')) {
                        $slider.flexslider({
                            animation: 'fade',
                            controlNav: true,
                            directionNav: true,
                            slideshow: true,
                            slideshowSpeed: 5000,
                            animationSpeed: 600,
                            pauseOnHover: true,
                            start: function() {
                                $slider.addClass('flexslider-loaded');
                                FlexiProSliders.enhanceSliderContent($slider);
                            }
                        });
                    }
                });
            }
        },
        
        initNivoSlider: function() {
            // Initialize Nivo Slider if available
            if (typeof $.fn.nivoSlider !== 'undefined') {
                $('.nivoSlider').each(function() {
                    var $slider = $(this);
                    
                    if (!$slider.hasClass('nivo-loaded')) {
                        $slider.nivoSlider({
                            effect: 'fade',
                            animSpeed: 600,
                            pauseTime: 5000,
                            directionNav: true,
                            controlNav: true,
                            pauseOnHover: true,
                            start: function() {
                                $slider.addClass('nivo-loaded');
                                FlexiProSliders.enhanceSliderContent($slider);
                            }
                        });
                    }
                });
            }
        },
        
        initCustomSliders: function() {
            // Initialize custom sliders
            $('.flexipro-slider, .banner-slider, .hero-slider').each(function() {
                var $slider = $(this);
                FlexiProSliders.enhanceSliderContent($slider);
                FlexiProSliders.addCustomNavigation($slider);
            });
        },
        
        enhanceSliderContent: function($slider) {
            // Add modern styling and animations to slider content
            $slider.find('.slider-content, .slide-content, .owl-slide-content, .swiper-slide-content, .nivo-caption').each(function() {
                var $content = $(this);
                
                // Add fade-in animation
                $content.addClass('animate-fadeInUp');
                
                // Enhance buttons
                $content.find('.btn, .button, a[class*="btn"]').each(function() {
                    var $btn = $(this);
                    if (!$btn.hasClass('btn-enhanced')) {
                        $btn.addClass('btn-enhanced');
                        
                        // Add hover effects
                        $btn.hover(
                            function() {
                                $(this).addClass('btn-hover');
                            },
                            function() {
                                $(this).removeClass('btn-hover');
                            }
                        );
                    }
                });
                
                // Add parallax effect to background images
                if ($content.parent().css('background-image') !== 'none') {
                    $content.parent().addClass('parallax-bg');
                }
            });
        },
        
        addCustomNavigation: function($slider) {
            // Add custom navigation if not present
            if (!$slider.find('.custom-nav').length) {
                var $nav = $('<div class="custom-nav"></div>');
                var $prev = $('<button class="custom-prev" aria-label="Previous slide"><i class="fas fa-chevron-left"></i></button>');
                var $next = $('<button class="custom-next" aria-label="Next slide"><i class="fas fa-chevron-right"></i></button>');
                var $dots = $('<div class="custom-dots"></div>');
                
                $nav.append($prev, $next, $dots);
                $slider.append($nav);
                
                // Add click handlers
                $prev.on('click', function() {
                    FlexiProSliders.goToPreviousSlide($slider);
                });
                
                $next.on('click', function() {
                    FlexiProSliders.goToNextSlide($slider);
                });
            }
        },
        
        goToPreviousSlide: function($slider) {
            // Generic previous slide functionality
            if ($slider.hasClass('owl-carousel')) {
                $slider.trigger('prev.owl.carousel');
            } else if ($slider.hasClass('swiper-container')) {
                if (window.Swiper && $slider[0].swiper) {
                    $slider[0].swiper.slidePrev();
                }
            } else if ($slider.hasClass('flexslider')) {
                $slider.flexslider('prev');
            } else if ($slider.hasClass('nivoSlider')) {
                $slider.trigger('nivo:prev');
            } else {
                // Custom slider logic
                var $slides = $slider.find('.slide, .slider-slide, .owl-item, .swiper-slide');
                var currentIndex = $slides.filter('.active, .current').index();
                var prevIndex = currentIndex > 0 ? currentIndex - 1 : $slides.length - 1;
                
                $slides.removeClass('active current');
                $slides.eq(prevIndex).addClass('active current');
            }
        },
        
        goToNextSlide: function($slider) {
            // Generic next slide functionality
            if ($slider.hasClass('owl-carousel')) {
                $slider.trigger('next.owl.carousel');
            } else if ($slider.hasClass('swiper-container')) {
                if (window.Swiper && $slider[0].swiper) {
                    $slider[0].swiper.slideNext();
                }
            } else if ($slider.hasClass('flexslider')) {
                $slider.flexslider('next');
            } else if ($slider.hasClass('nivoSlider')) {
                $slider.trigger('nivo:next');
            } else {
                // Custom slider logic
                var $slides = $slider.find('.slide, .slider-slide, .owl-item, .swiper-slide');
                var currentIndex = $slides.filter('.active, .current').index();
                var nextIndex = currentIndex < $slides.length - 1 ? currentIndex + 1 : 0;
                
                $slides.removeClass('active current');
                $slides.eq(nextIndex).addClass('active current');
            }
        },
        
        bindEvents: function() {
            // Bind global events
            $(window).on('resize', this.handleResize.bind(this));
            $(document).on('click', '.custom-prev', this.handleCustomPrev.bind(this));
            $(document).on('click', '.custom-next', this.handleCustomNext.bind(this));
            $(document).on('click', '.custom-dot', this.handleCustomDot.bind(this));
        },
        
        handleResize: function() {
            // Handle window resize
            $('.flexipro-slider, .rev_slider_wrapper, .smartslider3, .metaslider, .owl-carousel, .swiper-container, .flexslider, .nivoSlider').each(function() {
                var $slider = $(this);
                
                // Refresh slider if needed
                if ($slider.hasClass('owl-carousel') && $slider.data('owl.carousel')) {
                    $slider.trigger('refresh.owl.carousel');
                } else if ($slider.hasClass('swiper-container') && $slider[0].swiper) {
                    $slider[0].swiper.update();
                } else if ($slider.hasClass('flexslider')) {
                    $slider.flexslider('resize');
                }
            });
        },
        
        handleCustomPrev: function(e) {
            e.preventDefault();
            var $slider = $(e.target).closest('.flexipro-slider, .banner-slider, .hero-slider');
            this.goToPreviousSlide($slider);
        },
        
        handleCustomNext: function(e) {
            e.preventDefault();
            var $slider = $(e.target).closest('.flexipro-slider, .banner-slider, .hero-slider');
            this.goToNextSlide($slider);
        },
        
        handleCustomDot: function(e) {
            e.preventDefault();
            var $dot = $(e.target);
            var $slider = $dot.closest('.flexipro-slider, .banner-slider, .hero-slider');
            var slideIndex = $dot.data('slide');
            
            if ($slider.hasClass('owl-carousel')) {
                $slider.trigger('to.owl.carousel', [slideIndex]);
            } else if ($slider.hasClass('swiper-container') && $slider[0].swiper) {
                $slider[0].swiper.slideTo(slideIndex);
            } else {
                var $slides = $slider.find('.slide, .slider-slide, .owl-item, .swiper-slide');
                $slides.removeClass('active current');
                $slides.eq(slideIndex).addClass('active current');
            }
        }
    };
    
    // Initialize when document is ready
    $(document).ready(function() {
        FlexiProSliders.init();
    });
    
    // Re-initialize on AJAX content load
    $(document).on('ajaxComplete', function() {
        FlexiProSliders.init();
    });
    
    // Expose to global scope
    window.FlexiProSliders = FlexiProSliders;
    
})(jQuery);
