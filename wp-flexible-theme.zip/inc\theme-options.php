<?php
/**
 * Theme Options Framework
 * 
 * @package FlexiPro
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class FlexiPro_Theme_Options {
    
    private $options;
    private $sections;
    
    public function __construct() {
        $this->options = get_option('flexipro_options', array());
        $this->init_sections();
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'admin_init'));
        add_action('wp_head', array($this, 'output_custom_css'));
    }
    
    private function init_sections() {
        $this->sections = array(
            'general' => array(
                'title' => __('General Settings', 'flexipro'),
                'fields' => array(
                    'logo' => array(
                        'type' => 'image',
                        'label' => __('Site Logo', 'flexipro'),
                        'description' => __('Upload your site logo', 'flexipro')
                    ),
                    'favicon' => array(
                        'type' => 'image',
                        'label' => __('Favicon', 'flexipro'),
                        'description' => __('Upload your site favicon', 'flexipro')
                    ),
                    'preloader' => array(
                        'type' => 'checkbox',
                        'label' => __('Enable Preloader', 'flexipro'),
                        'description' => __('Show loading animation on page load', 'flexipro')
                    ),
                    'back_to_top' => array(
                        'type' => 'checkbox',
                        'label' => __('Enable Back to Top', 'flexipro'),
                        'description' => __('Show back to top button', 'flexipro')
                    ),
                    'smooth_scroll' => array(
                        'type' => 'checkbox',
                        'label' => __('Enable Smooth Scroll', 'flexipro'),
                        'description' => __('Enable smooth scrolling behavior', 'flexipro')
                    )
                )
            ),
            'header' => array(
                'title' => __('Header Settings', 'flexipro'),
                'fields' => array(
                    'header_style' => array(
                        'type' => 'select',
                        'label' => __('Header Style', 'flexipro'),
                        'options' => array(
                            'default' => __('Default', 'flexipro'),
                            'centered' => __('Centered', 'flexipro'),
                            'minimal' => __('Minimal', 'flexipro'),
                            'transparent' => __('Transparent', 'flexipro')
                        )
                    ),
                    'sticky_header' => array(
                        'type' => 'checkbox',
                        'label' => __('Sticky Header', 'flexipro'),
                        'description' => __('Make header stick to top on scroll', 'flexipro')
                    ),
                    'header_height' => array(
                        'type' => 'number',
                        'label' => __('Header Height (px)', 'flexipro'),
                        'default' => 80
                    ),
                    'header_bg_color' => array(
                        'type' => 'color',
                        'label' => __('Header Background Color', 'flexipro'),
                        'default' => '#ffffff'
                    ),
                    'header_text_color' => array(
                        'type' => 'color',
                        'label' => __('Header Text Color', 'flexipro'),
                        'default' => '#333333'
                    )
                )
            ),
            'footer' => array(
                'title' => __('Footer Settings', 'flexipro'),
                'fields' => array(
                    'footer_style' => array(
                        'type' => 'select',
                        'label' => __('Footer Style', 'flexipro'),
                        'options' => array(
                            'default' => __('Default', 'flexipro'),
                            'minimal' => __('Minimal', 'flexipro'),
                            'centered' => __('Centered', 'flexipro')
                        )
                    ),
                    'footer_bg_color' => array(
                        'type' => 'color',
                        'label' => __('Footer Background Color', 'flexipro'),
                        'default' => '#1a1a1a'
                    ),
                    'footer_text_color' => array(
                        'type' => 'color',
                        'label' => __('Footer Text Color', 'flexipro'),
                        'default' => '#ffffff'
                    ),
                    'footer_copyright' => array(
                        'type' => 'textarea',
                        'label' => __('Copyright Text', 'flexipro'),
                        'description' => __('Enter your copyright text', 'flexipro')
                    ),
                    'social_links' => array(
                        'type' => 'repeater',
                        'label' => __('Social Links', 'flexipro'),
                        'fields' => array(
                            'platform' => array('type' => 'text', 'label' => 'Platform'),
                            'url' => array('type' => 'url', 'label' => 'URL'),
                            'icon' => array('type' => 'text', 'label' => 'Icon Class')
                        )
                    )
                )
            ),
            'styling' => array(
                'title' => __('Styling Settings', 'flexipro'),
                'fields' => array(
                    'primary_color' => array(
                        'type' => 'color',
                        'label' => __('Primary Color', 'flexipro'),
                        'default' => '#007cba'
                    ),
                    'secondary_color' => array(
                        'type' => 'color',
                        'label' => __('Secondary Color', 'flexipro'),
                        'default' => '#6c757d'
                    ),
                    'accent_color' => array(
                        'type' => 'color',
                        'label' => __('Accent Color', 'flexipro'),
                        'default' => '#ff6b6b'
                    ),
                    'body_bg_color' => array(
                        'type' => 'color',
                        'label' => __('Body Background Color', 'flexipro'),
                        'default' => '#ffffff'
                    ),
                    'text_color' => array(
                        'type' => 'color',
                        'label' => __('Text Color', 'flexipro'),
                        'default' => '#333333'
                    ),
                    'heading_color' => array(
                        'type' => 'color',
                        'label' => __('Heading Color', 'flexipro'),
                        'default' => '#1a1a1a'
                    ),
                    'link_color' => array(
                        'type' => 'color',
                        'label' => __('Link Color', 'flexipro'),
                        'default' => '#007cba'
                    ),
                    'border_radius' => array(
                        'type' => 'number',
                        'label' => __('Border Radius (px)', 'flexipro'),
                        'default' => 5
                    ),
                    'box_shadow' => array(
                        'type' => 'checkbox',
                        'label' => __('Enable Box Shadows', 'flexipro'),
                        'description' => __('Add subtle shadows to elements', 'flexipro')
                    )
                )
            ),
            'typography' => array(
                'title' => __('Typography Settings', 'flexipro'),
                'fields' => array(
                    'body_font' => array(
                        'type' => 'select',
                        'label' => __('Body Font', 'flexipro'),
                        'options' => $this->get_google_fonts()
                    ),
                    'heading_font' => array(
                        'type' => 'select',
                        'label' => __('Heading Font', 'flexipro'),
                        'options' => $this->get_google_fonts()
                    ),
                    'body_font_size' => array(
                        'type' => 'number',
                        'label' => __('Body Font Size (px)', 'flexipro'),
                        'default' => 16
                    ),
                    'heading_font_weight' => array(
                        'type' => 'select',
                        'label' => __('Heading Font Weight', 'flexipro'),
                        'options' => array(
                            '300' => 'Light (300)',
                            '400' => 'Normal (400)',
                            '500' => 'Medium (500)',
                            '600' => 'Semi Bold (600)',
                            '700' => 'Bold (700)',
                            '800' => 'Extra Bold (800)'
                        )
                    )
                )
            ),
            'portfolio' => array(
                'title' => __('Portfolio Settings', 'flexipro'),
                'fields' => array(
                    'portfolio_layout' => array(
                        'type' => 'select',
                        'label' => __('Portfolio Layout', 'flexipro'),
                        'options' => array(
                            'grid' => __('Grid', 'flexipro'),
                            'masonry' => __('Masonry', 'flexipro'),
                            'carousel' => __('Carousel', 'flexipro')
                        )
                    ),
                    'portfolio_columns' => array(
                        'type' => 'select',
                        'label' => __('Portfolio Columns', 'flexipro'),
                        'options' => array(
                            '2' => '2 Columns',
                            '3' => '3 Columns',
                            '4' => '4 Columns'
                        )
                    ),
                    'portfolio_filter' => array(
                        'type' => 'checkbox',
                        'label' => __('Enable Portfolio Filter', 'flexipro'),
                        'description' => __('Show category filter on portfolio page', 'flexipro')
                    ),
                    'portfolio_lightbox' => array(
                        'type' => 'checkbox',
                        'label' => __('Enable Lightbox', 'flexipro'),
                        'description' => __('Open portfolio items in lightbox', 'flexipro')
                    )
                )
            ),
            'blog' => array(
                'title' => __('Blog Settings', 'flexipro'),
                'fields' => array(
                    'blog_layout' => array(
                        'type' => 'select',
                        'label' => __('Blog Layout', 'flexipro'),
                        'options' => array(
                            'grid' => __('Grid', 'flexipro'),
                            'list' => __('List', 'flexipro'),
                            'masonry' => __('Masonry', 'flexipro')
                        )
                    ),
                    'blog_sidebar' => array(
                        'type' => 'select',
                        'label' => __('Blog Sidebar', 'flexipro'),
                        'options' => array(
                            'right' => __('Right Sidebar', 'flexipro'),
                            'left' => __('Left Sidebar', 'flexipro'),
                            'none' => __('No Sidebar', 'flexipro')
                        )
                    ),
                    'excerpt_length' => array(
                        'type' => 'number',
                        'label' => __('Excerpt Length', 'flexipro'),
                        'default' => 55
                    ),
                    'show_meta' => array(
                        'type' => 'checkbox',
                        'label' => __('Show Post Meta', 'flexipro'),
                        'description' => __('Show date, author, comments on blog posts', 'flexipro')
                    )
                )
            ),
            'woocommerce' => array(
                'title' => __('WooCommerce Settings', 'flexipro'),
                'fields' => array(
                    'shop_layout' => array(
                        'type' => 'select',
                        'label' => __('Shop Layout', 'flexipro'),
                        'options' => array(
                            'grid' => __('Grid', 'flexipro'),
                            'list' => __('List', 'flexipro')
                        )
                    ),
                    'products_per_page' => array(
                        'type' => 'number',
                        'label' => __('Products Per Page', 'flexipro'),
                        'default' => 12
                    ),
                    'shop_sidebar' => array(
                        'type' => 'select',
                        'label' => __('Shop Sidebar', 'flexipro'),
                        'options' => array(
                            'right' => __('Right Sidebar', 'flexipro'),
                            'left' => __('Left Sidebar', 'flexipro'),
                            'none' => __('No Sidebar', 'flexipro')
                        )
                    ),
                    'enable_quick_view' => array(
                        'type' => 'checkbox',
                        'label' => __('Enable Quick View', 'flexipro'),
                        'description' => __('Show quick view button on product hover', 'flexipro')
                    )
                )
            )
        );
    }
    
    private function get_google_fonts() {
        return array(
            'Inter' => 'Inter',
            'Roboto' => 'Roboto',
            'Open Sans' => 'Open Sans',
            'Lato' => 'Lato',
            'Montserrat' => 'Montserrat',
            'Poppins' => 'Poppins',
            'Source Sans Pro' => 'Source Sans Pro',
            'Nunito' => 'Nunito',
            'Raleway' => 'Raleway',
            'Ubuntu' => 'Ubuntu'
        );
    }
    
    public function add_admin_menu() {
        add_menu_page(
            __('Flexi Theme Options', 'flexipro'),
            __('Flexi Theme Options', 'flexipro'),
            'manage_options',
            'flexipro-options',
            array($this, 'options_page'),
            'dashicons-admin-customizer',
            30
        );
    }
    
    public function admin_init() {
        register_setting('flexipro_options', 'flexipro_options', array($this, 'sanitize_options'));
    }
    
    public function sanitize_options($input) {
        $sanitized = array();
        
        foreach ($input as $key => $value) {
            if (is_array($value)) {
                $sanitized[$key] = $this->sanitize_options($value);
            } else {
                $sanitized[$key] = sanitize_text_field($value);
            }
        }
        
        return $sanitized;
    }
    
    public function options_page() {
        if (isset($_POST['submit'])) {
            update_option('flexipro_options', $_POST['flexipro_options']);
            echo '<div class="notice notice-success"><p>' . __('Options saved successfully!', 'flexipro') . '</p></div>';
        }
        
        $this->options = get_option('flexipro_options', array());
        ?>
        <div class="wrap flexipro-options">
            <h1><?php _e('Flexi ztheme by rwb - Theme Options', 'flexipro'); ?></h1>
            
            <div class="flexipro-options-wrapper">
                <div class="flexipro-options-sidebar">
                    <div class="flexipro-options-nav">
                        <?php foreach ($this->sections as $key => $section) : ?>
                            <a href="#<?php echo $key; ?>" class="nav-tab <?php echo $key === 'general' ? 'nav-tab-active' : ''; ?>">
                                <?php echo $section['title']; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="flexipro-options-content">
                    <form method="post" action="">
                        <?php wp_nonce_field('flexipro_options_nonce', 'flexipro_options_nonce'); ?>
                        
                        <?php foreach ($this->sections as $key => $section) : ?>
                            <div id="<?php echo $key; ?>" class="tab-pane <?php echo $key === 'general' ? 'active' : ''; ?>">
                                <h2><?php echo $section['title']; ?></h2>
                                
                                <table class="form-table">
                                    <?php foreach ($section['fields'] as $field_key => $field) : ?>
                                        <tr>
                                            <th scope="row">
                                                <label for="<?php echo $field_key; ?>"><?php echo $field['label']; ?></label>
                                                <?php if (isset($field['description'])) : ?>
                                                    <p class="description"><?php echo $field['description']; ?></p>
                                                <?php endif; ?>
                                            </th>
                                            <td>
                                                <?php $this->render_field($field_key, $field); ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </table>
                            </div>
                        <?php endforeach; ?>
                        
                        <?php submit_button(); ?>
                    </form>
                </div>
            </div>
        </div>
        
        <style>
        .flexipro-options-wrapper {
            display: flex;
            gap: 20px;
            margin-top: 20px;
        }
        .flexipro-options-sidebar {
            width: 200px;
            flex-shrink: 0;
        }
        .flexipro-options-nav {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
        }
        .flexipro-options-nav .nav-tab {
            display: block;
            padding: 10px 15px;
            text-decoration: none;
            border: none;
            border-bottom: 1px solid #ccd0d4;
            background: #f1f1f1;
        }
        .flexipro-options-nav .nav-tab:last-child {
            border-bottom: none;
        }
        .flexipro-options-nav .nav-tab:hover,
        .flexipro-options-nav .nav-tab.nav-tab-active {
            background: #0073aa;
            color: #fff;
        }
        .flexipro-options-content {
            flex: 1;
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            padding: 20px;
        }
        .tab-pane {
            display: none;
        }
        .tab-pane.active {
            display: block;
        }
        .flexipro-field-repeater {
            border: 1px solid #ddd;
            padding: 15px;
            margin: 10px 0;
        }
        .flexipro-repeater-item {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
            align-items: end;
        }
        .flexipro-repeater-item input {
            flex: 1;
        }
        .flexipro-remove-item {
            background: #dc3545;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }
        .flexipro-add-item {
            background: #28a745;
            color: white;
            border: none;
            padding: 8px 15px;
            cursor: pointer;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            // Tab switching
            $('.flexipro-options-nav .nav-tab').click(function(e) {
                e.preventDefault();
                var target = $(this).attr('href');
                
                $('.nav-tab').removeClass('nav-tab-active');
                $(this).addClass('nav-tab-active');
                
                $('.tab-pane').removeClass('active');
                $(target).addClass('active');
            });
            
            // Repeater fields
            $('.flexipro-add-item').click(function() {
                var repeater = $(this).closest('.flexipro-field-repeater');
                var template = repeater.find('.flexipro-repeater-template').html();
                repeater.find('.flexipro-repeater-items').append(template);
            });
            
            $(document).on('click', '.flexipro-remove-item', function() {
                $(this).closest('.flexipro-repeater-item').remove();
            });
        });
        </script>
        <?php
    }
    
    private function render_field($field_key, $field) {
        $value = isset($this->options[$field_key]) ? $this->options[$field_key] : (isset($field['default']) ? $field['default'] : '');
        
        switch ($field['type']) {
            case 'text':
                echo '<input type="text" id="' . $field_key . '" name="flexipro_options[' . $field_key . ']" value="' . esc_attr($value) . '" class="regular-text" />';
                break;
                
            case 'textarea':
                echo '<textarea id="' . $field_key . '" name="flexipro_options[' . $field_key . ']" rows="3" cols="50" class="large-text">' . esc_textarea($value) . '</textarea>';
                break;
                
            case 'number':
                echo '<input type="number" id="' . $field_key . '" name="flexipro_options[' . $field_key . ']" value="' . esc_attr($value) . '" class="small-text" />';
                break;
                
            case 'color':
                echo '<input type="color" id="' . $field_key . '" name="flexipro_options[' . $field_key . ']" value="' . esc_attr($value) . '" />';
                break;
                
            case 'checkbox':
                echo '<label><input type="checkbox" id="' . $field_key . '" name="flexipro_options[' . $field_key . ']" value="1" ' . checked($value, 1, false) . ' /> ' . $field['label'] . '</label>';
                break;
                
            case 'select':
                echo '<select id="' . $field_key . '" name="flexipro_options[' . $field_key . ']">';
                foreach ($field['options'] as $option_value => $option_label) {
                    echo '<option value="' . esc_attr($option_value) . '" ' . selected($value, $option_value, false) . '>' . esc_html($option_label) . '</option>';
                }
                echo '</select>';
                break;
                
            case 'image':
                echo '<input type="text" id="' . $field_key . '" name="flexipro_options[' . $field_key . ']" value="' . esc_attr($value) . '" class="regular-text" />';
                echo '<button type="button" class="button upload-image" data-target="' . $field_key . '">' . __('Upload', 'flexipro') . '</button>';
                if ($value) {
                    echo '<div class="image-preview"><img src="' . esc_url($value) . '" style="max-width: 200px; height: auto;" /></div>';
                }
                break;
                
            case 'repeater':
                echo '<div class="flexipro-field-repeater">';
                echo '<div class="flexipro-repeater-items">';
                if (is_array($value)) {
                    foreach ($value as $index => $item) {
                        echo '<div class="flexipro-repeater-item">';
                        foreach ($field['fields'] as $sub_key => $sub_field) {
                            $sub_value = isset($item[$sub_key]) ? $item[$sub_key] : '';
                            echo '<input type="' . $sub_field['type'] . '" name="flexipro_options[' . $field_key . '][' . $index . '][' . $sub_key . ']" value="' . esc_attr($sub_value) . '" placeholder="' . esc_attr($sub_field['label']) . '" />';
                        }
                        echo '<button type="button" class="flexipro-remove-item">' . __('Remove', 'flexipro') . '</button>';
                        echo '</div>';
                    }
                }
                echo '</div>';
                echo '<button type="button" class="flexipro-add-item">' . __('Add Item', 'flexipro') . '</button>';
                echo '</div>';
                break;
        }
    }
    
    public function output_custom_css() {
        $options = $this->options;
        
        if (empty($options)) {
            return;
        }
        
        echo '<style type="text/css">';
        echo ':root {';
        
        // Colors
        if (!empty($options['primary_color'])) {
            echo '--primary-color: ' . esc_attr($options['primary_color']) . ';';
        }
        if (!empty($options['secondary_color'])) {
            echo '--secondary-color: ' . esc_attr($options['secondary_color']) . ';';
        }
        if (!empty($options['accent_color'])) {
            echo '--accent-color: ' . esc_attr($options['accent_color']) . ';';
        }
        if (!empty($options['body_bg_color'])) {
            echo '--body-bg-color: ' . esc_attr($options['body_bg_color']) . ';';
        }
        if (!empty($options['text_color'])) {
            echo '--text-color: ' . esc_attr($options['text_color']) . ';';
        }
        if (!empty($options['heading_color'])) {
            echo '--heading-color: ' . esc_attr($options['heading_color']) . ';';
        }
        if (!empty($options['link_color'])) {
            echo '--link-color: ' . esc_attr($options['link_color']) . ';';
        }
        
        // Typography
        if (!empty($options['body_font'])) {
            echo '--body-font: "' . esc_attr($options['body_font']) . '", sans-serif;';
        }
        if (!empty($options['heading_font'])) {
            echo '--heading-font: "' . esc_attr($options['heading_font']) . '", sans-serif;';
        }
        if (!empty($options['body_font_size'])) {
            echo '--body-font-size: ' . esc_attr($options['body_font_size']) . 'px;';
        }
        if (!empty($options['heading_font_weight'])) {
            echo '--heading-font-weight: ' . esc_attr($options['heading_font_weight']) . ';';
        }
        
        // Layout
        if (!empty($options['border_radius'])) {
            echo '--border-radius: ' . esc_attr($options['border_radius']) . 'px;';
        }
        
        echo '}';
        
        // Apply custom styles
        if (!empty($options['body_bg_color'])) {
            echo 'body { background-color: var(--body-bg-color); }';
        }
        if (!empty($options['text_color'])) {
            echo 'body { color: var(--text-color); }';
        }
        if (!empty($options['heading_color'])) {
            echo 'h1, h2, h3, h4, h5, h6 { color: var(--heading-color); }';
        }
        if (!empty($options['link_color'])) {
            echo 'a { color: var(--link-color); }';
        }
        if (!empty($options['primary_color'])) {
            echo '.btn-primary { background-color: var(--primary-color); }';
            echo '.btn-outline { border-color: var(--primary-color); color: var(--primary-color); }';
        }
        
        echo '</style>';
    }
}

// Initialize theme options
new FlexiPro_Theme_Options();
