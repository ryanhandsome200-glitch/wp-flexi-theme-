<?php
/**
 * Flexi Theme by RWB Ultimate 1.0 Functions
 *
 * @package FlexiPro
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define theme constants
define('FLEXIPRO_VERSION', '1.0.0');
define('FLEXIPRO_THEME_DIR', get_template_directory());
define('FLEXIPRO_THEME_URL', get_template_directory_uri());
define('FLEXIPRO_INC_DIR', FLEXIPRO_THEME_DIR . '/inc');
define('FLEXIPRO_ADMIN_DIR', FLEXIPRO_THEME_DIR . '/admin');

// Theme setup
function flexipro_setup() {
    // Add theme support
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('custom-logo');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    add_theme_support('customize-selective-refresh-widgets');
    add_theme_support('responsive-embeds');
    add_theme_support('wp-block-styles');
    add_theme_support('align-wide');
    add_theme_support('editor-styles');
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');

    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'flexipro'),
        'footer' => __('Footer Menu', 'flexipro'),
    ));

    // Add image sizes
    add_image_size('flexipro-blog-thumb', 400, 300, true);
    add_image_size('flexipro-portfolio-thumb', 600, 400, true);
    add_image_size('flexipro-hero-bg', 1920, 1080, true);
}
add_action('after_setup_theme', 'flexipro_setup');

// Enqueue scripts and styles
function flexipro_scripts() {
    // Enqueue main stylesheet
    wp_enqueue_style('flexipro-style', get_stylesheet_uri(), array(), FLEXIPRO_VERSION);
    
    // Enqueue Google Fonts
    wp_enqueue_style('flexipro-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap', array(), null);
    
    // Enqueue Font Awesome
    wp_enqueue_style('flexipro-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');
    
    // Enqueue Forms CSS
    wp_enqueue_style('flexipro-forms', FLEXIPRO_THEME_URL . '/css/forms.css', array(), FLEXIPRO_VERSION);
    
    // Enqueue Sliders CSS
    wp_enqueue_style('flexipro-sliders', FLEXIPRO_THEME_URL . '/css/sliders.css', array(), FLEXIPRO_VERSION);
    
    // Enqueue main JavaScript
    wp_enqueue_script('flexipro-main', FLEXIPRO_THEME_URL . '/js/main.js', array('jquery'), FLEXIPRO_VERSION, true);
    
    // Enqueue sticky header script
    wp_enqueue_script('flexipro-sticky-header', FLEXIPRO_THEME_URL . '/js/sticky-header.js', array('jquery'), FLEXIPRO_VERSION, true);
    
    // Enqueue sliders script
    wp_enqueue_script('flexipro-sliders', FLEXIPRO_THEME_URL . '/js/sliders.js', array('jquery'), FLEXIPRO_VERSION, true);
    
    // Enqueue page builder scripts
    if (is_page() && get_post_meta(get_the_ID(), '_flexipro_page_builder', true)) {
        wp_enqueue_script('flexipro-page-builder', FLEXIPRO_THEME_URL . '/js/page-builder.js', array('jquery'), FLEXIPRO_VERSION, true);
        wp_enqueue_style('flexipro-page-builder', FLEXIPRO_THEME_URL . '/css/page-builder.css', array(), FLEXIPRO_VERSION);
    }
    
    // Localize script for AJAX
    wp_localize_script('flexipro-main', 'flexipro_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('flexipro_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'flexipro_scripts');

// Enqueue admin scripts
function flexipro_admin_scripts($hook) {
    if ('toplevel_page_flexipro-options' == $hook || 'post.php' == $hook || 'post-new.php' == $hook) {
        wp_enqueue_style('flexipro-admin', FLEXIPRO_THEME_URL . '/admin/css/admin.css', array(), FLEXIPRO_VERSION);
        wp_enqueue_script('flexipro-admin', FLEXIPRO_THEME_URL . '/admin/js/admin.js', array('jquery'), FLEXIPRO_VERSION, true);
        wp_enqueue_media();
    }
}
add_action('admin_enqueue_scripts', 'flexipro_admin_scripts');

// Include required files
require_once FLEXIPRO_INC_DIR . '/theme-options.php';
require_once FLEXIPRO_INC_DIR . '/page-builder.php';
require_once FLEXIPRO_INC_DIR . '/visual-builder.php';
require_once FLEXIPRO_INC_DIR . '/frontend-renderer.php';
require_once FLEXIPRO_INC_DIR . '/shortcodes.php';
require_once FLEXIPRO_INC_DIR . '/demo-import.php';
require_once FLEXIPRO_INC_DIR . '/customizer.php';
require_once FLEXIPRO_INC_DIR . '/widgets.php';
require_once FLEXIPRO_INC_DIR . '/woocommerce.php';
require_once FLEXIPRO_INC_DIR . '/portfolio.php';

// Register widget areas
function flexipro_widgets_init() {
    register_sidebar(array(
        'name'          => __('Sidebar', 'flexipro'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here.', 'flexipro'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    register_sidebar(array(
        'name'          => __('Footer 1', 'flexipro'),
        'id'            => 'footer-1',
        'description'   => __('Add widgets here.', 'flexipro'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    register_sidebar(array(
        'name'          => __('Footer 2', 'flexipro'),
        'id'            => 'footer-2',
        'description'   => __('Add widgets here.', 'flexipro'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    register_sidebar(array(
        'name'          => __('Footer 3', 'flexipro'),
        'id'            => 'footer-3',
        'description'   => __('Add widgets here.', 'flexipro'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    register_sidebar(array(
        'name'          => __('Footer 4', 'flexipro'),
        'id'            => 'footer-4',
        'description'   => __('Add widgets here.', 'flexipro'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'flexipro_widgets_init');

// Custom post types
function flexipro_custom_post_types() {
    // Portfolio post type
    register_post_type('portfolio', array(
        'labels' => array(
            'name' => __('Portfolio', 'flexipro'),
            'singular_name' => __('Portfolio Item', 'flexipro'),
            'add_new' => __('Add New', 'flexipro'),
            'add_new_item' => __('Add New Portfolio Item', 'flexipro'),
            'edit_item' => __('Edit Portfolio Item', 'flexipro'),
            'new_item' => __('New Portfolio Item', 'flexipro'),
            'view_item' => __('View Portfolio Item', 'flexipro'),
            'search_items' => __('Search Portfolio Items', 'flexipro'),
            'not_found' => __('No portfolio items found', 'flexipro'),
            'not_found_in_trash' => __('No portfolio items found in trash', 'flexipro'),
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-portfolio',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite' => array('slug' => 'portfolio'),
    ));

    // Portfolio categories
    register_taxonomy('portfolio_category', 'portfolio', array(
        'labels' => array(
            'name' => __('Portfolio Categories', 'flexipro'),
            'singular_name' => __('Portfolio Category', 'flexipro'),
        ),
        'hierarchical' => true,
        'public' => true,
        'rewrite' => array('slug' => 'portfolio-category'),
    ));
}
add_action('init', 'flexipro_custom_post_types');

// Add page builder meta box
function flexipro_add_page_builder_meta_box() {
    add_meta_box(
        'flexipro-page-builder',
        __('Page Builder', 'flexipro'),
        'flexipro_page_builder_meta_box_callback',
        'page',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'flexipro_add_page_builder_meta_box');

// Page builder meta box callback
function flexipro_page_builder_meta_box_callback($post) {
    wp_nonce_field('flexipro_page_builder_nonce', 'flexipro_page_builder_nonce');
    $page_builder_data = get_post_meta($post->ID, '_flexipro_page_builder', true);
    ?>
    <div id="flexipro-page-builder">
        <div class="flexipro-builder-toolbar">
            <button type="button" class="button button-primary" id="add-section">Add Section</button>
            <button type="button" class="button" id="add-row">Add Row</button>
            <button type="button" class="button" id="add-column">Add Column</button>
        </div>
        <div class="flexipro-builder-elements">
            <h4>Elements</h4>
            <div class="flexipro-element-grid">
                <div class="flexipro-element" data-element="text">
                    <i class="fas fa-font"></i>
                    <span>Text Block</span>
                </div>
                <div class="flexipro-element" data-element="image">
                    <i class="fas fa-image"></i>
                    <span>Image</span>
                </div>
                <div class="flexipro-element" data-element="button">
                    <i class="fas fa-mouse-pointer"></i>
                    <span>Button</span>
                </div>
                <div class="flexipro-element" data-element="heading">
                    <i class="fas fa-heading"></i>
                    <span>Heading</span>
                </div>
                <div class="flexipro-element" data-element="spacer">
                    <i class="fas fa-arrows-alt-v"></i>
                    <span>Spacer</span>
                </div>
                <div class="flexipro-element" data-element="video">
                    <i class="fas fa-video"></i>
                    <span>Video</span>
                </div>
            </div>
        </div>
        <div class="flexipro-builder-canvas">
            <div id="flexipro-sections">
                <?php
                if ($page_builder_data) {
                    echo $page_builder_data;
                } else {
                    echo '<div class="flexipro-empty-state">Click "Add Section" to start building your page</div>';
                }
                ?>
            </div>
        </div>
        <textarea name="flexipro_page_builder_data" id="flexipro_page_builder_data" style="display: none;"><?php echo esc_textarea($page_builder_data); ?></textarea>
    </div>
    <?php
}

// Save page builder data
function flexipro_save_page_builder_data($post_id) {
    if (!isset($_POST['flexipro_page_builder_nonce']) || !wp_verify_nonce($_POST['flexipro_page_builder_nonce'], 'flexipro_page_builder_nonce')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (isset($_POST['flexipro_page_builder_data'])) {
        update_post_meta($post_id, '_flexipro_page_builder', $_POST['flexipro_page_builder_data']);
    }
}
add_action('save_post', 'flexipro_save_page_builder_data');

// AJAX handlers for page builder
add_action('wp_ajax_flexipro_save_element', 'flexipro_save_element_ajax');
add_action('wp_ajax_flexipro_delete_element', 'flexipro_delete_element_ajax');

function flexipro_save_element_ajax() {
    check_ajax_referer('flexipro_nonce', 'nonce');
    
    $element_data = $_POST['element_data'];
    $element_html = flexipro_render_element($element_data);
    
    wp_send_json_success(array('html' => $element_html));
}

function flexipro_delete_element_ajax() {
    check_ajax_referer('flexipro_nonce', 'nonce');
    
    wp_send_json_success();
}

// Render page builder element
function flexipro_render_element($element_data) {
    $element_type = $element_data['type'];
    $element_settings = $element_data['settings'];
    
    ob_start();
    
    switch ($element_type) {
        case 'text':
            echo '<div class="flexipro-text-element" data-id="' . esc_attr($element_data['id']) . '">';
            echo '<div class="element-content">' . wp_kses_post($element_settings['content']) . '</div>';
            echo '<div class="element-controls"><button class="edit-element">Edit</button><button class="delete-element">Delete</button></div>';
            echo '</div>';
            break;
            
        case 'image':
            echo '<div class="flexipro-image-element" data-id="' . esc_attr($element_data['id']) . '">';
            if (!empty($element_settings['image_id'])) {
                echo wp_get_attachment_image($element_settings['image_id'], 'full');
            }
            echo '<div class="element-controls"><button class="edit-element">Edit</button><button class="delete-element">Delete</button></div>';
            echo '</div>';
            break;
            
        case 'button':
            echo '<div class="flexipro-button-element" data-id="' . esc_attr($element_data['id']) . '">';
            echo '<a href="' . esc_url($element_settings['url']) . '" class="btn btn-' . esc_attr($element_settings['style']) . '">' . esc_html($element_settings['text']) . '</a>';
            echo '<div class="element-controls"><button class="edit-element">Edit</button><button class="delete-element">Delete</button></div>';
            echo '</div>';
            break;
            
        case 'heading':
            echo '<div class="flexipro-heading-element" data-id="' . esc_attr($element_data['id']) . '">';
            echo '<' . esc_attr($element_settings['tag']) . '>' . esc_html($element_settings['text']) . '</' . esc_attr($element_settings['tag']) . '>';
            echo '<div class="element-controls"><button class="edit-element">Edit</button><button class="delete-element">Delete</button></div>';
            echo '</div>';
            break;
    }
    
    return ob_get_clean();
}

// Add theme options page
function flexipro_add_theme_options_page() {
    add_menu_page(
        __('Flexi Theme Options', 'flexipro'),
        __('Flexi Theme Options', 'flexipro'),
        'manage_options',
        'flexipro-options',
        'flexipro_theme_options_page',
        'dashicons-admin-customizer',
        30
    );
}
add_action('admin_menu', 'flexipro_add_theme_options_page');

// Theme options page callback
function flexipro_theme_options_page() {
    if (isset($_POST['submit'])) {
        update_option('flexipro_options', $_POST['flexipro_options']);
        echo '<div class="notice notice-success"><p>Options saved successfully!</p></div>';
    }
    
    $options = get_option('flexipro_options', array());
    ?>
    <div class="wrap">
        <h1>Flexi Theme by RWB Ultimate 1.0 Options</h1>
        <form method="post" action="">
            <?php wp_nonce_field('flexipro_options_nonce', 'flexipro_options_nonce'); ?>
            
            <div class="flexipro-options-tabs">
                <nav class="nav-tab-wrapper">
                    <a href="#general" class="nav-tab nav-tab-active">General</a>
                    <a href="#header" class="nav-tab">Header</a>
                    <a href="#footer" class="nav-tab">Footer</a>
                    <a href="#styling" class="nav-tab">Styling</a>
                    <a href="#typography" class="nav-tab">Typography</a>
                    <a href="#portfolio" class="nav-tab">Portfolio</a>
                    <a href="#blog" class="nav-tab">Blog</a>
                    <a href="#woocommerce" class="nav-tab">WooCommerce</a>
                </nav>
                
                <div class="tab-content">
                    <div id="general" class="tab-pane active">
                        <table class="form-table">
                            <tr>
                                <th scope="row">Site Logo</th>
                                <td>
                                    <input type="text" name="flexipro_options[logo]" value="<?php echo esc_attr($options['logo'] ?? ''); ?>" class="regular-text" />
                                    <button type="button" class="button upload-logo">Upload Logo</button>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Favicon</th>
                                <td>
                                    <input type="text" name="flexipro_options[favicon]" value="<?php echo esc_attr($options['favicon'] ?? ''); ?>" class="regular-text" />
                                    <button type="button" class="button upload-favicon">Upload Favicon</button>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Preloader</th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="flexipro_options[preloader]" value="1" <?php checked($options['preloader'] ?? 0, 1); ?> />
                                        Enable preloader
                                    </label>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <div id="header" class="tab-pane">
                        <table class="form-table">
                            <tr>
                                <th scope="row">Header Style</th>
                                <td>
                                    <select name="flexipro_options[header_style]">
                                        <option value="default" <?php selected($options['header_style'] ?? 'default', 'default'); ?>>Default</option>
                                        <option value="centered" <?php selected($options['header_style'] ?? 'default', 'centered'); ?>>Centered</option>
                                        <option value="minimal" <?php selected($options['header_style'] ?? 'default', 'minimal'); ?>>Minimal</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Sticky Header</th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="flexipro_options[sticky_header]" value="1" <?php checked($options['sticky_header'] ?? 0, 1); ?> />
                                        Enable sticky header
                                    </label>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <div id="footer" class="tab-pane">
                        <table class="form-table">
                            <tr>
                                <th scope="row">Footer Text</th>
                                <td>
                                    <textarea name="flexipro_options[footer_text]" rows="3" cols="50"><?php echo esc_textarea($options['footer_text'] ?? ''); ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Social Links</th>
                                <td>
                                    <div class="social-links">
                                        <p><label>Facebook: <input type="url" name="flexipro_options[social_facebook]" value="<?php echo esc_attr($options['social_facebook'] ?? ''); ?>" /></label></p>
                                        <p><label>Twitter: <input type="url" name="flexipro_options[social_twitter]" value="<?php echo esc_attr($options['social_twitter'] ?? ''); ?>" /></label></p>
                                        <p><label>Instagram: <input type="url" name="flexipro_options[social_instagram]" value="<?php echo esc_attr($options['social_instagram'] ?? ''); ?>" /></label></p>
                                        <p><label>LinkedIn: <input type="url" name="flexipro_options[social_linkedin]" value="<?php echo esc_attr($options['social_linkedin'] ?? ''); ?>" /></label></p>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <div id="styling" class="tab-pane">
                        <table class="form-table">
                            <tr>
                                <th scope="row">Primary Color</th>
                                <td>
                                    <input type="color" name="flexipro_options[primary_color]" value="<?php echo esc_attr($options['primary_color'] ?? '#007cba'); ?>" />
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Secondary Color</th>
                                <td>
                                    <input type="color" name="flexipro_options[secondary_color]" value="<?php echo esc_attr($options['secondary_color'] ?? '#6c757d'); ?>" />
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Body Background</th>
                                <td>
                                    <input type="color" name="flexipro_options[body_bg]" value="<?php echo esc_attr($options['body_bg'] ?? '#ffffff'); ?>" />
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Add custom CSS from options
function flexipro_custom_css() {
    $options = get_option('flexipro_options', array());
    
    if (!empty($options['primary_color']) || !empty($options['secondary_color']) || !empty($options['body_bg'])) {
        echo '<style type="text/css">';
        
        if (!empty($options['primary_color'])) {
            echo ':root { --primary-color: ' . esc_attr($options['primary_color']) . '; }';
            echo '.btn-primary { background-color: ' . esc_attr($options['primary_color']) . '; }';
            echo '.btn-outline { border-color: ' . esc_attr($options['primary_color']) . '; color: ' . esc_attr($options['primary_color']) . '; }';
        }
        
        if (!empty($options['secondary_color'])) {
            echo ':root { --secondary-color: ' . esc_attr($options['secondary_color']) . '; }';
            echo '.btn-secondary { background-color: ' . esc_attr($options['secondary_color']) . '; }';
        }
        
        if (!empty($options['body_bg'])) {
            echo 'body { background-color: ' . esc_attr($options['body_bg']) . '; }';
        }
        
        echo '</style>';
    }
}
add_action('wp_head', 'flexipro_custom_css');

// Add preloader if enabled
function flexipro_preloader() {
    $options = get_option('flexipro_options', array());
    
    if (!empty($options['preloader'])) {
        ?>
        <div id="flexipro-preloader">
            <div class="preloader-content">
                <div class="preloader-spinner"></div>
                <div class="preloader-text">Loading...</div>
            </div>
        </div>
        <style>
        #flexipro-preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: #fff;
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .preloader-spinner {
            width: 50px;
            height: 50px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #007cba;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .preloader-text {
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
        </style>
        <script>
        window.addEventListener('load', function() {
            document.getElementById('flexipro-preloader').style.display = 'none';
        });
        </script>
        <?php
    }
}
add_action('wp_head', 'flexipro_preloader');

// Add sticky header class if enabled
function flexipro_sticky_header_class($classes) {
    $options = get_option('flexipro_options', array());
    
    if (!empty($options['sticky_header'])) {
        $classes[] = 'sticky-header';
    }
    
    return $classes;
}
add_filter('body_class', 'flexipro_sticky_header_class');

// Add sticky header CSS
function flexipro_sticky_header_css() {
    $options = get_option('flexipro_options', array());
    
    if (!empty($options['sticky_header'])) {
        ?>
        <style>
        .sticky-header .site-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            transition: all 0.3s ease;
        }
        .sticky-header .site-header.scrolled {
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }
        .sticky-header body {
            padding-top: 80px;
        }
        </style>
        <script>
        window.addEventListener('scroll', function() {
            const header = document.querySelector('.site-header');
            if (window.scrollY > 100) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
        </script>
        <?php
    }
}
add_action('wp_head', 'flexipro_sticky_header_css');

// Visual Builder AJAX Handlers
add_action('wp_ajax_flexipro_get_builder_data', 'flexipro_get_builder_data_ajax');
add_action('wp_ajax_flexipro_save_builder_data', 'flexipro_save_builder_data_ajax');
add_action('wp_ajax_flexipro_publish_post', 'flexipro_publish_post_ajax');
add_action('wp_ajax_flexipro_create_demo_page', 'flexipro_create_demo_page_ajax');

function flexipro_get_builder_data_ajax() {
    check_ajax_referer('flexipro_builder_nonce', 'nonce');
    
    if (!current_user_can('edit_posts')) {
        wp_send_json_error('Permission denied');
    }
    
    $post_id = intval($_POST['post_id']);
    $builder_data = get_post_meta($post_id, '_flexipro_visual_builder_data', true);
    
    wp_send_json_success($builder_data);
}

function flexipro_save_builder_data_ajax() {
    check_ajax_referer('flexipro_builder_nonce', 'nonce');
    
    if (!current_user_can('edit_posts')) {
        wp_send_json_error('Permission denied');
    }
    
    $post_id = intval($_POST['post_id']);
    $builder_data = json_decode(stripslashes($_POST['builder_data']), true);
    
    if (update_post_meta($post_id, '_flexipro_visual_builder_data', $builder_data)) {
        wp_send_json_success('Builder data saved successfully');
    } else {
        wp_send_json_error('Failed to save builder data');
    }
}

function flexipro_publish_post_ajax() {
    check_ajax_referer('flexipro_builder_nonce', 'nonce');
    
    if (!current_user_can('publish_posts')) {
        wp_send_json_error('Permission denied');
    }
    
    $post_id = intval($_POST['post_id']);
    $post = get_post($post_id);
    
    if (!$post) {
        wp_send_json_error('Post not found');
    }
    
    $result = wp_update_post(array(
        'ID' => $post_id,
        'post_status' => 'publish'
    ));
    
    if (is_wp_error($result)) {
        wp_send_json_error('Failed to publish post');
    }
    
    wp_send_json_success('Post published successfully');
}

function flexipro_create_demo_page_ajax() {
    // This will be handled by the FlexiPro_Demo_Import class
    $demo_import = new FlexiPro_Demo_Import();
    $demo_import->ajax_create_demo_page();
}

// Render visual builder content on frontend
function flexipro_render_visual_builder_content($content) {
    // Check if this is a page with visual builder data
    global $post;
    
    if (!$post || !is_singular()) {
        return $content;
    }
    
    $builder_data = get_post_meta($post->ID, '_flexipro_visual_builder_data', true);
    
    if (empty($builder_data) || !is_array($builder_data)) {
        return $content;
    }
    
    // Render visual builder content
    $frontend_renderer = new FlexiPro_Frontend_Renderer();
    $rendered_content = '';
    
    if (isset($builder_data['elements']) && is_array($builder_data['elements'])) {
        foreach ($builder_data['elements'] as $element) {
            $rendered_content .= $frontend_renderer->render_element($element);
        }
    }
    
    // If we have rendered content, use it instead of the default content
    if (!empty($rendered_content)) {
        return $rendered_content;
    }
    
    return $content;
}
add_filter('the_content', 'flexipro_render_visual_builder_content');
