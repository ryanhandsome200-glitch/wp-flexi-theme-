<?php
/**
 * Customizer Settings
 * 
 * @package FlexiPro
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

function flexipro_customize_register($wp_customize) {
    
    // Add Hero Section Panel
    $wp_customize->add_panel('flexipro_hero_panel', array(
        'title' => __('Hero Section', 'flexipro'),
        'priority' => 30,
    ));
    
    // Hero Section
    $wp_customize->add_section('flexipro_hero_section', array(
        'title' => __('Hero Settings', 'flexipro'),
        'panel' => 'flexipro_hero_panel',
        'priority' => 10,
    ));
    
    // Hero Title
    $wp_customize->add_setting('flexipro_hero_title', array(
        'default' => 'Welcome to FlexiPro',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('flexipro_hero_title', array(
        'label' => __('Hero Title', 'flexipro'),
        'section' => 'flexipro_hero_section',
        'type' => 'text',
    ));
    
    // Hero Subtitle
    $wp_customize->add_setting('flexipro_hero_subtitle', array(
        'default' => 'A powerful and flexible WordPress theme for modern websites',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('flexipro_hero_subtitle', array(
        'label' => __('Hero Subtitle', 'flexipro'),
        'section' => 'flexipro_hero_section',
        'type' => 'textarea',
    ));
    
    // Hero Button Text
    $wp_customize->add_setting('flexipro_hero_button_text', array(
        'default' => 'Get Started',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('flexipro_hero_button_text', array(
        'label' => __('Button Text', 'flexipro'),
        'section' => 'flexipro_hero_section',
        'type' => 'text',
    ));
    
    // Hero Button URL
    $wp_customize->add_setting('flexipro_hero_button_url', array(
        'default' => '#',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('flexipro_hero_button_url', array(
        'label' => __('Button URL', 'flexipro'),
        'section' => 'flexipro_hero_section',
        'type' => 'url',
    ));
    
    // Hero Background Image
    $wp_customize->add_setting('flexipro_hero_background', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'flexipro_hero_background', array(
        'label' => __('Background Image', 'flexipro'),
        'section' => 'flexipro_hero_section',
    )));
    
    // Add Typography Panel
    $wp_customize->add_panel('flexipro_typography_panel', array(
        'title' => __('Typography', 'flexipro'),
        'priority' => 40,
    ));
    
    // Body Typography
    $wp_customize->add_section('flexipro_body_typography', array(
        'title' => __('Body Typography', 'flexipro'),
        'panel' => 'flexipro_typography_panel',
        'priority' => 10,
    ));
    
    // Body Font Family
    $wp_customize->add_setting('flexipro_body_font', array(
        'default' => 'Inter',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('flexipro_body_font', array(
        'label' => __('Body Font Family', 'flexipro'),
        'section' => 'flexipro_body_typography',
        'type' => 'select',
        'choices' => array(
            'Inter' => 'Inter',
            'Roboto' => 'Roboto',
            'Open Sans' => 'Open Sans',
            'Lato' => 'Lato',
            'Montserrat' => 'Montserrat',
            'Poppins' => 'Poppins',
        ),
    ));
    
    // Body Font Size
    $wp_customize->add_setting('flexipro_body_font_size', array(
        'default' => 16,
        'sanitize_callback' => 'absint',
    ));
    
    $wp_customize->add_control('flexipro_body_font_size', array(
        'label' => __('Body Font Size (px)', 'flexipro'),
        'section' => 'flexipro_body_typography',
        'type' => 'number',
        'input_attrs' => array(
            'min' => 12,
            'max' => 24,
        ),
    ));
    
    // Heading Typography
    $wp_customize->add_section('flexipro_heading_typography', array(
        'title' => __('Heading Typography', 'flexipro'),
        'panel' => 'flexipro_typography_panel',
        'priority' => 20,
    ));
    
    // Heading Font Family
    $wp_customize->add_setting('flexipro_heading_font', array(
        'default' => 'Inter',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('flexipro_heading_font', array(
        'label' => __('Heading Font Family', 'flexipro'),
        'section' => 'flexipro_heading_typography',
        'type' => 'select',
        'choices' => array(
            'Inter' => 'Inter',
            'Roboto' => 'Roboto',
            'Open Sans' => 'Open Sans',
            'Lato' => 'Lato',
            'Montserrat' => 'Montserrat',
            'Poppins' => 'Poppins',
        ),
    ));
    
    // Add Colors Panel
    $wp_customize->add_panel('flexipro_colors_panel', array(
        'title' => __('Colors', 'flexipro'),
        'priority' => 50,
    ));
    
    // Primary Colors
    $wp_customize->add_section('flexipro_primary_colors', array(
        'title' => __('Primary Colors', 'flexipro'),
        'panel' => 'flexipro_colors_panel',
        'priority' => 10,
    ));
    
    // Primary Color
    $wp_customize->add_setting('flexipro_primary_color', array(
        'default' => '#007cba',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'flexipro_primary_color', array(
        'label' => __('Primary Color', 'flexipro'),
        'section' => 'flexipro_primary_colors',
    )));
    
    // Secondary Color
    $wp_customize->add_setting('flexipro_secondary_color', array(
        'default' => '#6c757d',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'flexipro_secondary_color', array(
        'label' => __('Secondary Color', 'flexipro'),
        'section' => 'flexipro_primary_colors',
    )));
    
    // Accent Color
    $wp_customize->add_setting('flexipro_accent_color', array(
        'default' => '#ff6b6b',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'flexipro_accent_color', array(
        'label' => __('Accent Color', 'flexipro'),
        'section' => 'flexipro_primary_colors',
    )));
    
    // Layout Settings
    $wp_customize->add_section('flexipro_layout_settings', array(
        'title' => __('Layout Settings', 'flexipro'),
        'priority' => 60,
    ));
    
    // Container Width
    $wp_customize->add_setting('flexipro_container_width', array(
        'default' => 1200,
        'sanitize_callback' => 'absint',
    ));
    
    $wp_customize->add_control('flexipro_container_width', array(
        'label' => __('Container Width (px)', 'flexipro'),
        'section' => 'flexipro_layout_settings',
        'type' => 'number',
        'input_attrs' => array(
            'min' => 960,
            'max' => 1600,
        ),
    ));
    
    // Sidebar Layout
    $wp_customize->add_setting('flexipro_sidebar_layout', array(
        'default' => 'right',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('flexipro_sidebar_layout', array(
        'label' => __('Sidebar Layout', 'flexipro'),
        'section' => 'flexipro_layout_settings',
        'type' => 'select',
        'choices' => array(
            'right' => __('Right Sidebar', 'flexipro'),
            'left' => __('Left Sidebar', 'flexipro'),
            'none' => __('No Sidebar', 'flexipro'),
        ),
    ));
    
    // Footer Settings
    $wp_customize->add_section('flexipro_footer_settings', array(
        'title' => __('Footer Settings', 'flexipro'),
        'priority' => 70,
    ));
    
    // Footer Copyright Text
    $wp_customize->add_setting('flexipro_footer_copyright', array(
        'default' => '© 2024 FlexiPro. All rights reserved.',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('flexipro_footer_copyright', array(
        'label' => __('Copyright Text', 'flexipro'),
        'section' => 'flexipro_footer_settings',
        'type' => 'text',
    ));
    
    // Social Media Links
    $wp_customize->add_section('flexipro_social_media', array(
        'title' => __('Social Media', 'flexipro'),
        'priority' => 80,
    ));
    
    // Facebook URL
    $wp_customize->add_setting('flexipro_facebook_url', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('flexipro_facebook_url', array(
        'label' => __('Facebook URL', 'flexipro'),
        'section' => 'flexipro_social_media',
        'type' => 'url',
    ));
    
    // Twitter URL
    $wp_customize->add_setting('flexipro_twitter_url', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('flexipro_twitter_url', array(
        'label' => __('Twitter URL', 'flexipro'),
        'section' => 'flexipro_social_media',
        'type' => 'url',
    ));
    
    // Instagram URL
    $wp_customize->add_setting('flexipro_instagram_url', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('flexipro_instagram_url', array(
        'label' => __('Instagram URL', 'flexipro'),
        'section' => 'flexipro_social_media',
        'type' => 'url',
    ));
    
    // LinkedIn URL
    $wp_customize->add_setting('flexipro_linkedin_url', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('flexipro_linkedin_url', array(
        'label' => __('LinkedIn URL', 'flexipro'),
        'section' => 'flexipro_social_media',
        'type' => 'url',
    ));
}

add_action('customize_register', 'flexipro_customize_register');

// Output custom CSS
function flexipro_customize_css() {
    $primary_color = get_theme_mod('flexipro_primary_color', '#007cba');
    $secondary_color = get_theme_mod('flexipro_secondary_color', '#6c757d');
    $accent_color = get_theme_mod('flexipro_accent_color', '#ff6b6b');
    $body_font = get_theme_mod('flexipro_body_font', 'Inter');
    $heading_font = get_theme_mod('flexipro_heading_font', 'Inter');
    $body_font_size = get_theme_mod('flexipro_body_font_size', 16);
    $container_width = get_theme_mod('flexipro_container_width', 1200);
    ?>
    <style type="text/css">
        :root {
            --primary-color: <?php echo esc_attr($primary_color); ?>;
            --secondary-color: <?php echo esc_attr($secondary_color); ?>;
            --accent-color: <?php echo esc_attr($accent_color); ?>;
            --body-font: '<?php echo esc_attr($body_font); ?>', sans-serif;
            --heading-font: '<?php echo esc_attr($heading_font); ?>', sans-serif;
            --body-font-size: <?php echo esc_attr($body_font_size); ?>px;
        }
        
        body {
            font-family: var(--body-font);
            font-size: var(--body-font-size);
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: var(--heading-font);
        }
        
        .container {
            max-width: <?php echo esc_attr($container_width); ?>px;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
        }
        
        .btn-outline {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-outline:hover {
            background-color: var(--primary-color);
            color: #fff;
        }
        
        a {
            color: var(--primary-color);
        }
        
        a:hover {
            color: var(--secondary-color);
        }
    </style>
    <?php
}
add_action('wp_head', 'flexipro_customize_css');
