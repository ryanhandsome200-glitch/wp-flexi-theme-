<?php
/**
 * Flexi Theme by RWB Ultimate 1.0 Frontend Renderer
 * Handles rendering of visual builder elements on the frontend
 *
 * @package FlexiPro
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class FlexiPro_Frontend_Renderer {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('wp_head', array($this, 'add_frontend_styles'));
        add_shortcode('flexipro_element', array($this, 'render_element_shortcode'));
    }
    
    public function enqueue_frontend_assets() {
        wp_enqueue_style(
            'flexipro-frontend-builder',
            FLEXIPRO_THEME_URL . '/css/frontend-builder.css',
            array(),
            FLEXIPRO_VERSION
        );
        
        wp_enqueue_script(
            'flexipro-frontend-builder',
            FLEXIPRO_THEME_URL . '/js/frontend-builder.js',
            array('jquery'),
            FLEXIPRO_VERSION,
            true
        );
    }
    
    public function add_frontend_styles() {
        // Add dynamic styles for visual builder elements
        $this->render_dynamic_styles();
    }
    
    public function render_element_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => '',
            'type' => '',
            'content' => '',
            'settings' => ''
        ), $atts);
        
        if (empty($atts['id']) || empty($atts['type'])) {
            return '';
        }
        
        $element_data = array(
            'id' => $atts['id'],
            'type' => $atts['type'],
            'data' => array(
                'content' => $atts['content'],
                'settings' => json_decode($atts['settings'], true)
            )
        );
        
        return $this->render_element($element_data);
    }
    
    public function render_element($element) {
        if (empty($element['type'])) {
            return '';
        }
        
        $type = $element['type'];
        $data = isset($element['data']) ? $element['data'] : array();
        $content = isset($data['content']) ? $data['content'] : '';
        $settings = isset($data['settings']) ? $data['settings'] : array();
        
        $element_id = isset($element['id']) ? $element['id'] : 'element_' . uniqid();
        
        ob_start();
        
        switch ($type) {
            case 'heading':
                $this->render_heading($content, $settings, $element_id);
                break;
            case 'text':
                $this->render_text($content, $settings, $element_id);
                break;
            case 'button':
                $this->render_button($content, $settings, $element_id);
                break;
            case 'image':
                $this->render_image($content, $settings, $element_id);
                break;
            case 'video':
                $this->render_video($content, $settings, $element_id);
                break;
            case 'spacer':
                $this->render_spacer($settings, $element_id);
                break;
            case 'container':
                $this->render_container($content, $settings, $element_id);
                break;
            case 'row':
                $this->render_row($content, $settings, $element_id);
                break;
            case 'column':
                $this->render_column($content, $settings, $element_id);
                break;
            case 'section':
                $this->render_section($content, $settings, $element_id);
                break;
            default:
                echo '<div class="flexipro-element flexipro-element-' . esc_attr($type) . '" data-id="' . esc_attr($element_id) . '">' . wp_kses_post($content) . '</div>';
        }
        
        return ob_get_clean();
    }
    
    private function render_heading($content, $settings, $element_id) {
        $level = isset($settings['level']) ? intval($settings['level']) : 1;
        $level = max(1, min(6, $level)); // Ensure level is between 1-6
        
        $classes = array('flexipro-heading', 'flexipro-element');
        $styles = array();
        
        // Color
        if (isset($settings['color'])) {
            $styles[] = 'color: ' . esc_attr($settings['color']);
        }
        
        // Background color
        if (isset($settings['bg_color'])) {
            $styles[] = 'background-color: ' . esc_attr($settings['bg_color']);
        }
        
        // Font size
        if (isset($settings['font_size'])) {
            $styles[] = 'font-size: ' . esc_attr($settings['font_size']);
        }
        
        // Text align
        if (isset($settings['text_align'])) {
            $styles[] = 'text-align: ' . esc_attr($settings['text_align']);
        }
        
        // Padding
        if (isset($settings['padding'])) {
            $styles[] = 'padding: ' . esc_attr($settings['padding']);
        }
        
        // Margin
        if (isset($settings['margin'])) {
            $styles[] = 'margin: ' . esc_attr($settings['margin']);
        }
        
        $class_string = implode(' ', $classes);
        $style_string = implode('; ', $styles);
        
        echo '<h' . $level . ' class="' . esc_attr($class_string) . '" data-id="' . esc_attr($element_id) . '"';
        if (!empty($style_string)) {
            echo ' style="' . esc_attr($style_string) . '"';
        }
        echo '>' . wp_kses_post($content) . '</h' . $level . '>';
    }
    
    private function render_text($content, $settings, $element_id) {
        $classes = array('flexipro-text', 'flexipro-element');
        $styles = array();
        
        // Color
        if (isset($settings['color'])) {
            $styles[] = 'color: ' . esc_attr($settings['color']);
        }
        
        // Font size
        if (isset($settings['font_size'])) {
            $styles[] = 'font-size: ' . esc_attr($settings['font_size']);
        }
        
        // Text align
        if (isset($settings['text_align'])) {
            $styles[] = 'text-align: ' . esc_attr($settings['text_align']);
        }
        
        // Line height
        if (isset($settings['line_height'])) {
            $styles[] = 'line-height: ' . esc_attr($settings['line_height']);
        }
        
        // Padding
        if (isset($settings['padding'])) {
            $styles[] = 'padding: ' . esc_attr($settings['padding']);
        }
        
        // Margin
        if (isset($settings['margin'])) {
            $styles[] = 'margin: ' . esc_attr($settings['margin']);
        }
        
        $class_string = implode(' ', $classes);
        $style_string = implode('; ', $styles);
        
        echo '<div class="' . esc_attr($class_string) . '" data-id="' . esc_attr($element_id) . '"';
        if (!empty($style_string)) {
            echo ' style="' . esc_attr($style_string) . '"';
        }
        echo '>' . wp_kses_post($content) . '</div>';
    }
    
    private function render_button($content, $settings, $element_id) {
        $classes = array('flexipro-button', 'flexipro-element');
        $styles = array();
        
        // Button style
        $button_style = isset($settings['button_style']) ? $settings['button_style'] : 'primary';
        $classes[] = 'btn-' . esc_attr($button_style);
        
        // Background color
        if (isset($settings['bg_color'])) {
            $styles[] = 'background-color: ' . esc_attr($settings['bg_color']);
        }
        
        // Text color
        if (isset($settings['color'])) {
            $styles[] = 'color: ' . esc_attr($settings['color']);
        }
        
        // Font size
        if (isset($settings['font_size'])) {
            $styles[] = 'font-size: ' . esc_attr($settings['font_size']);
        }
        
        // Padding
        if (isset($settings['padding'])) {
            $styles[] = 'padding: ' . esc_attr($settings['padding']);
        }
        
        // Border radius
        if (isset($settings['border_radius'])) {
            $styles[] = 'border-radius: ' . esc_attr($settings['border_radius']);
        }
        
        // Width
        if (isset($settings['width'])) {
            $styles[] = 'width: ' . esc_attr($settings['width']);
        }
        
        $class_string = implode(' ', $classes);
        $style_string = implode('; ', $styles);
        
        $url = isset($settings['url']) ? esc_url($settings['url']) : '#';
        $target = isset($settings['target']) && $settings['target'] === 'blank' ? ' target="_blank"' : '';
        
        echo '<a href="' . $url . '" class="' . esc_attr($class_string) . '" data-id="' . esc_attr($element_id) . '"' . $target;
        if (!empty($style_string)) {
            echo ' style="' . esc_attr($style_string) . '"';
        }
        echo '>' . wp_kses_post($content) . '</a>';
    }
    
    private function render_image($content, $settings, $element_id) {
        $classes = array('flexipro-image', 'flexipro-element');
        $styles = array();
        
        // Width
        if (isset($settings['width'])) {
            $styles[] = 'width: ' . esc_attr($settings['width']);
        }
        
        // Height
        if (isset($settings['height'])) {
            $styles[] = 'height: ' . esc_attr($settings['height']);
        }
        
        // Border radius
        if (isset($settings['border_radius'])) {
            $styles[] = 'border-radius: ' . esc_attr($settings['border_radius']);
        }
        
        // Margin
        if (isset($settings['margin'])) {
            $styles[] = 'margin: ' . esc_attr($settings['margin']);
        }
        
        $class_string = implode(' ', $classes);
        $style_string = implode('; ', $styles);
        
        $alt = isset($settings['alt']) ? esc_attr($settings['alt']) : '';
        $title = isset($settings['title']) ? esc_attr($settings['title']) : '';
        
        echo '<img src="' . esc_url($content) . '" alt="' . $alt . '" title="' . $title . '" class="' . esc_attr($class_string) . '" data-id="' . esc_attr($element_id) . '"';
        if (!empty($style_string)) {
            echo ' style="' . esc_attr($style_string) . '"';
        }
        echo '>';
    }
    
    private function render_video($content, $settings, $element_id) {
        $classes = array('flexipro-video', 'flexipro-element');
        $styles = array();
        
        // Width
        if (isset($settings['width'])) {
            $styles[] = 'width: ' . esc_attr($settings['width']);
        }
        
        // Height
        if (isset($settings['height'])) {
            $styles[] = 'height: ' . esc_attr($settings['height']);
        }
        
        // Margin
        if (isset($settings['margin'])) {
            $styles[] = 'margin: ' . esc_attr($settings['margin']);
        }
        
        $class_string = implode(' ', $classes);
        $style_string = implode('; ', $styles);
        
        $autoplay = isset($settings['autoplay']) && $settings['autoplay'] ? ' autoplay' : '';
        $controls = isset($settings['controls']) && $settings['controls'] ? ' controls' : '';
        $loop = isset($settings['loop']) && $settings['loop'] ? ' loop' : '';
        
        echo '<video class="' . esc_attr($class_string) . '" data-id="' . esc_attr($element_id) . '"' . $autoplay . $controls . $loop;
        if (!empty($style_string)) {
            echo ' style="' . esc_attr($style_string) . '"';
        }
        echo '>';
        echo '<source src="' . esc_url($content) . '" type="video/mp4">';
        echo 'Your browser does not support the video tag.';
        echo '</video>';
    }
    
    private function render_spacer($settings, $element_id) {
        $height = isset($settings['height']) ? esc_attr($settings['height']) : '20px';
        echo '<div class="flexipro-spacer flexipro-element" data-id="' . esc_attr($element_id) . '" style="height: ' . $height . ';"></div>';
    }
    
    private function render_container($content, $settings, $element_id) {
        $classes = array('flexipro-container', 'flexipro-element');
        $styles = array();
        
        // Background color
        if (isset($settings['bg_color'])) {
            $styles[] = 'background-color: ' . esc_attr($settings['bg_color']);
        }
        
        // Padding
        if (isset($settings['padding'])) {
            $styles[] = 'padding: ' . esc_attr($settings['padding']);
        }
        
        // Margin
        if (isset($settings['margin'])) {
            $styles[] = 'margin: ' . esc_attr($settings['margin']);
        }
        
        // Border
        if (isset($settings['border'])) {
            $styles[] = 'border: ' . esc_attr($settings['border']);
        }
        
        // Border radius
        if (isset($settings['border_radius'])) {
            $styles[] = 'border-radius: ' . esc_attr($settings['border_radius']);
        }
        
        $class_string = implode(' ', $classes);
        $style_string = implode('; ', $styles);
        
        echo '<div class="' . esc_attr($class_string) . '" data-id="' . esc_attr($element_id) . '"';
        if (!empty($style_string)) {
            echo ' style="' . esc_attr($style_string) . '"';
        }
        echo '>';
        echo wp_kses_post($content);
        echo '</div>';
    }
    
    private function render_row($content, $settings, $element_id) {
        $classes = array('flexipro-row', 'flexipro-element');
        $styles = array();
        
        // Background color
        if (isset($settings['bg_color'])) {
            $styles[] = 'background-color: ' . esc_attr($settings['bg_color']);
        }
        
        // Padding
        if (isset($settings['padding'])) {
            $styles[] = 'padding: ' . esc_attr($settings['padding']);
        }
        
        // Margin
        if (isset($settings['margin'])) {
            $styles[] = 'margin: ' . esc_attr($settings['margin']);
        }
        
        // Gap
        if (isset($settings['gap'])) {
            $styles[] = 'gap: ' . esc_attr($settings['gap']);
        }
        
        $class_string = implode(' ', $classes);
        $style_string = implode('; ', $styles);
        
        echo '<div class="' . esc_attr($class_string) . '" data-id="' . esc_attr($element_id) . '"';
        if (!empty($style_string)) {
            echo ' style="' . esc_attr($style_string) . '"';
        }
        echo '>';
        echo wp_kses_post($content);
        echo '</div>';
    }
    
    private function render_column($content, $settings, $element_id) {
        $classes = array('flexipro-column', 'flexipro-element');
        $styles = array();
        
        // Width
        if (isset($settings['width'])) {
            $width = intval($settings['width']);
            $percentage = ($width / 12) * 100;
            $styles[] = 'flex: 0 0 ' . $percentage . '%';
        }
        
        // Background color
        if (isset($settings['bg_color'])) {
            $styles[] = 'background-color: ' . esc_attr($settings['bg_color']);
        }
        
        // Padding
        if (isset($settings['padding'])) {
            $styles[] = 'padding: ' . esc_attr($settings['padding']);
        }
        
        // Margin
        if (isset($settings['margin'])) {
            $styles[] = 'margin: ' . esc_attr($settings['margin']);
        }
        
        // Border
        if (isset($settings['border'])) {
            $styles[] = 'border: ' . esc_attr($settings['border']);
        }
        
        // Border radius
        if (isset($settings['border_radius'])) {
            $styles[] = 'border-radius: ' . esc_attr($settings['border_radius']);
        }
        
        $class_string = implode(' ', $classes);
        $style_string = implode('; ', $styles);
        
        echo '<div class="' . esc_attr($class_string) . '" data-id="' . esc_attr($element_id) . '" data-width="' . esc_attr($settings['width'] ?? '12') . '"';
        if (!empty($style_string)) {
            echo ' style="' . esc_attr($style_string) . '"';
        }
        echo '>';
        echo wp_kses_post($content);
        echo '</div>';
    }
    
    private function render_section($content, $settings, $element_id) {
        $classes = array('flexipro-section', 'flexipro-element');
        $styles = array();
        
        // Background color
        if (isset($settings['bg_color'])) {
            $styles[] = 'background-color: ' . esc_attr($settings['bg_color']);
        }
        
        // Padding
        if (isset($settings['padding'])) {
            $styles[] = 'padding: ' . esc_attr($settings['padding']);
        }
        
        // Margin
        if (isset($settings['margin'])) {
            $styles[] = 'margin: ' . esc_attr($settings['margin']);
        }
        
        // Min height
        if (isset($settings['min_height'])) {
            $styles[] = 'min-height: ' . esc_attr($settings['min_height']);
        }
        
        $class_string = implode(' ', $classes);
        $style_string = implode('; ', $styles);
        
        echo '<section class="' . esc_attr($class_string) . '" data-id="' . esc_attr($element_id) . '"';
        if (!empty($style_string)) {
            echo ' style="' . esc_attr($style_string) . '"';
        }
        echo '>';
        echo wp_kses_post($content);
        echo '</section>';
    }
    
    private function render_dynamic_styles() {
        // This will be used to add dynamic CSS for visual builder elements
        echo '<style id="flexipro-dynamic-styles">';
        echo '.flexipro-element { position: relative; }';
        echo '.flexipro-row { display: flex; flex-wrap: wrap; }';
        echo '.flexipro-column { flex: 1; }';
        echo '.flexipro-section { width: 100%; }';
        echo '.flexipro-container { width: 100%; }';
        echo '</style>';
    }
}

// Initialize frontend renderer
new FlexiPro_Frontend_Renderer();
