<?php
/**
 * Portfolio Functionality
 * 
 * @package FlexiPro
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Register Portfolio Post Type
function flexipro_portfolio_post_type() {
    $labels = array(
        'name' => __('Portfolio', 'flexipro'),
        'singular_name' => __('Portfolio Item', 'flexipro'),
        'add_new' => __('Add New', 'flexipro'),
        'add_new_item' => __('Add New Portfolio Item', 'flexipro'),
        'edit_item' => __('Edit Portfolio Item', 'flexipro'),
        'new_item' => __('New Portfolio Item', 'flexipro'),
        'view_item' => __('View Portfolio Item', 'flexipro'),
        'search_items' => __('Search Portfolio Items', 'flexipro'),
        'not_found' => __('No portfolio items found', 'flexipro'),
        'not_found_in_trash' => __('No portfolio items found in trash', 'flexipro'),
        'menu_name' => __('Portfolio', 'flexipro'),
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'portfolio'),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-portfolio',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'show_in_rest' => true,
    );

    register_post_type('portfolio', $args);
}
add_action('init', 'flexipro_portfolio_post_type');

// Register Portfolio Categories
function flexipro_portfolio_taxonomies() {
    $labels = array(
        'name' => __('Portfolio Categories', 'flexipro'),
        'singular_name' => __('Portfolio Category', 'flexipro'),
        'search_items' => __('Search Categories', 'flexipro'),
        'all_items' => __('All Categories', 'flexipro'),
        'parent_item' => __('Parent Category', 'flexipro'),
        'parent_item_colon' => __('Parent Category:', 'flexipro'),
        'edit_item' => __('Edit Category', 'flexipro'),
        'update_item' => __('Update Category', 'flexipro'),
        'add_new_item' => __('Add New Category', 'flexipro'),
        'new_item_name' => __('New Category Name', 'flexipro'),
        'menu_name' => __('Categories', 'flexipro'),
    );

    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'portfolio-category'),
        'show_in_rest' => true,
    );

    register_taxonomy('portfolio_category', 'portfolio', $args);
}
add_action('init', 'flexipro_portfolio_taxonomies');

// Add Portfolio Meta Boxes
function flexipro_portfolio_meta_boxes() {
    add_meta_box(
        'portfolio_details',
        __('Portfolio Details', 'flexipro'),
        'flexipro_portfolio_meta_box_callback',
        'portfolio',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'flexipro_portfolio_meta_boxes');

function flexipro_portfolio_meta_box_callback($post) {
    wp_nonce_field('flexipro_portfolio_meta_box', 'flexipro_portfolio_meta_box_nonce');
    
    $client = get_post_meta($post->ID, '_portfolio_client', true);
    $date = get_post_meta($post->ID, '_portfolio_date', true);
    $url = get_post_meta($post->ID, '_portfolio_url', true);
    $skills = get_post_meta($post->ID, '_portfolio_skills', true);
    $gallery = get_post_meta($post->ID, '_portfolio_gallery', true);
    ?>
    <table class="form-table">
        <tr>
            <th><label for="portfolio_client"><?php _e('Client', 'flexipro'); ?></label></th>
            <td><input type="text" id="portfolio_client" name="portfolio_client" value="<?php echo esc_attr($client); ?>" class="regular-text" /></td>
        </tr>
        <tr>
            <th><label for="portfolio_date"><?php _e('Project Date', 'flexipro'); ?></label></th>
            <td><input type="date" id="portfolio_date" name="portfolio_date" value="<?php echo esc_attr($date); ?>" class="regular-text" /></td>
        </tr>
        <tr>
            <th><label for="portfolio_url"><?php _e('Project URL', 'flexipro'); ?></label></th>
            <td><input type="url" id="portfolio_url" name="portfolio_url" value="<?php echo esc_attr($url); ?>" class="regular-text" /></td>
        </tr>
        <tr>
            <th><label for="portfolio_skills"><?php _e('Skills Used', 'flexipro'); ?></label></th>
            <td><input type="text" id="portfolio_skills" name="portfolio_skills" value="<?php echo esc_attr($skills); ?>" class="regular-text" placeholder="e.g., WordPress, PHP, JavaScript" /></td>
        </tr>
        <tr>
            <th><label for="portfolio_gallery"><?php _e('Gallery Images', 'flexipro'); ?></label></th>
            <td>
                <input type="hidden" id="portfolio_gallery" name="portfolio_gallery" value="<?php echo esc_attr($gallery); ?>" />
                <button type="button" class="button upload-gallery"><?php _e('Select Images', 'flexipro'); ?></button>
                <div class="gallery-preview"></div>
            </td>
        </tr>
    </table>
    <?php
}

// Save Portfolio Meta Box
function flexipro_save_portfolio_meta_box($post_id) {
    if (!isset($_POST['flexipro_portfolio_meta_box_nonce']) || !wp_verify_nonce($_POST['flexipro_portfolio_meta_box_nonce'], 'flexipro_portfolio_meta_box')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (isset($_POST['portfolio_client'])) {
        update_post_meta($post_id, '_portfolio_client', sanitize_text_field($_POST['portfolio_client']));
    }

    if (isset($_POST['portfolio_date'])) {
        update_post_meta($post_id, '_portfolio_date', sanitize_text_field($_POST['portfolio_date']));
    }

    if (isset($_POST['portfolio_url'])) {
        update_post_meta($post_id, '_portfolio_url', esc_url_raw($_POST['portfolio_url']));
    }

    if (isset($_POST['portfolio_skills'])) {
        update_post_meta($post_id, '_portfolio_skills', sanitize_text_field($_POST['portfolio_skills']));
    }

    if (isset($_POST['portfolio_gallery'])) {
        update_post_meta($post_id, '_portfolio_gallery', sanitize_text_field($_POST['portfolio_gallery']));
    }
}
add_action('save_post', 'flexipro_save_portfolio_meta_box');

// Portfolio Shortcode
function flexipro_portfolio_shortcode($atts) {
    $atts = shortcode_atts(array(
        'posts_per_page' => '6',
        'columns' => '3',
        'filter' => 'true',
        'lightbox' => 'true',
        'hover_effect' => 'zoom',
        'show_title' => 'true',
        'show_excerpt' => 'true',
        'show_categories' => 'true',
        'category' => '',
        'class' => ''
    ), $atts);

    $args = array(
        'post_type' => 'portfolio',
        'posts_per_page' => intval($atts['posts_per_page']),
        'post_status' => 'publish'
    );

    if (!empty($atts['category'])) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'portfolio_category',
                'field' => 'slug',
                'terms' => $atts['category']
            )
        );
    }

    $query = new WP_Query($args);

    ob_start();
    ?>
    <div class="flexipro-portfolio <?php echo esc_attr($atts['class']); ?>" data-columns="<?php echo esc_attr($atts['columns']); ?>">
        <?php if ($atts['filter'] === 'true'): ?>
            <div class="portfolio-filter">
                <button class="filter-btn active" data-filter="*"><?php _e('All', 'flexipro'); ?></button>
                <?php
                $categories = get_terms(array(
                    'taxonomy' => 'portfolio_category',
                    'hide_empty' => true
                ));
                foreach ($categories as $category):
                ?>
                    <button class="filter-btn" data-filter=".<?php echo esc_attr($category->slug); ?>"><?php echo esc_html($category->name); ?></button>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="portfolio-grid">
            <?php if ($query->have_posts()): ?>
                <?php while ($query->have_posts()): $query->the_post(); ?>
                    <?php
                    $post_id = get_the_ID();
                    $categories = get_the_terms($post_id, 'portfolio_category');
                    $category_classes = '';
                    if ($categories) {
                        foreach ($categories as $category) {
                            $category_classes .= ' ' . $category->slug;
                        }
                    }
                    ?>
                    <div class="portfolio-item<?php echo $category_classes; ?>">
                        <?php if (has_post_thumbnail()): ?>
                            <div class="portfolio-image">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail('flexipro-portfolio-thumb'); ?>
                                </a>
                                <?php if ($atts['lightbox'] === 'true'): ?>
                                    <?php $full_image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full'); ?>
                                    <a href="<?php echo esc_url($full_image[0]); ?>" class="portfolio-lightbox" data-lightbox="portfolio">
                                        <i class="fas fa-search-plus"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($atts['show_title'] === 'true' || $atts['show_excerpt'] === 'true' || $atts['show_categories'] === 'true'): ?>
                            <div class="portfolio-content">
                                <?php if ($atts['show_title'] === 'true'): ?>
                                    <h3 class="portfolio-title">
                                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                    </h3>
                                <?php endif; ?>

                                <?php if ($atts['show_categories'] === 'true' && $categories): ?>
                                    <div class="portfolio-categories">
                                        <?php foreach ($categories as $category): ?>
                                            <span class="portfolio-category"><?php echo esc_html($category->name); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ($atts['show_excerpt'] === 'true'): ?>
                                    <div class="portfolio-excerpt"><?php the_excerpt(); ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php
    wp_reset_postdata();
    return ob_get_clean();
}
add_shortcode('flexipro_portfolio', 'flexipro_portfolio_shortcode');

// Portfolio Filter AJAX
add_action('wp_ajax_flexipro_portfolio_filter', 'flexipro_portfolio_filter_ajax');
add_action('wp_ajax_nopriv_flexipro_portfolio_filter', 'flexipro_portfolio_filter_ajax');

function flexipro_portfolio_filter_ajax() {
    $category = sanitize_text_field($_POST['category']);
    $posts_per_page = intval($_POST['posts_per_page']);
    
    $args = array(
        'post_type' => 'portfolio',
        'posts_per_page' => $posts_per_page,
        'post_status' => 'publish'
    );
    
    if ($category !== '*') {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'portfolio_category',
                'field' => 'slug',
                'terms' => $category
            )
        );
    }
    
    $query = new WP_Query($args);
    
    ob_start();
    
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $post_id = get_the_ID();
            $categories = get_the_terms($post_id, 'portfolio_category');
            $category_classes = '';
            if ($categories) {
                foreach ($categories as $cat) {
                    $category_classes .= ' ' . $cat->slug;
                }
            }
            ?>
            <div class="portfolio-item<?php echo $category_classes; ?>">
                <?php if (has_post_thumbnail()): ?>
                    <div class="portfolio-image">
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail('flexipro-portfolio-thumb'); ?>
                        </a>
                        <a href="<?php echo wp_get_attachment_image_src(get_post_thumbnail_id(), 'full')[0]; ?>" class="portfolio-lightbox" data-lightbox="portfolio">
                            <i class="fas fa-search-plus"></i>
                        </a>
                    </div>
                <?php endif; ?>
                <div class="portfolio-content">
                    <h3 class="portfolio-title">
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h3>
                    <?php if ($categories): ?>
                        <div class="portfolio-categories">
                            <?php foreach ($categories as $cat): ?>
                                <span class="portfolio-category"><?php echo esc_html($cat->name); ?></span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <div class="portfolio-excerpt"><?php the_excerpt(); ?></div>
                </div>
            </div>
            <?php
        }
    }
    
    wp_reset_postdata();
    
    wp_send_json_success(ob_get_clean());
}

// Portfolio Widget
class FlexiPro_Portfolio_Widget extends WP_Widget {
    
    public function __construct() {
        parent::__construct(
            'flexipro_portfolio_widget',
            __('FlexiPro Portfolio', 'flexipro'),
            array('description' => __('Display recent portfolio items', 'flexipro'))
        );
    }
    
    public function widget($args, $instance) {
        $title = apply_filters('widget_title', $instance['title']);
        $number = !empty($instance['number']) ? $instance['number'] : 3;
        $show_thumbnail = !empty($instance['show_thumbnail']) ? true : false;
        
        echo $args['before_widget'];
        
        if (!empty($title)) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
        
        $query_args = array(
            'post_type' => 'portfolio',
            'posts_per_page' => $number,
            'post_status' => 'publish'
        );
        
        $recent_portfolio = new WP_Query($query_args);
        
        if ($recent_portfolio->have_posts()) {
            echo '<div class="flexipro-portfolio-widget">';
            while ($recent_portfolio->have_posts()) {
                $recent_portfolio->the_post();
                echo '<div class="portfolio-widget-item">';
                
                if ($show_thumbnail && has_post_thumbnail()) {
                    echo '<div class="portfolio-widget-thumbnail">';
                    echo '<a href="' . get_permalink() . '">';
                    the_post_thumbnail('thumbnail');
                    echo '</a>';
                    echo '</div>';
                }
                
                echo '<div class="portfolio-widget-content">';
                echo '<h4 class="portfolio-widget-title"><a href="' . get_permalink() . '">' . get_the_title() . '</a></h4>';
                echo '<div class="portfolio-widget-excerpt">' . wp_trim_words(get_the_excerpt(), 15) . '</div>';
                echo '</div>';
                echo '</div>';
            }
            echo '</div>';
        }
        
        wp_reset_postdata();
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : '';
        $number = !empty($instance['number']) ? $instance['number'] : 3;
        $show_thumbnail = !empty($instance['show_thumbnail']) ? true : false;
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'flexipro'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('number'); ?>"><?php _e('Number of items:', 'flexipro'); ?></label>
            <input class="tiny-text" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="number" value="<?php echo esc_attr($number); ?>" min="1" max="10">
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_thumbnail); ?> id="<?php echo $this->get_field_id('show_thumbnail'); ?>" name="<?php echo $this->get_field_name('show_thumbnail'); ?>">
            <label for="<?php echo $this->get_field_id('show_thumbnail'); ?>"><?php _e('Show thumbnail', 'flexipro'); ?></label>
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        $instance['number'] = (!empty($new_instance['number'])) ? absint($new_instance['number']) : 3;
        $instance['show_thumbnail'] = !empty($new_instance['show_thumbnail']);
        return $instance;
    }
}

// Register Portfolio Widget
function flexipro_register_portfolio_widget() {
    register_widget('FlexiPro_Portfolio_Widget');
}
add_action('widgets_init', 'flexipro_register_portfolio_widget');
