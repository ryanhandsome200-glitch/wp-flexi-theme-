/**
 * Flexi Theme by RWB Ultimate 1.0 Frontend Builder JavaScript
 * Handles frontend functionality for visual builder elements
 *
 * @package FlexiPro
 * @version 1.0.0
 */

(function($) {
    'use strict';
    
    var FlexiProFrontend = {
        
        init: function() {
            this.bindEvents();
            this.initAnimations();
            this.initResponsive();
        },
        
        bindEvents: function() {
            // Button click events
            $(document).on('click', '.flexipro-button', function(e) {
                var $button = $(this);
                var url = $button.attr('href');
                
                if (url && url !== '#') {
                    // Add click animation
                    $button.addClass('clicked');
                    setTimeout(function() {
                        $button.removeClass('clicked');
                    }, 200);
                }
            });
            
            // Image lazy loading
            this.initLazyLoading();
            
            // Video controls
            this.initVideoControls();
            
            // Responsive handling
            $(window).on('resize', this.debounce(this.handleResize, 250));
        },
        
        initAnimations: function() {
            // Intersection Observer for animations
            if ('IntersectionObserver' in window) {
                var observer = new IntersectionObserver(function(entries) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            var $element = $(entry.target);
                            var animation = $element.data('animation');
                            
                            if (animation) {
                                $element.addClass(animation);
                            }
                        }
                    });
                }, {
                    threshold: 0.1,
                    rootMargin: '0px 0px -50px 0px'
                });
                
                $('.flexipro-element[data-animation]').each(function() {
                    observer.observe(this);
                });
            }
        },
        
        initLazyLoading: function() {
            if ('IntersectionObserver' in window) {
                var imageObserver = new IntersectionObserver(function(entries) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            var $img = $(entry.target);
                            var src = $img.data('src');
                            
                            if (src) {
                                $img.attr('src', src);
                                $img.removeClass('lazy');
                                imageObserver.unobserve(entry.target);
                            }
                        }
                    });
                });
                
                $('.flexipro-image img[data-src]').each(function() {
                    imageObserver.observe(this);
                });
            }
        },
        
        initVideoControls: function() {
            $('.flexipro-video video').each(function() {
                var $video = $(this);
                var $container = $video.closest('.flexipro-video');
                
                // Add custom controls if needed
                if (!$video.attr('controls')) {
                    $video.on('click', function() {
                        if (this.paused) {
                            this.play();
                        } else {
                            this.pause();
                        }
                    });
                }
                
                // Add loading state
                $video.on('loadstart', function() {
                    $container.addClass('loading');
                });
                
                $video.on('canplay', function() {
                    $container.removeClass('loading');
                });
            });
        },
        
        initResponsive: function() {
            this.handleResize();
        },
        
        handleResize: function() {
            // Handle responsive column adjustments
            $('.flexipro-row').each(function() {
                var $row = $(this);
                var $columns = $row.find('.flexipro-column');
                
                // Check if we need to stack columns
                if ($(window).width() <= 768) {
                    $columns.addClass('stacked');
                } else {
                    $columns.removeClass('stacked');
                }
            });
        },
        
        // Utility function for debouncing
        debounce: function(func, wait, immediate) {
            var timeout;
            return function() {
                var context = this, args = arguments;
                var later = function() {
                    timeout = null;
                    if (!immediate) func.apply(context, args);
                };
                var callNow = immediate && !timeout;
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
                if (callNow) func.apply(context, args);
            };
        },
        
        // Method to update element content
        updateElement: function(elementId, newContent, newSettings) {
            var $element = $('.flexipro-element[data-id="' + elementId + '"]');
            
            if ($element.length) {
                // Update content
                if (newContent !== undefined) {
                    $element.html(newContent);
                }
                
                // Update settings/styles
                if (newSettings) {
                    this.applySettings($element, newSettings);
                }
                
                // Trigger update event
                $element.trigger('flexipro:updated');
            }
        },
        
        // Method to apply settings to an element
        applySettings: function($element, settings) {
            var styles = {};
            
            // Map settings to CSS properties
            if (settings.color) styles.color = settings.color;
            if (settings.bg_color) styles.backgroundColor = settings.bg_color;
            if (settings.font_size) styles.fontSize = settings.font_size;
            if (settings.text_align) styles.textAlign = settings.text_align;
            if (settings.padding) styles.padding = settings.padding;
            if (settings.margin) styles.margin = settings.margin;
            if (settings.width) styles.width = settings.width;
            if (settings.height) styles.height = settings.height;
            if (settings.border_radius) styles.borderRadius = settings.border_radius;
            if (settings.line_height) styles.lineHeight = settings.line_height;
            
            // Apply styles
            $element.css(styles);
            
            // Apply classes
            if (settings.classes) {
                $element.attr('class', settings.classes);
            }
        },
        
        // Method to get element data
        getElementData: function(elementId) {
            var $element = $('.flexipro-element[data-id="' + elementId + '"]');
            
            if ($element.length) {
                return {
                    id: elementId,
                    type: $element.data('type'),
                    content: $element.html(),
                    settings: this.extractSettings($element)
                };
            }
            
            return null;
        },
        
        // Method to extract settings from element
        extractSettings: function($element) {
            var settings = {};
            var styles = $element.css([
                'color', 'backgroundColor', 'fontSize', 'textAlign', 
                'padding', 'margin', 'width', 'height', 'borderRadius', 'lineHeight'
            ]);
            
            // Map CSS properties back to settings
            if (styles.color) settings.color = styles.color;
            if (styles.backgroundColor) settings.bg_color = styles.backgroundColor;
            if (styles.fontSize) settings.font_size = styles.fontSize;
            if (styles.textAlign) settings.text_align = styles.textAlign;
            if (styles.padding) settings.padding = styles.padding;
            if (styles.margin) settings.margin = styles.margin;
            if (styles.width) settings.width = styles.width;
            if (styles.height) settings.height = styles.height;
            if (styles.borderRadius) settings.border_radius = styles.borderRadius;
            if (styles.lineHeight) settings.line_height = styles.lineHeight;
            
            return settings;
        }
    };
    
    // Initialize when document is ready
    $(document).ready(function() {
        FlexiProFrontend.init();
    });
    
    // Make it globally available
    window.FlexiProFrontend = FlexiProFrontend;
    
})(jQuery);
