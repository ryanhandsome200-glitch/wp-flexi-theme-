<?php
/**
 * Visual Page Builder - Avada Pro Style
 * 
 * @package FlexiPro
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class FlexiPro_Visual_Builder {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_ajax_flexipro_save_builder_data', array($this, 'save_builder_data'));
        add_action('wp_ajax_flexipro_get_element_html', array($this, 'get_element_html'));
        add_action('wp_ajax_flexipro_delete_element', array($this, 'delete_element'));
        add_action('wp_ajax_flexipro_duplicate_element', array($this, 'duplicate_element'));
    }
    
    public function init() {
        // Add visual builder button to admin bar
        add_action('admin_bar_menu', array($this, 'add_builder_button'), 100);
        
        // Add meta box for visual builder
        add_action('add_meta_boxes', array($this, 'add_visual_builder_meta_box'));
        
        // Enqueue builder scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_builder_assets'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
    }
    
    public function add_builder_button($wp_admin_bar) {
        // Show on both frontend and admin, but only for users who can edit posts
        if (!current_user_can('edit_posts')) {
            return;
        }
        
        $wp_admin_bar->add_node(array(
            'id' => 'flexipro-visual-builder',
            'title' => '<span class="ab-icon dashicons dashicons-admin-customizer"></span> Visual Builder',
            'href' => '#',
            'meta' => array(
                'class' => 'flexipro-builder-trigger',
                'title' => 'Open Visual Builder'
            )
        ));
    }
    
    public function add_visual_builder_meta_box() {
        add_meta_box(
            'flexipro-visual-builder',
            __('Visual Page Builder', 'flexipro'),
            array($this, 'visual_builder_meta_box_callback'),
            array('page', 'post'),
            'normal',
            'high'
        );
    }
    
    public function visual_builder_meta_box_callback($post) {
        wp_nonce_field('flexipro_visual_builder_nonce', 'flexipro_visual_builder_nonce');
        ?>
        <div id="flexipro-visual-builder-admin">
            <div class="builder-controls">
                <button type="button" class="button button-primary" id="open-visual-builder">
                    <span class="dashicons dashicons-admin-customizer"></span>
                    Open Visual Builder
                </button>
                <button type="button" class="button" id="preview-builder">
                    <span class="dashicons dashicons-visibility"></span>
                    Preview
                </button>
            </div>
            <div class="builder-info">
                <p>Use the Visual Builder to create stunning pages with drag-and-drop elements. Click "Open Visual Builder" to start designing.</p>
            </div>
        </div>
        <?php
    }
    
    public function enqueue_builder_assets($hook) {
        // Load on post edit pages and admin pages
        if (!in_array($hook, array('post.php', 'post-new.php', 'edit.php', 'themes.php'))) {
            return;
        }
        
        // Enqueue WordPress media scripts
        wp_enqueue_media();
        wp_enqueue_script('jquery-ui-sortable');
        wp_enqueue_script('jquery-ui-draggable');
        wp_enqueue_script('jquery-ui-droppable');
        wp_enqueue_script('jquery-ui-resizable');
        wp_enqueue_script('jquery-ui-dialog');
        wp_enqueue_script('jquery-ui-tabs');
        wp_enqueue_script('jquery-ui-accordion');
        
        // Enqueue builder scripts
        wp_enqueue_script(
            'flexipro-visual-builder',
            FLEXIPRO_THEME_URL . '/js/visual-builder.js',
            array('jquery', 'jquery-ui-sortable', 'jquery-ui-draggable', 'jquery-ui-droppable', 'jquery-ui-dialog', 'jquery-ui-tabs', 'jquery-ui-accordion'),
            FLEXIPRO_VERSION,
            true
        );
        
        wp_enqueue_style(
            'flexipro-visual-builder',
            FLEXIPRO_THEME_URL . '/css/visual-builder.css',
            array(),
            FLEXIPRO_VERSION
        );
        
        // Enqueue additional styles
        wp_enqueue_style('wp-jquery-ui-dialog');
        wp_enqueue_style('wp-jquery-ui-tabs');
        wp_enqueue_style('wp-jquery-ui-accordion');
        
        wp_localize_script('flexipro-visual-builder', 'flexiproBuilder', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('flexipro_builder_nonce'),
            'postId' => get_the_ID(),
            'elements' => $this->get_available_elements(),
            'sections' => $this->get_available_sections(),
            'templates' => $this->get_available_templates(),
            'colors' => $this->get_color_palette(),
            'fonts' => $this->get_font_options(),
            'icons' => $this->get_icon_options(),
            'mediaLibrary' => array(
                'title' => __('Select Image', 'flexipro'),
                'button' => __('Use Image', 'flexipro')
            )
        ));
    }
    
    public function enqueue_frontend_assets() {
        // Load visual builder scripts on both frontend and admin
        wp_enqueue_script(
            'flexipro-visual-builder',
            FLEXIPRO_THEME_URL . '/js/visual-builder.js',
            array('jquery'),
            FLEXIPRO_VERSION,
            true
        );
        
        wp_enqueue_style(
            'flexipro-visual-builder',
            FLEXIPRO_THEME_URL . '/css/visual-builder.css',
            array(),
            FLEXIPRO_VERSION
        );
        
        // Localize script for AJAX
        wp_localize_script('flexipro-visual-builder', 'flexiproBuilder', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('flexipro_builder_nonce'),
            'postId' => get_the_ID() ? get_the_ID() : 0,
            'elements' => $this->get_available_elements(),
            'sections' => $this->get_available_sections(),
            'templates' => $this->get_available_templates(),
            'colors' => $this->get_color_palette(),
            'fonts' => $this->get_font_options(),
            'icons' => $this->get_icon_options(),
            'mediaLibrary' => array(
                'title' => __('Select Image', 'flexipro'),
                'button' => __('Use Image', 'flexipro')
            )
        ));
    }
    
    private function get_available_elements() {
        return array(
            'text' => array(
                'name' => 'Text Block',
                'icon' => 'dashicons-editor-textcolor',
                'category' => 'content',
                'description' => 'Add text content with formatting options'
            ),
            'heading' => array(
                'name' => 'Heading',
                'icon' => 'dashicons-editor-textcolor',
                'category' => 'content',
                'description' => 'Add headings (H1-H6) with styling options'
            ),
            'image' => array(
                'name' => 'Image',
                'icon' => 'dashicons-format-image',
                'category' => 'media',
                'description' => 'Add images with various display options'
            ),
            'button' => array(
                'name' => 'Button',
                'icon' => 'dashicons-admin-links',
                'category' => 'content',
                'description' => 'Add call-to-action buttons'
            ),
            'video' => array(
                'name' => 'Video',
                'icon' => 'dashicons-video-alt3',
                'category' => 'media',
                'description' => 'Embed videos from YouTube, Vimeo, etc.'
            ),
            'spacer' => array(
                'name' => 'Spacer',
                'icon' => 'dashicons-image-flip-vertical',
                'category' => 'layout',
                'description' => 'Add vertical spacing between elements'
            ),
            'divider' => array(
                'name' => 'Divider',
                'icon' => 'dashicons-minus',
                'category' => 'layout',
                'description' => 'Add horizontal dividers and separators'
            ),
            'icon' => array(
                'name' => 'Icon',
                'icon' => 'dashicons-star-filled',
                'category' => 'content',
                'description' => 'Add icons with various styles'
            ),
            'counter' => array(
                'name' => 'Counter',
                'icon' => 'dashicons-chart-bar',
                'category' => 'content',
                'description' => 'Animated number counters'
            ),
            'testimonial' => array(
                'name' => 'Testimonial',
                'icon' => 'dashicons-format-quote',
                'category' => 'content',
                'description' => 'Customer testimonials and reviews'
            ),
            'team' => array(
                'name' => 'Team Member',
                'icon' => 'dashicons-groups',
                'category' => 'content',
                'description' => 'Team member profiles with photos'
            ),
            'pricing' => array(
                'name' => 'Pricing Table',
                'icon' => 'dashicons-tag',
                'category' => 'content',
                'description' => 'Pricing tables and plans'
            ),
            'contact_form' => array(
                'name' => 'Contact Form',
                'icon' => 'dashicons-email-alt',
                'category' => 'forms',
                'description' => 'Contact forms with validation'
            ),
            'map' => array(
                'name' => 'Google Map',
                'icon' => 'dashicons-location-alt',
                'category' => 'media',
                'description' => 'Interactive Google Maps'
            ),
            'gallery' => array(
                'name' => 'Image Gallery',
                'icon' => 'dashicons-images-alt2',
                'category' => 'media',
                'description' => 'Responsive image galleries'
            ),
            'slider' => array(
                'name' => 'Image Slider',
                'icon' => 'dashicons-images-alt',
                'category' => 'media',
                'description' => 'Image sliders and carousels'
            ),
            'accordion' => array(
                'name' => 'Accordion',
                'icon' => 'dashicons-arrow-down-alt2',
                'category' => 'content',
                'description' => 'Collapsible content sections'
            ),
            'tabs' => array(
                'name' => 'Tabs',
                'icon' => 'dashicons-admin-page',
                'category' => 'content',
                'description' => 'Tabbed content sections'
            ),
            'progress_bar' => array(
                'name' => 'Progress Bar',
                'icon' => 'dashicons-chart-line',
                'category' => 'content',
                'description' => 'Animated progress bars'
            ),
            'social_icons' => array(
                'name' => 'Social Icons',
                'icon' => 'dashicons-share',
                'category' => 'content',
                'description' => 'Social media icons and links'
            )
        );
    }
    
    private function get_available_sections() {
        return array(
            'hero' => array(
                'name' => 'Hero Section',
                'icon' => 'dashicons-star-filled',
                'description' => 'Full-width hero sections with background images'
            ),
            'content' => array(
                'name' => 'Content Section',
                'icon' => 'dashicons-layout',
                'description' => 'Standard content sections with columns'
            ),
            'features' => array(
                'name' => 'Features Section',
                'icon' => 'dashicons-star-filled',
                'description' => 'Feature showcase with icons and descriptions'
            ),
            'testimonials' => array(
                'name' => 'Testimonials',
                'icon' => 'dashicons-format-quote',
                'description' => 'Customer testimonials and reviews'
            ),
            'team' => array(
                'name' => 'Team Section',
                'icon' => 'dashicons-groups',
                'description' => 'Team member profiles and bios'
            ),
            'pricing' => array(
                'name' => 'Pricing Section',
                'icon' => 'dashicons-tag',
                'description' => 'Pricing tables and plans'
            ),
            'contact' => array(
                'name' => 'Contact Section',
                'icon' => 'dashicons-email-alt',
                'description' => 'Contact forms and information'
            ),
            'cta' => array(
                'name' => 'Call to Action',
                'icon' => 'dashicons-megaphone',
                'description' => 'Call-to-action sections with buttons'
            ),
            'portfolio' => array(
                'name' => 'Portfolio',
                'icon' => 'dashicons-portfolio',
                'description' => 'Portfolio and project showcases'
            ),
            'blog' => array(
                'name' => 'Blog Section',
                'icon' => 'dashicons-admin-post',
                'description' => 'Blog posts and news sections'
            )
        );
    }
    
    private function get_available_templates() {
        return array(
            'landing' => array(
                'name' => 'Landing Page',
                'preview' => FLEXIPRO_THEME_URL . '/images/templates/landing.jpg',
                'sections' => array('hero', 'features', 'testimonials', 'cta')
            ),
            'about' => array(
                'name' => 'About Page',
                'preview' => FLEXIPRO_THEME_URL . '/images/templates/about.jpg',
                'sections' => array('hero', 'content', 'team', 'testimonials')
            ),
            'services' => array(
                'name' => 'Services Page',
                'preview' => FLEXIPRO_THEME_URL . '/images/templates/services.jpg',
                'sections' => array('hero', 'features', 'pricing', 'contact')
            ),
            'portfolio' => array(
                'name' => 'Portfolio Page',
                'preview' => FLEXIPRO_THEME_URL . '/images/templates/portfolio.jpg',
                'sections' => array('hero', 'portfolio', 'testimonials', 'contact')
            ),
            'contact' => array(
                'name' => 'Contact Page',
                'preview' => FLEXIPRO_THEME_URL . '/images/templates/contact.jpg',
                'sections' => array('hero', 'contact', 'map')
            )
        );
    }
    
    private function get_color_palette() {
        return array(
            'primary' => '#3498db',
            'secondary' => '#2c3e50',
            'success' => '#27ae60',
            'danger' => '#e74c3c',
            'warning' => '#f39c12',
            'info' => '#17a2b8',
            'light' => '#f8f9fa',
            'dark' => '#343a40',
            'white' => '#ffffff',
            'black' => '#000000'
        );
    }
    
    private function get_font_options() {
        return array(
            'system' => array(
                'name' => 'System Fonts',
                'fonts' => array(
                    'Arial, sans-serif',
                    'Helvetica, sans-serif',
                    'Georgia, serif',
                    'Times New Roman, serif',
                    'Courier New, monospace'
                )
            ),
            'google' => array(
                'name' => 'Google Fonts',
                'fonts' => array(
                    'Open Sans',
                    'Roboto',
                    'Lato',
                    'Montserrat',
                    'Source Sans Pro',
                    'Raleway',
                    'Poppins',
                    'Nunito',
                    'Playfair Display',
                    'Merriweather'
                )
            )
        );
    }
    
    private function get_icon_options() {
        return array(
            'dashicons' => array(
                'name' => 'Dashicons',
                'icons' => array(
                    'dashicons-star-filled',
                    'dashicons-heart',
                    'dashicons-thumbs-up',
                    'dashicons-phone',
                    'dashicons-email',
                    'dashicons-location',
                    'dashicons-clock',
                    'dashicons-camera',
                    'dashicons-video-alt3',
                    'dashicons-music',
                    'dashicons-palmtree',
                    'dashicons-carrot',
                    'dashicons-coffee',
                    'dashicons-food',
                    'dashicons-building',
                    'dashicons-groups',
                    'dashicons-admin-users',
                    'dashicons-businessman',
                    'dashicons-id',
                    'dashicons-id-alt'
                )
            ),
            'fontawesome' => array(
                'name' => 'Font Awesome',
                'icons' => array(
                    'fas fa-home',
                    'fas fa-user',
                    'fas fa-envelope',
                    'fas fa-phone',
                    'fas fa-map-marker-alt',
                    'fas fa-clock',
                    'fas fa-camera',
                    'fas fa-video',
                    'fas fa-music',
                    'fas fa-heart',
                    'fas fa-star',
                    'fas fa-thumbs-up',
                    'fas fa-share',
                    'fas fa-download',
                    'fas fa-upload',
                    'fas fa-search',
                    'fas fa-shopping-cart',
                    'fas fa-credit-card',
                    'fas fa-lock',
                    'fas fa-unlock'
                )
            )
        );
    }
    
    public function save_builder_data() {
        check_ajax_referer('flexipro_builder_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permission denied');
        }
        
        $post_id = intval($_POST['post_id']);
        $builder_data = $_POST['builder_data'];
        
        update_post_meta($post_id, '_flexipro_visual_builder_data', $builder_data);
        
        wp_send_json_success('Builder data saved successfully');
    }
    
    public function get_element_html() {
        check_ajax_referer('flexipro_builder_nonce', 'nonce');
        
        $element_type = sanitize_text_field($_POST['element_type']);
        $element_data = $_POST['element_data'];
        
        $html = $this->render_element($element_type, $element_data);
        
        wp_send_json_success(array('html' => $html));
    }
    
    public function delete_element() {
        check_ajax_referer('flexipro_builder_nonce', 'nonce');
        
        wp_send_json_success('Element deleted successfully');
    }
    
    public function duplicate_element() {
        check_ajax_referer('flexipro_builder_nonce', 'nonce');
        
        $element_data = $_POST['element_data'];
        $element_data['id'] = uniqid();
        
        wp_send_json_success(array('element_data' => $element_data));
    }
    
    private function render_element($type, $data) {
        ob_start();
        
        switch ($type) {
            case 'text':
                $this->render_text_element($data);
                break;
            case 'heading':
                $this->render_heading_element($data);
                break;
            case 'image':
                $this->render_image_element($data);
                break;
            case 'button':
                $this->render_button_element($data);
                break;
            case 'video':
                $this->render_video_element($data);
                break;
            case 'spacer':
                $this->render_spacer_element($data);
                break;
            case 'divider':
                $this->render_divider_element($data);
                break;
            case 'icon':
                $this->render_icon_element($data);
                break;
            case 'counter':
                $this->render_counter_element($data);
                break;
            case 'testimonial':
                $this->render_testimonial_element($data);
                break;
            case 'team':
                $this->render_team_element($data);
                break;
            case 'pricing':
                $this->render_pricing_element($data);
                break;
            case 'contact_form':
                $this->render_contact_form_element($data);
                break;
            case 'map':
                $this->render_map_element($data);
                break;
            case 'gallery':
                $this->render_gallery_element($data);
                break;
            case 'slider':
                $this->render_slider_element($data);
                break;
            case 'accordion':
                $this->render_accordion_element($data);
                break;
            case 'tabs':
                $this->render_tabs_element($data);
                break;
            case 'progress_bar':
                $this->render_progress_bar_element($data);
                break;
            case 'social_icons':
                $this->render_social_icons_element($data);
                break;
        }
        
        return ob_get_clean();
    }
    
    private function render_text_element($data) {
        $content = isset($data['content']) ? $data['content'] : 'Click to edit text';
        $align = isset($data['align']) ? $data['align'] : 'left';
        $color = isset($data['color']) ? $data['color'] : '#333';
        $font_size = isset($data['font_size']) ? $data['font_size'] : '16px';
        
        echo '<div class="flexipro-text-element" style="text-align: ' . esc_attr($align) . '; color: ' . esc_attr($color) . '; font-size: ' . esc_attr($font_size) . ';">';
        echo wp_kses_post($content);
        echo '</div>';
    }
    
    private function render_heading_element($data) {
        $tag = isset($data['tag']) ? $data['tag'] : 'h2';
        $text = isset($data['text']) ? $data['text'] : 'Click to edit heading';
        $align = isset($data['align']) ? $data['align'] : 'left';
        $color = isset($data['color']) ? $data['color'] : '#333';
        $font_size = isset($data['font_size']) ? $data['font_size'] : '32px';
        
        echo '<' . esc_attr($tag) . ' class="flexipro-heading-element" style="text-align: ' . esc_attr($align) . '; color: ' . esc_attr($color) . '; font-size: ' . esc_attr($font_size) . '; margin: 0 0 20px 0;">';
        echo esc_html($text);
        echo '</' . esc_attr($tag) . '>';
    }
    
    private function render_image_element($data) {
        $src = isset($data['src']) ? $data['src'] : 'https://via.placeholder.com/400x300';
        $alt = isset($data['alt']) ? $data['alt'] : 'Image';
        $align = isset($data['align']) ? $data['align'] : 'left';
        $width = isset($data['width']) ? $data['width'] : '100%';
        
        echo '<div class="flexipro-image-element" style="text-align: ' . esc_attr($align) . ';">';
        echo '<img src="' . esc_url($src) . '" alt="' . esc_attr($alt) . '" style="max-width: ' . esc_attr($width) . '; height: auto;">';
        echo '</div>';
    }
    
    private function render_button_element($data) {
        $text = isset($data['text']) ? $data['text'] : 'Click Here';
        $url = isset($data['url']) ? $data['url'] : '#';
        $style = isset($data['style']) ? $data['style'] : 'primary';
        $size = isset($data['size']) ? $data['size'] : 'medium';
        $align = isset($data['align']) ? $data['align'] : 'left';
        
        $class = 'flexipro-button-element btn btn-' . esc_attr($style) . ' btn-' . esc_attr($size);
        
        echo '<div class="button-wrapper" style="text-align: ' . esc_attr($align) . ';">';
        echo '<a href="' . esc_url($url) . '" class="' . esc_attr($class) . '">' . esc_html($text) . '</a>';
        echo '</div>';
    }
    
    private function render_video_element($data) {
        $url = isset($data['url']) ? $data['url'] : '';
        $width = isset($data['width']) ? $data['width'] : '100%';
        $height = isset($data['height']) ? $data['height'] : '400px';
        
        if (empty($url)) {
            echo '<div class="flexipro-video-element" style="width: ' . esc_attr($width) . '; height: ' . esc_attr($height) . '; background: #f0f0f0; display: flex; align-items: center; justify-content: center; border: 2px dashed #ccc;">';
            echo '<span>Click to add video URL</span>';
            echo '</div>';
        } else {
            echo '<div class="flexipro-video-element" style="width: ' . esc_attr($width) . ';">';
            echo wp_oembed_get($url, array('width' => $width, 'height' => $height));
            echo '</div>';
        }
    }
    
    private function render_spacer_element($data) {
        $height = isset($data['height']) ? $data['height'] : '50px';
        
        echo '<div class="flexipro-spacer-element" style="height: ' . esc_attr($height) . '; width: 100%;"></div>';
    }
    
    private function render_divider_element($data) {
        $style = isset($data['style']) ? $data['style'] : 'solid';
        $color = isset($data['color']) ? $data['color'] : '#ddd';
        $width = isset($data['width']) ? $data['width'] : '100%';
        $thickness = isset($data['thickness']) ? $data['thickness'] : '1px';
        
        echo '<div class="flexipro-divider-element" style="width: ' . esc_attr($width) . '; height: ' . esc_attr($thickness) . '; background: ' . esc_attr($color) . '; margin: 20px auto;"></div>';
    }
    
    private function render_icon_element($data) {
        $icon = isset($data['icon']) ? $data['icon'] : 'dashicons-star-filled';
        $size = isset($data['size']) ? $data['size'] : '32px';
        $color = isset($data['color']) ? $data['color'] : '#333';
        $align = isset($data['align']) ? $data['align'] : 'left';
        
        echo '<div class="flexipro-icon-element" style="text-align: ' . esc_attr($align) . ';">';
        echo '<span class="dashicons ' . esc_attr($icon) . '" style="font-size: ' . esc_attr($size) . '; color: ' . esc_attr($color) . ';"></span>';
        echo '</div>';
    }
    
    private function render_counter_element($data) {
        $number = isset($data['number']) ? $data['number'] : '100';
        $label = isset($data['label']) ? $data['label'] : 'Count';
        $color = isset($data['color']) ? $data['color'] : '#333';
        $align = isset($data['align']) ? $data['align'] : 'center';
        
        echo '<div class="flexipro-counter-element" style="text-align: ' . esc_attr($align) . ';">';
        echo '<div class="counter-number" style="font-size: 48px; font-weight: bold; color: ' . esc_attr($color) . '; margin-bottom: 10px;">' . esc_html($number) . '</div>';
        echo '<div class="counter-label" style="font-size: 16px; color: ' . esc_attr($color) . ';">' . esc_html($label) . '</div>';
        echo '</div>';
    }
    
    private function render_testimonial_element($data) {
        $content = isset($data['content']) ? $data['content'] : 'This is a great product!';
        $author = isset($data['author']) ? $data['author'] : 'John Doe';
        $position = isset($data['position']) ? $data['position'] : 'CEO, Company';
        $avatar = isset($data['avatar']) ? $data['avatar'] : '';
        
        echo '<div class="flexipro-testimonial-element" style="background: #f8f9fa; padding: 30px; border-radius: 8px; text-align: center;">';
        echo '<div class="testimonial-content" style="font-style: italic; margin-bottom: 20px; font-size: 18px;">"' . esc_html($content) . '"</div>';
        echo '<div class="testimonial-author">';
        if ($avatar) {
            echo '<img src="' . esc_url($avatar) . '" alt="' . esc_attr($author) . '" style="width: 60px; height: 60px; border-radius: 50%; margin-bottom: 10px;">';
        }
        echo '<div class="author-name" style="font-weight: bold; margin-bottom: 5px;">' . esc_html($author) . '</div>';
        echo '<div class="author-position" style="color: #666; font-size: 14px;">' . esc_html($position) . '</div>';
        echo '</div>';
        echo '</div>';
    }
    
    private function render_team_element($data) {
        $name = isset($data['name']) ? $data['name'] : 'John Doe';
        $position = isset($data['position']) ? $data['position'] : 'Team Member';
        $bio = isset($data['bio']) ? $data['bio'] : 'Team member description';
        $avatar = isset($data['avatar']) ? $data['avatar'] : 'https://via.placeholder.com/200x200';
        $social = isset($data['social']) ? $data['social'] : array();
        
        echo '<div class="flexipro-team-element" style="text-align: center; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">';
        echo '<img src="' . esc_url($avatar) . '" alt="' . esc_attr($name) . '" style="width: 150px; height: 150px; border-radius: 50%; margin-bottom: 20px; object-fit: cover;">';
        echo '<h3 style="margin: 0 0 10px 0; font-size: 24px;">' . esc_html($name) . '</h3>';
        echo '<p style="color: #666; margin: 0 0 15px 0; font-size: 16px;">' . esc_html($position) . '</p>';
        echo '<p style="margin: 0 0 20px 0; line-height: 1.6;">' . esc_html($bio) . '</p>';
        
        if (!empty($social)) {
            echo '<div class="social-links">';
            foreach ($social as $platform => $url) {
                echo '<a href="' . esc_url($url) . '" target="_blank" style="margin: 0 10px; color: #666; text-decoration: none;">' . esc_html($platform) . '</a>';
            }
            echo '</div>';
        }
        echo '</div>';
    }
    
    private function render_pricing_element($data) {
        $title = isset($data['title']) ? $data['title'] : 'Basic Plan';
        $price = isset($data['price']) ? $data['price'] : '$29';
        $period = isset($data['period']) ? $data['period'] : '/month';
        $features = isset($data['features']) ? $data['features'] : array('Feature 1', 'Feature 2', 'Feature 3');
        $button_text = isset($data['button_text']) ? $data['button_text'] : 'Get Started';
        $button_url = isset($data['button_url']) ? $data['button_url'] : '#';
        $featured = isset($data['featured']) ? $data['featured'] : false;
        
        $featured_class = $featured ? ' featured' : '';
        
        echo '<div class="flexipro-pricing-element' . $featured_class . '" style="background: #fff; border: 2px solid ' . ($featured ? '#007cba' : '#eee') . '; border-radius: 8px; padding: 30px; text-align: center; position: relative;' . ($featured ? ' transform: scale(1.05);' : '') . '">';
        
        if ($featured) {
            echo '<div style="position: absolute; top: -15px; left: 50%; transform: translateX(-50%); background: #007cba; color: white; padding: 5px 20px; border-radius: 20px; font-size: 12px; font-weight: bold;">POPULAR</div>';
        }
        
        echo '<h3 style="margin: 0 0 20px 0; font-size: 24px;">' . esc_html($title) . '</h3>';
        echo '<div class="price" style="margin-bottom: 20px;">';
        echo '<span style="font-size: 48px; font-weight: bold; color: #007cba;">' . esc_html($price) . '</span>';
        echo '<span style="color: #666;">' . esc_html($period) . '</span>';
        echo '</div>';
        
        echo '<ul style="list-style: none; padding: 0; margin: 0 0 30px 0;">';
        foreach ($features as $feature) {
            echo '<li style="padding: 10px 0; border-bottom: 1px solid #eee;">' . esc_html($feature) . '</li>';
        }
        echo '</ul>';
        
        echo '<a href="' . esc_url($button_url) . '" class="btn btn-primary" style="display: inline-block; padding: 12px 30px; background: #007cba; color: white; text-decoration: none; border-radius: 5px; font-weight: bold;">' . esc_html($button_text) . '</a>';
        echo '</div>';
    }
    
    private function render_contact_form_element($data) {
        $title = isset($data['title']) ? $data['title'] : 'Contact Us';
        $fields = isset($data['fields']) ? $data['fields'] : array('name', 'email', 'message');
        
        echo '<div class="flexipro-contact-form-element">';
        echo '<h3 style="margin-bottom: 20px;">' . esc_html($title) . '</h3>';
        echo '<form style="max-width: 500px;">';
        
        if (in_array('name', $fields)) {
            echo '<div style="margin-bottom: 15px;">';
            echo '<label style="display: block; margin-bottom: 5px; font-weight: bold;">Name</label>';
            echo '<input type="text" name="name" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">';
            echo '</div>';
        }
        
        if (in_array('email', $fields)) {
            echo '<div style="margin-bottom: 15px;">';
            echo '<label style="display: block; margin-bottom: 5px; font-weight: bold;">Email</label>';
            echo '<input type="email" name="email" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">';
            echo '</div>';
        }
        
        if (in_array('phone', $fields)) {
            echo '<div style="margin-bottom: 15px;">';
            echo '<label style="display: block; margin-bottom: 5px; font-weight: bold;">Phone</label>';
            echo '<input type="tel" name="phone" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">';
            echo '</div>';
        }
        
        if (in_array('message', $fields)) {
            echo '<div style="margin-bottom: 15px;">';
            echo '<label style="display: block; margin-bottom: 5px; font-weight: bold;">Message</label>';
            echo '<textarea name="message" rows="5" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; resize: vertical;"></textarea>';
            echo '</div>';
        }
        
        echo '<button type="submit" style="background: #007cba; color: white; padding: 12px 30px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;">Send Message</button>';
        echo '</form>';
        echo '</div>';
    }
    
    private function render_map_element($data) {
        $address = isset($data['address']) ? $data['address'] : 'New York, NY';
        $zoom = isset($data['zoom']) ? $data['zoom'] : '15';
        $height = isset($data['height']) ? $data['height'] : '300px';
        
        echo '<div class="flexipro-map-element" style="height: ' . esc_attr($height) . '; background: #f0f0f0; border: 1px solid #ddd; display: flex; align-items: center; justify-content: center; border-radius: 4px;">';
        echo '<div style="text-align: center; color: #666;">';
        echo '<div style="font-size: 48px; margin-bottom: 10px;">🗺️</div>';
        echo '<div>Google Map</div>';
        echo '<div style="font-size: 14px; margin-top: 5px;">' . esc_html($address) . '</div>';
        echo '</div>';
        echo '</div>';
    }
    
    private function render_gallery_element($data) {
        $images = isset($data['images']) ? $data['images'] : array();
        $columns = isset($data['columns']) ? $data['columns'] : '3';
        
        if (empty($images)) {
            echo '<div class="flexipro-gallery-element" style="background: #f0f0f0; padding: 40px; text-align: center; border: 2px dashed #ccc; border-radius: 4px;">';
            echo '<div style="font-size: 48px; margin-bottom: 10px;">🖼️</div>';
            echo '<div>Click to add images to gallery</div>';
            echo '</div>';
        } else {
            echo '<div class="flexipro-gallery-element" style="display: grid; grid-template-columns: repeat(' . esc_attr($columns) . ', 1fr); gap: 10px;">';
            foreach ($images as $image) {
                echo '<img src="' . esc_url($image) . '" alt="Gallery image" style="width: 100%; height: 200px; object-fit: cover; border-radius: 4px;">';
            }
            echo '</div>';
        }
    }
    
    private function render_slider_element($data) {
        $images = isset($data['images']) ? $data['images'] : array();
        $height = isset($data['height']) ? $data['height'] : '400px';
        
        if (empty($images)) {
            echo '<div class="flexipro-slider-element" style="height: ' . esc_attr($height) . '; background: #f0f0f0; display: flex; align-items: center; justify-content: center; border: 2px dashed #ccc; border-radius: 4px;">';
            echo '<div style="text-align: center; color: #666;">';
            echo '<div style="font-size: 48px; margin-bottom: 10px;">🎠</div>';
            echo '<div>Click to add images to slider</div>';
            echo '</div>';
            echo '</div>';
        } else {
            echo '<div class="flexipro-slider-element" style="height: ' . esc_attr($height) . '; background: #000; border-radius: 4px; position: relative; overflow: hidden;">';
            echo '<img src="' . esc_url($images[0]) . '" alt="Slider image" style="width: 100%; height: 100%; object-fit: cover;">';
            echo '</div>';
        }
    }
    
    private function render_accordion_element($data) {
        $items = isset($data['items']) ? $data['items'] : array(
            array('title' => 'Item 1', 'content' => 'Content for item 1'),
            array('title' => 'Item 2', 'content' => 'Content for item 2'),
            array('title' => 'Item 3', 'content' => 'Content for item 3')
        );
        
        echo '<div class="flexipro-accordion-element">';
        foreach ($items as $index => $item) {
            echo '<div class="accordion-item" style="border: 1px solid #ddd; margin-bottom: 10px; border-radius: 4px;">';
            echo '<div class="accordion-header" style="padding: 15px; background: #f8f9fa; cursor: pointer; font-weight: bold; border-bottom: 1px solid #ddd;">';
            echo esc_html($item['title']);
            echo '</div>';
            echo '<div class="accordion-content" style="padding: 15px; display: none;">';
            echo esc_html($item['content']);
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';
    }
    
    private function render_tabs_element($data) {
        $tabs = isset($data['tabs']) ? $data['tabs'] : array(
            array('title' => 'Tab 1', 'content' => 'Content for tab 1'),
            array('title' => 'Tab 2', 'content' => 'Content for tab 2'),
            array('title' => 'Tab 3', 'content' => 'Content for tab 3')
        );
        
        echo '<div class="flexipro-tabs-element">';
        echo '<div class="tabs-nav" style="display: flex; border-bottom: 1px solid #ddd; margin-bottom: 20px;">';
        foreach ($tabs as $index => $tab) {
            echo '<div class="tab-nav-item" style="padding: 10px 20px; cursor: pointer; border-bottom: 2px solid transparent;' . ($index === 0 ? ' border-bottom-color: #007cba;' : '') . '">';
            echo esc_html($tab['title']);
            echo '</div>';
        }
        echo '</div>';
        
        echo '<div class="tabs-content">';
        foreach ($tabs as $index => $tab) {
            echo '<div class="tab-content-item" style="' . ($index === 0 ? '' : 'display: none;') . '">';
            echo esc_html($tab['content']);
            echo '</div>';
        }
        echo '</div>';
        echo '</div>';
    }
    
    private function render_progress_bar_element($data) {
        $title = isset($data['title']) ? $data['title'] : 'Progress';
        $percentage = isset($data['percentage']) ? $data['percentage'] : '75';
        $color = isset($data['color']) ? $data['color'] : '#007cba';
        
        echo '<div class="flexipro-progress-bar-element">';
        echo '<div style="display: flex; justify-content: space-between; margin-bottom: 10px;">';
        echo '<span style="font-weight: bold;">' . esc_html($title) . '</span>';
        echo '<span>' . esc_html($percentage) . '%</span>';
        echo '</div>';
        echo '<div style="background: #f0f0f0; height: 20px; border-radius: 10px; overflow: hidden;">';
        echo '<div style="background: ' . esc_attr($color) . '; height: 100%; width: ' . esc_attr($percentage) . '%; transition: width 0.3s ease;"></div>';
        echo '</div>';
        echo '</div>';
    }
    
    private function render_social_icons_element($data) {
        $platforms = isset($data['platforms']) ? $data['platforms'] : array(
            'facebook' => 'https://facebook.com',
            'twitter' => 'https://twitter.com',
            'instagram' => 'https://instagram.com',
            'linkedin' => 'https://linkedin.com'
        );
        $align = isset($data['align']) ? $data['align'] : 'center';
        $size = isset($data['size']) ? $data['size'] : '32px';
        
        echo '<div class="flexipro-social-icons-element" style="text-align: ' . esc_attr($align) . ';">';
        foreach ($platforms as $platform => $url) {
            echo '<a href="' . esc_url($url) . '" target="_blank" style="display: inline-block; margin: 0 10px; color: #666; text-decoration: none; font-size: ' . esc_attr($size) . ';">';
            echo '<span class="dashicons dashicons-' . esc_attr($platform) . '"></span>';
            echo '</a>';
        }
        echo '</div>';
    }
}

// Initialize the visual builder
new FlexiPro_Visual_Builder();
