/**
 * Flexi Theme by RWB Ultimate 1.0 Sticky Header JavaScript
 * Handles sticky header functionality with shrink on scroll
 *
 * @package FlexiPro
 * @version 1.0.0
 */

(function($) {
    'use strict';
    
    var StickyHeader = {
        
        init: function() {
            this.bindEvents();
            this.initScrollListener();
            this.fixHeaderPositioning();
            console.log('Sticky Header initialized');
        },
        
        fixHeaderPositioning: function() {
            // Force header to be properly positioned
            var header = $('.site-header');
            
            // Ensure header breaks out of any container constraints
            header.css({
                'position': 'fixed',
                'top': '0',
                'left': '0',
                'right': '0',
                'width': '100vw',
                'max-width': '100vw',
                'z-index': '9999',
                'margin': '0'
            });
            
            // Fix for WordPress admin bar
            if ($('body').hasClass('admin-bar')) {
                var adminBarHeight = $('#wpadminbar').outerHeight() || 32;
                header.css('top', adminBarHeight + 'px');
            }
            
            console.log('Header positioning fixed');
        },
        
        bindEvents: function() {
            // Mobile menu toggle
            $(document).on('click', '.mobile-menu-toggle', this.toggleMobileMenu.bind(this));
            
            // Close mobile menu when clicking outside
            $(document).on('click', function(e) {
                if (!$(e.target).closest('.main-navigation, .mobile-menu-toggle').length) {
                    this.closeMobileMenu();
                }
            }.bind(this));
            
            // Close mobile menu on window resize
            $(window).on('resize', this.handleResize.bind(this));
            
            // Re-fix header positioning on resize
            $(window).on('resize', this.fixHeaderPositioning.bind(this));
        },
        
        initScrollListener: function() {
            var lastScrollTop = 0;
            var ticking = false;
            var header = $('.site-header');
            var shrinkThreshold = 80; // Start shrinking after 80px scroll
            var isScrolling = false;
            var scrollTimeout;
            
            function updateHeader() {
                var scrollTop = $(window).scrollTop();
                var scrollDirection = scrollTop > lastScrollTop ? 'down' : 'up';
                var scrollDistance = Math.abs(scrollTop - lastScrollTop);
                
                // Clear any existing timeout
                clearTimeout(scrollTimeout);
                isScrolling = true;
                
                // Add sticky class when scrolled
                if (scrollTop > 10) {
                    header.addClass('sticky scrolled');
                } else {
                    header.removeClass('sticky scrolled');
                }
                
                // Shrink header when scrolled past threshold
                if (scrollTop > shrinkThreshold) {
                    header.addClass('shrink');
                } else {
                    header.removeClass('shrink');
                }
                
                // Remove any hide/show classes to keep header visible
                header.removeClass('hidden showing');
                
                // Set timeout to detect when scrolling stops
                scrollTimeout = setTimeout(function() {
                    isScrolling = false;
                    // Ensure header is visible when scrolling stops
                    header.removeClass('hidden showing');
                }, 150);
                
                lastScrollTop = scrollTop;
                ticking = false;
            }
            
            function requestTick() {
                if (!ticking) {
                    requestAnimationFrame(updateHeader);
                    ticking = true;
                }
            }
            
            // Throttled scroll listener
            $(window).on('scroll', requestTick);
        },
        
        toggleMobileMenu: function(e) {
            e.preventDefault();
            var $toggle = $(e.currentTarget);
            var $nav = $('.main-navigation');
            var isExpanded = $toggle.attr('aria-expanded') === 'true';
            
            $toggle.attr('aria-expanded', !isExpanded);
            $nav.toggleClass('active');
            $toggle.toggleClass('active');
            
            // Update toggle text
            var toggleText = $toggle.find('.menu-toggle-text');
            toggleText.text(isExpanded ? 'Menu' : 'Close');
        },
        
        closeMobileMenu: function() {
            $('.mobile-menu-toggle').attr('aria-expanded', 'false').removeClass('active');
            $('.main-navigation').removeClass('active');
            $('.menu-toggle-text').text('Menu');
        },
        
        handleResize: function() {
            // Close mobile menu on resize to desktop
            if ($(window).width() > 768) {
                this.closeMobileMenu();
            }
        },
        
        // Public method to manually update header state
        updateHeaderState: function() {
            var scrollTop = $(window).scrollTop();
            var header = $('.site-header');
            
            if (scrollTop > 10) {
                header.addClass('sticky scrolled');
            } else {
                header.removeClass('sticky scrolled');
            }
            
            if (scrollTop > 100) {
                header.addClass('shrink');
            } else {
                header.removeClass('shrink');
            }
        }
    };
    
    // Initialize when document is ready
    $(document).ready(function() {
        StickyHeader.init();
    });
    
    // Make it globally available
    window.StickyHeader = StickyHeader;
    
})(jQuery);
