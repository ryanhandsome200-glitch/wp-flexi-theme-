<?php
/**
 * Advanced Shortcodes System - Similar to Avada Pro
 * 
 * @package FlexiPro
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class FlexiPro_Shortcodes {
    
    public function __construct() {
        add_action('init', array($this, 'init_shortcodes'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_shortcode_scripts'));
    }
    
    public function init_shortcodes() {
        // Layout Shortcodes
        add_shortcode('flexipro_row', array($this, 'row_shortcode'));
        add_shortcode('flexipro_column', array($this, 'column_shortcode'));
        add_shortcode('flexipro_spacer', array($this, 'spacer_shortcode'));
        add_shortcode('flexipro_divider', array($this, 'divider_shortcode'));
        
        // Content Shortcodes
        add_shortcode('flexipro_heading', array($this, 'heading_shortcode'));
        add_shortcode('flexipro_text', array($this, 'text_shortcode'));
        add_shortcode('flexipro_button', array($this, 'button_shortcode'));
        add_shortcode('flexipro_image', array($this, 'image_shortcode'));
        add_shortcode('flexipro_video', array($this, 'video_shortcode'));
        add_shortcode('flexipro_gallery', array($this, 'gallery_shortcode'));
        
        // Advanced Shortcodes
        add_shortcode('flexipro_accordion', array($this, 'accordion_shortcode'));
        add_shortcode('flexipro_tabs', array($this, 'tabs_shortcode'));
        add_shortcode('flexipro_toggle', array($this, 'toggle_shortcode'));
        add_shortcode('flexipro_progress_bar', array($this, 'progress_bar_shortcode'));
        add_shortcode('flexipro_counter', array($this, 'counter_shortcode'));
        add_shortcode('flexipro_icon', array($this, 'icon_shortcode'));
        add_shortcode('flexipro_highlight', array($this, 'highlight_shortcode'));
        add_shortcode('flexipro_dropcap', array($this, 'dropcap_shortcode'));
        
        // Portfolio Shortcodes
        add_shortcode('flexipro_portfolio', array($this, 'portfolio_shortcode'));
        add_shortcode('flexipro_portfolio_filter', array($this, 'portfolio_filter_shortcode'));
        add_shortcode('flexipro_portfolio_carousel', array($this, 'portfolio_carousel_shortcode'));
        
        // Blog Shortcodes
        add_shortcode('flexipro_blog', array($this, 'blog_shortcode'));
        add_shortcode('flexipro_blog_carousel', array($this, 'blog_carousel_shortcode'));
        add_shortcode('flexipro_recent_posts', array($this, 'recent_posts_shortcode'));
        
        // Team Shortcodes
        add_shortcode('flexipro_team', array($this, 'team_shortcode'));
        add_shortcode('flexipro_team_member', array($this, 'team_member_shortcode'));
        
        // Testimonials Shortcodes
        add_shortcode('flexipro_testimonials', array($this, 'testimonials_shortcode'));
        add_shortcode('flexipro_testimonial', array($this, 'testimonial_shortcode'));
        
        // Pricing Shortcodes
        add_shortcode('flexipro_pricing_table', array($this, 'pricing_table_shortcode'));
        add_shortcode('flexipro_pricing_column', array($this, 'pricing_column_shortcode'));
        
        // Contact Shortcodes
        add_shortcode('flexipro_contact_form', array($this, 'contact_form_shortcode'));
        add_shortcode('flexipro_map', array($this, 'map_shortcode'));
        add_shortcode('flexipro_contact_info', array($this, 'contact_info_shortcode'));
        
        // WooCommerce Shortcodes
        add_shortcode('flexipro_products', array($this, 'products_shortcode'));
        add_shortcode('flexipro_product_carousel', array($this, 'product_carousel_shortcode'));
        add_shortcode('flexipro_featured_products', array($this, 'featured_products_shortcode'));
        
        // Animation Shortcodes
        add_shortcode('flexipro_animate', array($this, 'animate_shortcode'));
        add_shortcode('flexipro_parallax', array($this, 'parallax_shortcode'));
        
        // Utility Shortcodes
        add_shortcode('flexipro_clear', array($this, 'clear_shortcode'));
        add_shortcode('flexipro_br', array($this, 'br_shortcode'));
    }
    
    // Layout Shortcodes
    public function row_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'class' => '',
            'id' => '',
            'background_color' => '',
            'background_image' => '',
            'padding_top' => '',
            'padding_bottom' => '',
            'margin_top' => '',
            'margin_bottom' => '',
            'full_width' => 'false',
            'equal_height' => 'false'
        ), $atts);
        
        $style = '';
        if ($atts['background_color']) {
            $style .= 'background-color: ' . esc_attr($atts['background_color']) . '; ';
        }
        if ($atts['background_image']) {
            $style .= 'background-image: url(' . esc_url($atts['background_image']) . '); background-size: cover; background-position: center; ';
        }
        if ($atts['padding_top']) {
            $style .= 'padding-top: ' . esc_attr($atts['padding_top']) . 'px; ';
        }
        if ($atts['padding_bottom']) {
            $style .= 'padding-bottom: ' . esc_attr($atts['padding_bottom']) . 'px; ';
        }
        if ($atts['margin_top']) {
            $style .= 'margin-top: ' . esc_attr($atts['margin_top']) . 'px; ';
        }
        if ($atts['margin_bottom']) {
            $style .= 'margin-bottom: ' . esc_attr($atts['margin_bottom']) . 'px; ';
        }
        
        $classes = array('flexipro-row');
        if ($atts['full_width'] === 'true') {
            $classes[] = 'full-width';
        }
        if ($atts['equal_height'] === 'true') {
            $classes[] = 'equal-height';
        }
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $output = '<div class="' . implode(' ', $classes) . '"';
        if ($atts['id']) {
            $output .= ' id="' . esc_attr($atts['id']) . '"';
        }
        if ($style) {
            $output .= ' style="' . $style . '"';
        }
        $output .= '>';
        $output .= '<div class="container">';
        $output .= '<div class="row">';
        $output .= do_shortcode($content);
        $output .= '</div>';
        $output .= '</div>';
        $output .= '</div>';
        
        return $output;
    }
    
    public function column_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'size' => '12',
            'class' => '',
            'id' => '',
            'background_color' => '',
            'padding' => '',
            'text_align' => '',
            'vertical_align' => ''
        ), $atts);
        
        $style = '';
        if ($atts['background_color']) {
            $style .= 'background-color: ' . esc_attr($atts['background_color']) . '; ';
        }
        if ($atts['padding']) {
            $style .= 'padding: ' . esc_attr($atts['padding']) . '; ';
        }
        if ($atts['text_align']) {
            $style .= 'text-align: ' . esc_attr($atts['text_align']) . '; ';
        }
        if ($atts['vertical_align']) {
            $style .= 'display: flex; align-items: ' . esc_attr($atts['vertical_align']) . '; ';
        }
        
        $classes = array('col-' . $atts['size']);
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $output = '<div class="' . implode(' ', $classes) . '"';
        if ($atts['id']) {
            $output .= ' id="' . esc_attr($atts['id']) . '"';
        }
        if ($style) {
            $output .= ' style="' . $style . '"';
        }
        $output .= '>';
        $output .= do_shortcode($content);
        $output .= '</div>';
        
        return $output;
    }
    
    public function spacer_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'height' => '50',
            'class' => ''
        ), $atts);
        
        $classes = array('flexipro-spacer');
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        return '<div class="' . implode(' ', $classes) . '" style="height: ' . esc_attr($atts['height']) . 'px;"></div>';
    }
    
    public function divider_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'style' => 'solid',
            'color' => '#ddd',
            'width' => '100%',
            'height' => '1px',
            'margin_top' => '20px',
            'margin_bottom' => '20px',
            'class' => ''
        ), $atts);
        
        $classes = array('flexipro-divider', 'divider-' . $atts['style']);
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $style = 'border-top: ' . esc_attr($atts['height']) . ' ' . esc_attr($atts['style']) . ' ' . esc_attr($atts['color']) . '; ';
        $style .= 'width: ' . esc_attr($atts['width']) . '; ';
        $style .= 'margin-top: ' . esc_attr($atts['margin_top']) . 'px; ';
        $style .= 'margin-bottom: ' . esc_attr($atts['margin_bottom']) . 'px; ';
        
        return '<div class="' . implode(' ', $classes) . '" style="' . $style . '"></div>';
    }
    
    // Content Shortcodes
    public function heading_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'tag' => 'h2',
            'size' => '',
            'color' => '',
            'text_align' => '',
            'margin_top' => '',
            'margin_bottom' => '',
            'class' => ''
        ), $atts);
        
        $style = '';
        if ($atts['size']) {
            $style .= 'font-size: ' . esc_attr($atts['size']) . 'px; ';
        }
        if ($atts['color']) {
            $style .= 'color: ' . esc_attr($atts['color']) . '; ';
        }
        if ($atts['text_align']) {
            $style .= 'text-align: ' . esc_attr($atts['text_align']) . '; ';
        }
        if ($atts['margin_top']) {
            $style .= 'margin-top: ' . esc_attr($atts['margin_top']) . 'px; ';
        }
        if ($atts['margin_bottom']) {
            $style .= 'margin-bottom: ' . esc_attr($atts['margin_bottom']) . 'px; ';
        }
        
        $classes = array('flexipro-heading');
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $output = '<' . esc_attr($atts['tag']) . ' class="' . implode(' ', $classes) . '"';
        if ($style) {
            $output .= ' style="' . $style . '"';
        }
        $output .= '>';
        $output .= do_shortcode($content);
        $output .= '</' . esc_attr($atts['tag']) . '>';
        
        return $output;
    }
    
    public function text_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'size' => '',
            'color' => '',
            'text_align' => '',
            'font_weight' => '',
            'line_height' => '',
            'class' => ''
        ), $atts);
        
        $style = '';
        if ($atts['size']) {
            $style .= 'font-size: ' . esc_attr($atts['size']) . 'px; ';
        }
        if ($atts['color']) {
            $style .= 'color: ' . esc_attr($atts['color']) . '; ';
        }
        if ($atts['text_align']) {
            $style .= 'text-align: ' . esc_attr($atts['text_align']) . '; ';
        }
        if ($atts['font_weight']) {
            $style .= 'font-weight: ' . esc_attr($atts['font_weight']) . '; ';
        }
        if ($atts['line_height']) {
            $style .= 'line-height: ' . esc_attr($atts['line_height']) . '; ';
        }
        
        $classes = array('flexipro-text');
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $output = '<div class="' . implode(' ', $classes) . '"';
        if ($style) {
            $output .= ' style="' . $style . '"';
        }
        $output .= '>';
        $output .= do_shortcode($content);
        $output .= '</div>';
        
        return $output;
    }
    
    public function button_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'url' => '#',
            'target' => '_self',
            'style' => 'primary',
            'size' => 'medium',
            'icon' => '',
            'icon_position' => 'left',
            'text_align' => '',
            'margin_top' => '',
            'margin_bottom' => '',
            'class' => ''
        ), $atts);
        
        $style = '';
        if ($atts['text_align']) {
            $style .= 'text-align: ' . esc_attr($atts['text_align']) . '; ';
        }
        if ($atts['margin_top']) {
            $style .= 'margin-top: ' . esc_attr($atts['margin_top']) . 'px; ';
        }
        if ($atts['margin_bottom']) {
            $style .= 'margin-bottom: ' . esc_attr($atts['margin_bottom']) . 'px; ';
        }
        
        $classes = array('btn', 'btn-' . $atts['style'], 'btn-' . $atts['size']);
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $icon_html = '';
        if ($atts['icon']) {
            $icon_class = 'fas fa-' . esc_attr($atts['icon']);
            $icon_html = '<i class="' . $icon_class . '"></i>';
        }
        
        $output = '<div class="flexipro-button-wrapper"';
        if ($style) {
            $output .= ' style="' . $style . '"';
        }
        $output .= '>';
        $output .= '<a href="' . esc_url($atts['url']) . '" target="' . esc_attr($atts['target']) . '" class="' . implode(' ', $classes) . '">';
        
        if ($atts['icon'] && $atts['icon_position'] === 'left') {
            $output .= $icon_html . ' ';
        }
        
        $output .= do_shortcode($content);
        
        if ($atts['icon'] && $atts['icon_position'] === 'right') {
            $output .= ' ' . $icon_html;
        }
        
        $output .= '</a>';
        $output .= '</div>';
        
        return $output;
    }
    
    public function image_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'src' => '',
            'alt' => '',
            'width' => '',
            'height' => '',
            'align' => '',
            'link' => '',
            'link_target' => '_self',
            'lightbox' => 'false',
            'caption' => '',
            'class' => ''
        ), $atts);
        
        $style = '';
        if ($atts['width']) {
            $style .= 'width: ' . esc_attr($atts['width']) . 'px; ';
        }
        if ($atts['height']) {
            $style .= 'height: ' . esc_attr($atts['height']) . 'px; ';
        }
        if ($atts['align']) {
            $style .= 'float: ' . esc_attr($atts['align']) . '; ';
        }
        
        $classes = array('flexipro-image');
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $output = '<div class="' . implode(' ', $classes) . '"';
        if ($style) {
            $output .= ' style="' . $style . '"';
        }
        $output .= '>';
        
        if ($atts['link'] || $atts['lightbox'] === 'true') {
            $link_url = $atts['link'] ? $atts['link'] : $atts['src'];
            $link_target = $atts['lightbox'] === 'true' ? '_blank' : $atts['link_target'];
            $link_class = $atts['lightbox'] === 'true' ? 'lightbox' : '';
            
            $output .= '<a href="' . esc_url($link_url) . '" target="' . esc_attr($link_target) . '" class="' . $link_class . '">';
        }
        
        $output .= '<img src="' . esc_url($atts['src']) . '" alt="' . esc_attr($atts['alt']) . '">';
        
        if ($atts['link'] || $atts['lightbox'] === 'true') {
            $output .= '</a>';
        }
        
        if ($atts['caption']) {
            $output .= '<p class="image-caption">' . esc_html($atts['caption']) . '</p>';
        }
        
        $output .= '</div>';
        
        return $output;
    }
    
    public function video_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'src' => '',
            'width' => '100%',
            'height' => '400',
            'autoplay' => 'false',
            'muted' => 'false',
            'loop' => 'false',
            'controls' => 'true',
            'poster' => '',
            'class' => ''
        ), $atts);
        
        $classes = array('flexipro-video');
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $output = '<div class="' . implode(' ', $classes) . '">';
        $output .= '<video width="' . esc_attr($atts['width']) . '" height="' . esc_attr($atts['height']) . '"';
        
        if ($atts['autoplay'] === 'true') {
            $output .= ' autoplay';
        }
        if ($atts['muted'] === 'true') {
            $output .= ' muted';
        }
        if ($atts['loop'] === 'true') {
            $output .= ' loop';
        }
        if ($atts['controls'] === 'true') {
            $output .= ' controls';
        }
        if ($atts['poster']) {
            $output .= ' poster="' . esc_url($atts['poster']) . '"';
        }
        
        $output .= '>';
        $output .= '<source src="' . esc_url($atts['src']) . '" type="video/mp4">';
        $output .= 'Your browser does not support the video tag.';
        $output .= '</video>';
        $output .= '</div>';
        
        return $output;
    }
    
    // Portfolio Shortcodes
    public function portfolio_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'posts_per_page' => '6',
            'columns' => '3',
            'filter' => 'true',
            'lightbox' => 'true',
            'hover_effect' => 'zoom',
            'show_title' => 'true',
            'show_excerpt' => 'true',
            'show_categories' => 'true',
            'class' => ''
        ), $atts);
        
        $classes = array('flexipro-portfolio', 'portfolio-columns-' . $atts['columns']);
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $args = array(
            'post_type' => 'portfolio',
            'posts_per_page' => intval($atts['posts_per_page']),
            'post_status' => 'publish'
        );
        
        $query = new WP_Query($args);
        
        $output = '<div class="' . implode(' ', $classes) . '">';
        
        if ($atts['filter'] === 'true') {
            $output .= $this->portfolio_filter();
        }
        
        $output .= '<div class="portfolio-grid">';
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $output .= $this->portfolio_item($atts);
            }
        }
        
        $output .= '</div>';
        $output .= '</div>';
        
        wp_reset_postdata();
        
        return $output;
    }
    
    private function portfolio_filter() {
        $categories = get_terms(array(
            'taxonomy' => 'portfolio_category',
            'hide_empty' => true
        ));
        
        if (empty($categories)) {
            return '';
        }
        
        $output = '<div class="portfolio-filter">';
        $output .= '<button class="filter-btn active" data-filter="*">All</button>';
        
        foreach ($categories as $category) {
            $output .= '<button class="filter-btn" data-filter=".' . $category->slug . '">' . $category->name . '</button>';
        }
        
        $output .= '</div>';
        
        return $output;
    }
    
    private function portfolio_item($atts) {
        $post_id = get_the_ID();
        $categories = get_the_terms($post_id, 'portfolio_category');
        $category_classes = '';
        
        if ($categories) {
            foreach ($categories as $category) {
                $category_classes .= ' ' . $category->slug;
            }
        }
        
        $output = '<div class="portfolio-item' . $category_classes . '">';
        
        if (has_post_thumbnail()) {
            $output .= '<div class="portfolio-image">';
            $output .= '<a href="' . get_permalink() . '">';
            $output .= get_the_post_thumbnail($post_id, 'flexipro-portfolio-thumb');
            $output .= '</a>';
            
            if ($atts['lightbox'] === 'true') {
                $full_image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');
                $output .= '<a href="' . $full_image[0] . '" class="portfolio-lightbox" data-lightbox="portfolio">';
                $output .= '<i class="fas fa-search-plus"></i>';
                $output .= '</a>';
            }
            
            $output .= '</div>';
        }
        
        if ($atts['show_title'] === 'true' || $atts['show_excerpt'] === 'true' || $atts['show_categories'] === 'true') {
            $output .= '<div class="portfolio-content">';
            
            if ($atts['show_title'] === 'true') {
                $output .= '<h3 class="portfolio-title"><a href="' . get_permalink() . '">' . get_the_title() . '</a></h3>';
            }
            
            if ($atts['show_categories'] === 'true' && $categories) {
                $output .= '<div class="portfolio-categories">';
                foreach ($categories as $category) {
                    $output .= '<span class="portfolio-category">' . $category->name . '</span>';
                }
                $output .= '</div>';
            }
            
            if ($atts['show_excerpt'] === 'true') {
                $output .= '<div class="portfolio-excerpt">' . get_the_excerpt() . '</div>';
            }
            
            $output .= '</div>';
        }
        
        $output .= '</div>';
        
        return $output;
    }
    
    // Blog Shortcodes
    public function blog_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'posts_per_page' => '6',
            'columns' => '3',
            'layout' => 'grid',
            'show_meta' => 'true',
            'show_excerpt' => 'true',
            'excerpt_length' => '55',
            'show_read_more' => 'true',
            'read_more_text' => 'Read More',
            'class' => ''
        ), $atts);
        
        $classes = array('flexipro-blog', 'blog-' . $atts['layout'], 'blog-columns-' . $atts['columns']);
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => intval($atts['posts_per_page']),
            'post_status' => 'publish'
        );
        
        $query = new WP_Query($args);
        
        $output = '<div class="' . implode(' ', $classes) . '">';
        $output .= '<div class="blog-grid">';
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $output .= $this->blog_item($atts);
            }
        }
        
        $output .= '</div>';
        $output .= '</div>';
        
        wp_reset_postdata();
        
        return $output;
    }
    
    private function blog_item($atts) {
        $output = '<article class="blog-item">';
        
        if (has_post_thumbnail()) {
            $output .= '<div class="blog-image">';
            $output .= '<a href="' . get_permalink() . '">';
            $output .= get_the_post_thumbnail(get_the_ID(), 'flexipro-blog-thumb');
            $output .= '</a>';
            $output .= '</div>';
        }
        
        $output .= '<div class="blog-content">';
        
        if ($atts['show_meta'] === 'true') {
            $output .= '<div class="blog-meta">';
            $output .= '<span class="post-date"><i class="fas fa-calendar"></i> ' . get_the_date() . '</span>';
            $output .= '<span class="post-author"><i class="fas fa-user"></i> ' . get_the_author() . '</span>';
            $output .= '<span class="post-comments"><i class="fas fa-comments"></i> ' . get_comments_number() . '</span>';
            $output .= '</div>';
        }
        
        $output .= '<h3 class="blog-title"><a href="' . get_permalink() . '">' . get_the_title() . '</a></h3>';
        
        if ($atts['show_excerpt'] === 'true') {
            $excerpt = get_the_excerpt();
            if ($atts['excerpt_length']) {
                $excerpt = wp_trim_words($excerpt, intval($atts['excerpt_length']));
            }
            $output .= '<div class="blog-excerpt">' . $excerpt . '</div>';
        }
        
        if ($atts['show_read_more'] === 'true') {
            $output .= '<a href="' . get_permalink() . '" class="btn btn-primary">' . esc_html($atts['read_more_text']) . '</a>';
        }
        
        $output .= '</div>';
        $output .= '</article>';
        
        return $output;
    }
    
    // Testimonials Shortcodes
    public function testimonials_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'layout' => 'grid',
            'columns' => '3',
            'autoplay' => 'true',
            'show_rating' => 'true',
            'show_avatar' => 'true',
            'class' => ''
        ), $atts);
        
        $classes = array('flexipro-testimonials', 'testimonials-' . $atts['layout'], 'testimonials-columns-' . $atts['columns']);
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $testimonials = json_decode(do_shortcode($content), true);
        
        if (!$testimonials) {
            return '';
        }
        
        $output = '<div class="' . implode(' ', $classes) . '">';
        
        if ($atts['layout'] === 'carousel') {
            $output .= '<div class="testimonials-carousel">';
        } else {
            $output .= '<div class="testimonials-grid">';
        }
        
        foreach ($testimonials as $testimonial) {
            $output .= $this->testimonial_item($testimonial, $atts);
        }
        
        $output .= '</div>';
        $output .= '</div>';
        
        return $output;
    }
    
    private function testimonial_item($testimonial, $atts) {
        $output = '<div class="testimonial-item">';
        
        if ($atts['show_rating'] === 'true' && isset($testimonial['rating'])) {
            $output .= '<div class="testimonial-rating">';
            for ($i = 1; $i <= 5; $i++) {
                $class = $i <= $testimonial['rating'] ? 'star-filled' : 'star-empty';
                $output .= '<i class="fas fa-star ' . $class . '"></i>';
            }
            $output .= '</div>';
        }
        
        $output .= '<div class="testimonial-content">';
        $output .= '<p>' . esc_html($testimonial['content']) . '</p>';
        $output .= '</div>';
        
        $output .= '<div class="testimonial-author">';
        
        if ($atts['show_avatar'] === 'true' && isset($testimonial['avatar'])) {
            $output .= '<div class="testimonial-avatar">';
            $output .= '<img src="' . esc_url($testimonial['avatar']) . '" alt="' . esc_attr($testimonial['name']) . '">';
            $output .= '</div>';
        }
        
        $output .= '<div class="testimonial-info">';
        $output .= '<h4 class="testimonial-name">' . esc_html($testimonial['name']) . '</h4>';
        
        if (isset($testimonial['position'])) {
            $output .= '<span class="testimonial-position">' . esc_html($testimonial['position']) . '</span>';
        }
        
        if (isset($testimonial['company'])) {
            $output .= '<span class="testimonial-company">' . esc_html($testimonial['company']) . '</span>';
        }
        
        $output .= '</div>';
        $output .= '</div>';
        $output .= '</div>';
        
        return $output;
    }
    
    public function testimonial_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'name' => '',
            'position' => '',
            'company' => '',
            'avatar' => '',
            'rating' => '5',
            'class' => ''
        ), $atts);
        
        $testimonial = array(
            'name' => $atts['name'],
            'position' => $atts['position'],
            'company' => $atts['company'],
            'avatar' => $atts['avatar'],
            'rating' => intval($atts['rating']),
            'content' => do_shortcode($content)
        );
        
        $classes = array('flexipro-testimonial');
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $output = '<div class="' . implode(' ', $classes) . '">';
        $output .= $this->testimonial_item($testimonial, array('show_rating' => 'true', 'show_avatar' => 'true'));
        $output .= '</div>';
        
        return $output;
    }
    
    // Contact Form Shortcode
    public function contact_form_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'title' => 'Contact Us',
            'description' => '',
            'email_to' => get_option('admin_email'),
            'email_subject' => 'New Contact Form Submission',
            'success_message' => 'Thank you! Your message has been sent.',
            'class' => ''
        ), $atts);
        
        $classes = array('flexipro-contact-form');
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $output = '<div class="' . implode(' ', $classes) . '">';
        
        if ($atts['title']) {
            $output .= '<h3 class="form-title">' . esc_html($atts['title']) . '</h3>';
        }
        
        if ($atts['description']) {
            $output .= '<p class="form-description">' . esc_html($atts['description']) . '</p>';
        }
        
        $output .= '<form class="contact-form" method="post" action="">';
        $output .= wp_nonce_field('flexipro_contact_form', 'flexipro_contact_nonce', true, false);
        $output .= '<input type="hidden" name="email_to" value="' . esc_attr($atts['email_to']) . '">';
        $output .= '<input type="hidden" name="email_subject" value="' . esc_attr($atts['email_subject']) . '">';
        
        $output .= '<div class="form-group">';
        $output .= '<label for="contact_name">Name *</label>';
        $output .= '<input type="text" id="contact_name" name="contact_name" required>';
        $output .= '</div>';
        
        $output .= '<div class="form-group">';
        $output .= '<label for="contact_email">Email *</label>';
        $output .= '<input type="email" id="contact_email" name="contact_email" required>';
        $output .= '</div>';
        
        $output .= '<div class="form-group">';
        $output .= '<label for="contact_subject">Subject</label>';
        $output .= '<input type="text" id="contact_subject" name="contact_subject">';
        $output .= '</div>';
        
        $output .= '<div class="form-group">';
        $output .= '<label for="contact_message">Message *</label>';
        $output .= '<textarea id="contact_message" name="contact_message" rows="5" required></textarea>';
        $output .= '</div>';
        
        $output .= '<div class="form-group">';
        $output .= '<button type="submit" class="btn btn-primary">Send Message</button>';
        $output .= '</div>';
        
        $output .= '</form>';
        $output .= '</div>';
        
        // Handle form submission
        if ($_POST && wp_verify_nonce($_POST['flexipro_contact_nonce'], 'flexipro_contact_form')) {
            $this->handle_contact_form_submission($atts);
        }
        
        return $output;
    }
    
    private function handle_contact_form_submission($atts) {
        $name = sanitize_text_field($_POST['contact_name']);
        $email = sanitize_email($_POST['contact_email']);
        $subject = sanitize_text_field($_POST['contact_subject']);
        $message = sanitize_textarea_field($_POST['contact_message']);
        $email_to = sanitize_email($_POST['email_to']);
        $email_subject = sanitize_text_field($_POST['email_subject']);
        
        $email_message = "Name: $name\n";
        $email_message .= "Email: $email\n";
        $email_message .= "Subject: $subject\n\n";
        $email_message .= "Message:\n$message";
        
        $headers = array('Content-Type: text/plain; charset=UTF-8');
        
        if (wp_mail($email_to, $email_subject, $email_message, $headers)) {
            echo '<div class="contact-form-success">' . esc_html($atts['success_message']) . '</div>';
        } else {
            echo '<div class="contact-form-error">Sorry, there was an error sending your message.</div>';
        }
    }
    
    // Animation Shortcodes
    public function animate_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'animation' => 'fadeInUp',
            'delay' => '0',
            'duration' => '1000',
            'class' => ''
        ), $atts);
        
        $classes = array('flexipro-animate', 'animate-' . $atts['animation']);
        if ($atts['class']) {
            $classes[] = $atts['class'];
        }
        
        $style = 'animation-delay: ' . esc_attr($atts['delay']) . 'ms; ';
        $style .= 'animation-duration: ' . esc_attr($atts['duration']) . 'ms; ';
        
        $output = '<div class="' . implode(' ', $classes) . '" style="' . $style . '">';
        $output .= do_shortcode($content);
        $output .= '</div>';
        
        return $output;
    }
    
    // Utility Shortcodes
    public function clear_shortcode($atts, $content = null) {
        return '<div class="clear"></div>';
    }
    
    public function br_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'count' => '1'
        ), $atts);
        
        $output = '';
        for ($i = 0; $i < intval($atts['count']); $i++) {
            $output .= '<br>';
        }
        
        return $output;
    }
    
    public function enqueue_shortcode_scripts() {
        wp_enqueue_style('flexipro-shortcodes', FLEXIPRO_THEME_URL . '/css/shortcodes.css', array(), FLEXIPRO_VERSION);
        wp_enqueue_script('flexipro-shortcodes', FLEXIPRO_THEME_URL . '/js/shortcodes.js', array('jquery'), FLEXIPRO_VERSION, true);
    }
}

// Initialize shortcodes
new FlexiPro_Shortcodes();
