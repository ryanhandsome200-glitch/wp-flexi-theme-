/**
 * FlexiPro Visual Builder - Simple Working Version
 * 
 * @package FlexiPro
 * @version 1.0.0
 */

(function($) {
    'use strict';
    
    var FlexiProBuilder = {
        isOpen: false,
        currentElement: null,
        builderData: {
            elements: [],
            sections: []
        },
        
        init: function() {
            this.bindEvents();
            this.loadExistingContent();
            this.addDebugInfo();
            console.log('FlexiPro Builder initialized');
        },
        
        addDebugInfo: function() {
            // Add debug information to help troubleshoot
            console.log('=== DEBUG INFO ===');
            console.log('jQuery version:', $.fn.jquery);
            console.log('Document ready:', $(document).ready);
            console.log('Body content length:', $('body').html().length);
            console.log('Available content selectors:');
            $('.entry-content, .post-content, .page-content, .content, .site-content, main, article, .post, .page').each(function(i, el) {
                console.log('  Selector ' + i + ':', el.className, 'Content length:', $(el).html().length);
            });
            console.log('==================');
        },
        
        loadExistingContent: function() {
            console.log('Loading existing content...');
            
            // Check if we're on a post/page edit screen
            if (typeof flexiproBuilder !== 'undefined' && flexiproBuilder.postId) {
                this.loadBuilderDataFromPost();
            } else {
                // Try to load content from the current page
                this.loadContentFromPage();
            }
        },
        
        loadBuilderDataFromPost: function() {
            console.log('Loading builder data from post:', flexiproBuilder.postId);
            
            $.ajax({
                url: flexiproBuilder.ajaxurl,
                type: 'POST',
                data: {
                    action: 'flexipro_get_builder_data',
                    post_id: flexiproBuilder.postId,
                    nonce: flexiproBuilder.nonce
                },
                success: function(response) {
                    console.log('Builder data response:', response);
                    if (response.success && response.data) {
                        this.builderData = response.data;
                        this.renderAllElements();
                    } else {
                        console.log('No builder data found, loading page content');
                        this.loadContentFromPage();
                    }
                }.bind(this),
                error: function() {
                    console.log('Error loading builder data, loading page content');
                    this.loadContentFromPage();
                }.bind(this)
            });
        },
        
        loadContentFromPage: function() {
            console.log('Loading content from current page...');
            
            // Look for existing content in multiple possible selectors
            var $content = $('.entry-content, .post-content, .page-content, .content, .site-content, main, article, .post, .page');
            
            if ($content.length === 0) {
                console.log('No content found with standard selectors, trying body...');
                $content = $('body');
            }
            
            if ($content.length === 0) {
                console.log('No content found on page');
                this.showNoContentMessage();
                return;
            }
            
            console.log('Found content:', $content);
            console.log('Content HTML:', $content.html().substring(0, 200) + '...');
            
            // Parse the content and convert to builder elements
            this.parseContentToElements($content);
        },
        
        showNoContentMessage: function() {
            var $canvas = $('#builder-canvas');
            if ($canvas.length > 0) {
                $canvas.html(`
                    <div class="no-content-message" style="text-align: center; padding: 40px; color: #666;">
                        <i class="dashicons dashicons-info" style="font-size: 48px; margin-bottom: 20px; display: block;"></i>
                        <h3>No Content Found</h3>
                        <p>This page doesn't have any content to edit yet.</p>
                        <p>Start by adding elements from the sidebar to build your page.</p>
                    </div>
                `);
            }
        },
        
        parseContentToElements: function($content) {
            console.log('Parsing content to elements...');
            
            var elements = [];
            var elementId = 1;
            
            // First, try to find any existing flexipro elements
            var $flexiproElements = $content.find('.flexipro-heading, .flexipro-text, .flexipro-image, .flexipro-button, .flexipro-video, .flexipro-spacer');
            
            if ($flexiproElements.length > 0) {
                console.log('Found existing flexipro elements:', $flexiproElements.length);
                $flexiproElements.each(function() {
                    var $element = $(this);
                    var elementType = this.className.match(/flexipro-(\w+)/);
                    if (elementType) {
                        elements.push({
                            id: 'element_' + elementId++,
                            type: elementType[1],
                            data: {
                                content: $element.text() || $element.find('img').attr('src') || $element.find('iframe').attr('src') || '',
                                settings: {
                                    color: $element.css('color'),
                                    font_size: $element.css('font-size'),
                                    align: $element.css('text-align'),
                                    margin: $element.css('margin'),
                                    padding: $element.css('padding'),
                                    background: $element.css('background-color')
                                }
                            }
                        });
                    }
                });
            }
            
            // If no flexipro elements found, parse regular HTML
            if (elements.length === 0) {
                console.log('No flexipro elements found, parsing regular HTML...');
                
                // Parse headings
                $content.find('h1, h2, h3, h4, h5, h6').each(function() {
                    var $heading = $(this);
                    var level = parseInt($heading.prop('tagName').substring(1));
                    
                    elements.push({
                        id: 'element_' + elementId++,
                        type: 'heading',
                        data: {
                            content: $heading.text(),
                            settings: {
                                level: level.toString(),
                                tag: 'h' + level,
                                color: $heading.css('color'),
                                font_size: $heading.css('font-size'),
                                align: $heading.css('text-align'),
                                margin: $heading.css('margin')
                            }
                        }
                    });
                });
            }
            
            // Parse paragraphs
            $content.find('p').each(function() {
                var $paragraph = $(this);
                var text = $paragraph.text().trim();
                
                if (text && text.length > 0) {
                    elements.push({
                        id: 'element_' + elementId++,
                        type: 'text',
                        data: {
                            content: text,
                            settings: {
                                color: $paragraph.css('color'),
                                font_size: $paragraph.css('font-size'),
                                align: $paragraph.css('text-align'),
                                line_height: $paragraph.css('line-height')
                            }
                        }
                    });
                }
            });
            
            // Parse images
            $content.find('img').each(function() {
                var $img = $(this);
                
                elements.push({
                    id: 'element_' + elementId++,
                    type: 'image',
                    data: {
                        content: $img.attr('src'),
                        settings: {
                            alt: $img.attr('alt') || '',
                            width: $img.css('width'),
                            height: $img.css('height'),
                            align: $img.css('float') || 'left',
                            border_radius: $img.css('border-radius')
                        }
                    }
                });
            });
            
            // Parse buttons/links
            $content.find('a').each(function() {
                var $link = $(this);
                var text = $link.text().trim();
                var href = $link.attr('href');
                
                // Check if it looks like a button
                if (text && (href !== '#' || $link.hasClass('btn') || $link.hasClass('button'))) {
                    elements.push({
                        id: 'element_' + elementId++,
                        type: 'button',
                        data: {
                            content: text,
                            settings: {
                                url: href,
                                bg_color: $link.css('background-color'),
                                text_color: $link.css('color'),
                                padding: $link.css('padding'),
                                border_radius: $link.css('border-radius'),
                                align: $link.parent().css('text-align') || 'left'
                            }
                        }
                    });
                }
            });
            
            // Parse videos
            $content.find('video, iframe[src*="youtube"], iframe[src*="vimeo"]').each(function() {
                var $video = $(this);
                var src = $video.attr('src') || $video.find('source').attr('src');
                
                if (src) {
                    elements.push({
                        id: 'element_' + elementId++,
                        type: 'video',
                        data: {
                            content: src,
                            settings: {
                                width: $video.css('width'),
                                height: $video.css('height'),
                                controls: $video.attr('controls') !== undefined
                            }
                        }
                    });
                }
            });
            
            console.log('Parsed elements:', elements);
            
            // If no elements found, create some sample content
            if (elements.length === 0) {
                console.log('No elements found, creating sample content...');
                elements = this.createSampleContent();
            }
            
            // Add elements to builder data
            this.builderData.elements = elements;
            
            // Render elements if builder is open
            if ($('#flexipro-visual-builder').length > 0) {
                this.renderAllElements();
            }
        },
        
        createSampleContent: function() {
            return [
                {
                    id: 'element_1',
                    type: 'heading',
                    data: {
                        content: 'Welcome to Your Page',
                        settings: {
                            level: '1',
                            tag: 'h1',
                            color: '#333',
                            font_size: '32px',
                            align: 'center',
                            margin: '0 0 20px 0'
                        }
                    }
                },
                {
                    id: 'element_2',
                    type: 'text',
                    data: {
                        content: 'This is a sample paragraph. You can edit this text by clicking on it in the visual builder. Add more elements from the sidebar to build your page.',
                        settings: {
                            color: '#666',
                            font_size: '16px',
                            align: 'left',
                            line_height: '1.6',
                            margin: '0 0 20px 0'
                        }
                    }
                },
                {
                    id: 'element_3',
                    type: 'button',
                    data: {
                        content: 'Get Started',
                        settings: {
                            url: '#',
                            bg_color: '#007cba',
                            text_color: '#fff',
                            padding: '12px 24px',
                            border_radius: '4px',
                            align: 'center'
                        }
                    }
                }
            ];
        },
        
        renderAllElements: function() {
            console.log('Rendering all elements:', this.builderData.elements);
            
            var $canvas = $('#builder-canvas');
            if ($canvas.length === 0) {
                console.log('Canvas not found, cannot render elements');
                return;
            }
            
            // Clear existing content
            $canvas.empty();
            
            // Hide placeholder
            this.hidePlaceholder();
            
            // Check if we have elements to render
            if (this.builderData.elements.length === 0) {
                console.log('No elements to render');
                this.showNoContentMessage();
                return;
            }
            
            // Render each element
            this.builderData.elements.forEach(function(element) {
                console.log('Rendering element:', element);
                this.renderElement(element);
            }.bind(this));
            
            console.log('All elements rendered successfully');
            console.log('Canvas children count:', $canvas.children().length);
        },
        
        bindEvents: function() {
            console.log('Binding events...');
            
            // Builder button click
            $(document).on('click', '#open-visual-builder', this.openBuilder.bind(this));
            $(document).on('click', '.flexipro-builder-trigger', this.openBuilder.bind(this));
            $(document).on('click', '#flexipro-visual-builder', this.openBuilder.bind(this));
            $(document).on('click', '#close-builder', this.closeBuilder.bind(this));
            $(document).on('click', '.close-builder', this.closeBuilder.bind(this));
            $(document).on('click', '[data-action="close"]', this.closeBuilder.bind(this));
            
            // ESC key to close builder
            $(document).on('keydown', function(e) {
                if (e.keyCode === 27 && this.isOpen) { // ESC key
                    this.closeBuilder(e);
                }
            }.bind(this));
            
            // Element management - Use more specific selectors
            $(document).on('click', '.element-item', function(e) {
                console.log('Element item clicked:', $(this).data('type'));
                e.preventDefault();
                e.stopPropagation();
                FlexiProBuilder.addElement.call(FlexiProBuilder, e);
            });
            
            // Drag and drop functionality
            $(document).on('dragstart', '.element-item', this.dragStart.bind(this));
            $(document).on('dragover', '.builder-canvas, .builder-container, .builder-section, .builder-row', this.dragOver.bind(this));
            $(document).on('drop', '.builder-canvas, .builder-container, .builder-section, .builder-row', this.drop.bind(this));
            $(document).on('dragend', '.element-item', this.dragEnd.bind(this));
            
            $(document).on('click', '.element-controls .delete', this.deleteElement.bind(this));
            $(document).on('click', '.element-controls .edit', this.editElement.bind(this));
            
            // Settings
            $(document).on('change', '.element-settings input, .element-settings select, .element-settings textarea', this.updateElement.bind(this));
            $(document).on('click', '#test-add-element', this.testAddElement.bind(this));
            $(document).on('click', '.save-builder', this.saveBuilder.bind(this));
            $(document).on('click', '.preview-builder', this.previewBuilder.bind(this));
            $(document).on('click', '.publish-builder', this.publishBuilder.bind(this));
            
            // Element selection
            $(document).on('click', '.builder-element', this.selectElement.bind(this));
            $(document).on('click', '.builder-canvas', this.deselectAll.bind(this));
            
            // Load current content button
            $(document).on('click', '#load-current-content', function(e) {
                e.preventDefault();
                console.log('Load current content button clicked');
                this.loadExistingContent();
            }.bind(this));
            
            // Test close button
            $(document).on('click', '#test-close', function(e) {
                e.preventDefault();
                console.log('Test close button clicked');
                this.closeBuilder(e);
            }.bind(this));
            
            console.log('Events bound successfully');
        },
        
        openBuilder: function(e) {
            e.preventDefault();
            console.log('Opening visual builder...', e.target);
            
            if (this.isOpen) return;
            
            this.isOpen = true;
            this.createBuilderInterface();
            
            // Load existing content when builder opens
            setTimeout(function() {
                this.loadExistingContent();
            }.bind(this), 100);
            
            this.showNotification('Visual Builder opened!', 'success');
        },
        
        createBuilderInterface: function() {
            console.log('Creating builder interface...');
            var builderHTML = `
                <div id="flexipro-visual-builder" class="flexipro-builder-overlay">
                    <!-- Close overlay background -->
                    <div class="builder-overlay-bg" data-action="close"></div>
                    
                    <div class="builder-container">
                        <!-- Builder Header -->
                        <div class="builder-header">
                            <div class="builder-title">
                                <h2><i class="dashicons dashicons-admin-customizer"></i> Visual Page Builder</h2>
                                <span class="builder-status">Live Editing</span>
                            </div>
                            <div class="builder-actions">
                                <button class="btn btn-secondary" id="test-add-element" title="Test Add Element">
                                    <i class="dashicons dashicons-plus"></i>
                                    Test Add
                                </button>
                                <button class="btn btn-warning" id="test-close" title="Test Close">
                                    <i class="dashicons dashicons-no"></i>
                                    Test Close
                                </button>
                                <button class="btn btn-secondary preview-builder" title="Preview">
                                    <i class="dashicons dashicons-visibility"></i>
                                    Preview
                                </button>
                                <button class="btn btn-primary save-builder" title="Save">
                                    <i class="dashicons dashicons-yes"></i>
                                    Save
                                </button>
                                <button class="btn btn-success publish-builder" title="Publish">
                                    <i class="dashicons dashicons-upload"></i>
                                    Publish
                                </button>
                                <button class="btn btn-danger" id="close-builder" title="Close">
                                    <i class="dashicons dashicons-no"></i>
                                    Close
                                </button>
                            </div>
                        </div>
                        
                        <!-- Builder Content -->
                        <div class="builder-content">
                            <!-- Left Sidebar -->
                            <div class="builder-sidebar">
                                <!-- Structural Elements Panel -->
                                <div class="builder-panel">
                                    <h3><i class="dashicons dashicons-layout"></i> Structure</h3>
                                    <div class="elements-grid">
                                        <div class="element-item" data-type="container" draggable="true">
                                            <i class="dashicons dashicons-layout"></i>
                                            <span>Container</span>
                                        </div>
                                        <div class="element-item" data-type="row" draggable="true">
                                            <i class="dashicons dashicons-editor-table"></i>
                                            <span>Row</span>
                                        </div>
                                        <div class="element-item" data-type="column" draggable="true">
                                            <i class="dashicons dashicons-grid-view"></i>
                                            <span>Column</span>
                                        </div>
                                        <div class="element-item" data-type="section" draggable="true">
                                            <i class="dashicons dashicons-screenoptions"></i>
                                            <span>Section</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Content Elements Panel -->
                                <div class="builder-panel">
                                    <h3><i class="dashicons dashicons-plus-alt"></i> Content</h3>
                                    <div class="elements-grid">
                                        <div class="element-item" data-type="text" draggable="true">
                                            <i class="dashicons dashicons-editor-textcolor"></i>
                                            <span>Text</span>
                                        </div>
                                        <div class="element-item" data-type="heading" draggable="true">
                                            <i class="dashicons dashicons-editor-textcolor"></i>
                                            <span>Heading</span>
                                        </div>
                                        <div class="element-item" data-type="image" draggable="true">
                                            <i class="dashicons dashicons-format-image"></i>
                                            <span>Image</span>
                                        </div>
                                        <div class="element-item" data-type="button" draggable="true">
                                            <i class="dashicons dashicons-admin-links"></i>
                                            <span>Button</span>
                                        </div>
                                        <div class="element-item" data-type="video" draggable="true">
                                            <i class="dashicons dashicons-video-alt3"></i>
                                            <span>Video</span>
                                        </div>
                                        <div class="element-item" data-type="spacer" draggable="true">
                                            <i class="dashicons dashicons-image-flip-vertical"></i>
                                            <span>Spacer</span>
                                        </div>
                                        <div class="element-item" data-type="divider" draggable="true">
                                            <i class="dashicons dashicons-minus"></i>
                                            <span>Divider</span>
                                        </div>
                                        <div class="element-item" data-type="icon" draggable="true">
                                            <i class="dashicons dashicons-star-filled"></i>
                                            <span>Icon</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Advanced Elements Panel -->
                                <div class="builder-panel">
                                    <h3><i class="dashicons dashicons-admin-tools"></i> Advanced</h3>
                                    <div class="elements-grid">
                                        <div class="element-item" data-type="testimonial" draggable="true">
                                            <i class="dashicons dashicons-format-quote"></i>
                                            <span>Testimonial</span>
                                        </div>
                                        <div class="element-item" data-type="team" draggable="true">
                                            <i class="dashicons dashicons-groups"></i>
                                            <span>Team</span>
                                        </div>
                                        <div class="element-item" data-type="pricing" draggable="true">
                                            <i class="dashicons dashicons-tag"></i>
                                            <span>Pricing</span>
                                        </div>
                                        <div class="element-item" data-type="counter" draggable="true">
                                            <i class="dashicons dashicons-chart-bar"></i>
                                            <span>Counter</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Main Canvas -->
                            <div class="builder-main">
                                <div class="builder-canvas" id="builder-canvas">
                                    <div class="canvas-placeholder">
                                        <div class="placeholder-content">
                                            <i class="dashicons dashicons-plus-alt"></i>
                                            <h3>Start Building Your Page</h3>
                                            <p>Click on elements to add them to your page</p>
                                            <button class="button button-primary" id="load-current-content" style="margin-top: 15px;">
                                                <i class="dashicons dashicons-download"></i> Load Current Page Content
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Right Sidebar -->
                            <div class="builder-sidebar-right">
                                <!-- Element Settings -->
                                <div class="builder-panel">
                                    <h3><i class="dashicons dashicons-admin-settings"></i> Settings</h3>
                                    <div class="element-settings" id="element-settings">
                                        <p>Select an element to edit its settings</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            $('body').append(builderHTML);
            $('body').addClass('builder-open');
            
            // Test canvas after creation
            setTimeout(function() {
                console.log('Testing canvas after creation...');
                console.log('Canvas exists:', $('#builder-canvas').length > 0);
                console.log('Canvas element:', $('#builder-canvas')[0]);
                console.log('Element items count:', $('.element-item').length);
            }, 100);
        },
        
        addElement: function(e) {
            console.log('addElement called with event:', e);
            e.preventDefault();
            
            var $clickedElement = $(e.target).closest('.element-item');
            var elementType = $clickedElement.data('type');
            
            console.log('Adding element:', elementType);
            console.log('Clicked element:', $clickedElement);
            console.log('Element type from data:', elementType);
            
            if (!elementType) {
                console.error('No element type found!');
                this.showNotification('Error: No element type found', 'error');
                return;
            }
            
            var elementId = 'element_' + Date.now();
            var element = {
                id: elementId,
                type: elementType,
                data: {
                    content: 'Click to edit',
                    settings: this.getDefaultSettings(elementType)
                }
            };
            
            console.log('Created element object:', element);
            
            this.builderData.elements.push(element);
            console.log('Element added to builderData. Total elements:', this.builderData.elements.length);
            
            this.renderElement(element);
            this.hidePlaceholder();
            this.selectElement(null, elementId);
            this.showNotification(elementType.charAt(0).toUpperCase() + elementType.slice(1) + ' element added!', 'success');
        },
        
        renderElement: function(element) {
            console.log('Rendering element:', element);
            
            var elementHTML = `
                <div class="builder-element" data-id="${element.id}" data-type="${element.type}">
                    <div class="element-content">
                        ${this.getElementPreview(element)}
                    </div>
                    <div class="element-controls">
                        <button class="btn btn-sm edit" title="Edit">
                            <i class="dashicons dashicons-edit"></i>
                        </button>
                        <button class="btn btn-sm delete" title="Delete">
                            <i class="dashicons dashicons-trash"></i>
                        </button>
                    </div>
                </div>
            `;
            
            console.log('Element HTML:', elementHTML);
            console.log('Canvas element:', $('#builder-canvas'));
            console.log('Canvas length:', $('#builder-canvas').length);
            
            $('#builder-canvas').append(elementHTML);
            
            console.log('Element appended to canvas');
            console.log('Canvas children count:', $('#builder-canvas').children().length);
        },
        
        getElementPreview: function(element) {
            // Use frontend renderer for accurate preview
            return this.renderElementForBuilder(element);
        },
        
        renderElementForBuilder: function(element) {
            // Use the same rendering logic as frontend for consistency
            return this.renderElementAsHTML(element, true); // true = builder mode
        },
        
        renderElementAsHTML: function(element, isBuilderMode = false) {
            var type = element.type;
            var content = element.data.content || '';
            var settings = element.data.settings || {};
            
            // Add builder-specific classes and styles for visual editing
            var builderClass = isBuilderMode ? ' builder-element' : '';
            var builderStyle = isBuilderMode ? '; outline: 2px dashed #007cba; outline-offset: 2px; position: relative;' : '';
            
            switch (type) {
                case 'container':
                    if (isBuilderMode) {
                        return `<div class="builder-container flexipro-container${builderClass}" style="background: ${settings.bg_color || '#f8f9fa'}; padding: ${settings.padding || '20px'}; border: 2px dashed #ddd; border-radius: 4px; min-height: 100px;${builderStyle}">
                            <div style="text-align: center; color: #666; padding: 20px;">
                                <i class="dashicons dashicons-layout" style="font-size: 24px; margin-bottom: 10px; display: block;"></i>
                                <div>Container</div>
                                <div style="font-size: 12px; margin-top: 5px;">Drop elements here</div>
                            </div>
                        </div>`;
                    } else {
                        return `<div class="flexipro-container" style="background: ${settings.bg_color || '#f8f9fa'}; padding: ${settings.padding || '20px'}; border-radius: 4px; min-height: 100px;">
                            ${content}
                        </div>`;
                    }
                
                case 'row':
                    if (isBuilderMode) {
                        return `<div class="builder-row flexipro-row${builderClass}" style="background: ${settings.bg_color || '#f8f9fa'}; padding: ${settings.padding || '10px'}; border: 2px dashed #dee2e6; border-radius: 8px; min-height: 120px; display: flex; gap: 20px; align-items: stretch;${builderStyle}">
                            <div style="text-align: center; color: #666; padding: 20px; flex: 1; display: flex; flex-direction: column; justify-content: center; align-items: center; background: rgba(255,255,255,0.8); border-radius: 6px; border: 1px dashed #ccc;">
                                <i class="dashicons dashicons-editor-table" style="font-size: 24px; margin-bottom: 8px; display: block; color: #3498db;"></i>
                                <div style="font-weight: 600; color: #2c3e50;">Row Container</div>
                                <div style="font-size: 12px; color: #7f8c8d; margin-top: 4px;">Drop columns here</div>
                            </div>
                        </div>`;
                    } else {
                        return `<div class="flexipro-row" style="background: ${settings.bg_color || '#f8f9fa'}; padding: ${settings.padding || '10px'}; border-radius: 8px; min-height: 120px; display: flex; gap: 20px; align-items: stretch;">
                            ${content}
                        </div>`;
                    }
                
                case 'column':
                    var width = settings.width || '1';
                    var fraction = this.getColumnFraction(width);
                    var percentage = this.getColumnPercentage(width);
                    
                    if (isBuilderMode) {
                        return `<div class="builder-column flexipro-column${builderClass}" data-width="${width}" style="background: ${settings.bg_color || '#fff'}; padding: ${settings.padding || '15px'}; border: 2px solid #3498db; border-radius: 6px; min-height: 80px; flex: 0 0 ${percentage}%; position: relative; box-shadow: 0 2px 4px rgba(0,0,0,0.1);${builderStyle}">
                            <div class="column-header" style="background: #3498db; color: white; padding: 4px 8px; border-radius: 4px 4px 0 0; margin: -15px -15px 10px -15px; font-size: 11px; font-weight: bold; text-align: center;">
                                ${fraction}
                            </div>
                            <div style="text-align: center; color: #666; padding: 10px;">
                                <i class="dashicons dashicons-grid-view" style="font-size: 20px; margin-bottom: 8px; display: block; color: #3498db;"></i>
                                <div style="font-weight: 600; color: #2c3e50;">Column</div>
                                <div style="font-size: 12px; color: #7f8c8d; margin-top: 4px;">${percentage}% width</div>
                            </div>
                            <div class="column-resize-handles">
                                <div class="resize-handle left"></div>
                                <div class="resize-handle right"></div>
                            </div>
                        </div>`;
                    } else {
                        return `<div class="flexipro-column" data-width="${width}" style="background: ${settings.bg_color || '#fff'}; padding: ${settings.padding || '15px'}; border-radius: 6px; min-height: 80px; flex: 0 0 ${percentage}%; position: relative;">
                            ${content}
                        </div>`;
                    }
                
                case 'section':
                    if (isBuilderMode) {
                        return `<div class="builder-section flexipro-section${builderClass}" style="background: ${settings.bg_color || '#f8f9fa'}; padding: ${settings.padding || '40px 20px'}; border: 2px dashed #ddd; border-radius: 6px; min-height: 120px; margin-bottom: 20px;${builderStyle}">
                            <div style="text-align: center; color: #666; padding: 20px;">
                                <i class="dashicons dashicons-screenoptions" style="font-size: 28px; margin-bottom: 10px; display: block;"></i>
                                <div>Section</div>
                                <div style="font-size: 12px; margin-top: 5px;">Full-width section container</div>
                            </div>
                        </div>`;
                    } else {
                        return `<div class="flexipro-section" style="background: ${settings.bg_color || '#f8f9fa'}; padding: ${settings.padding || '40px 20px'}; border-radius: 6px; min-height: 120px; margin-bottom: 20px;">
                            ${content}
                        </div>`;
                    }
                
                case 'text':
                    return `<div class="flexipro-text${builderClass}" style="text-align: ${settings.align || 'left'}; color: ${settings.color || '#333'}; font-size: ${settings.font_size || '16px'}; line-height: ${settings.line_height || '1.6'}; margin: 0 0 20px 0;${builderStyle}">
                        ${content || 'Click to edit text'}
                    </div>`;
                
                case 'heading':
                    var tag = settings.tag || 'h2';
                    var level = settings.level || '2';
                    return `<${tag} class="flexipro-heading${builderClass}" style="text-align: ${settings.align || 'left'}; color: ${settings.color || '#333'}; font-size: ${settings.font_size || '32px'}; margin: 0 0 20px 0; line-height: 1.2; font-weight: 600;${builderStyle}">
                        ${content || 'Click to edit heading'}
                    </${tag}>`;
                
                case 'image':
                    return `<div class="flexipro-image${builderClass}" style="text-align: ${settings.align || 'left'}; margin: 0 0 20px 0;${builderStyle}">
                        <img src="${content || 'https://via.placeholder.com/400x300'}" 
                             alt="${settings.alt || 'Image'}" 
                             style="max-width: ${settings.width || '100%'}; height: auto; border-radius: ${settings.border_radius || '0'};">
                    </div>`;
                
                case 'button':
                    return `<div style="text-align: ${settings.align || 'left'}; margin: 0 0 20px 0;">
                        <a href="${settings.url || '#'}" 
                           class="flexipro-button btn btn-primary${builderClass}"
                           style="background: ${settings.bg_color || '#3498db'}; color: ${settings.text_color || '#fff'}; padding: ${settings.padding || '10px 20px'}; border-radius: ${settings.border_radius || '4px'}; text-decoration: none; display: inline-block; font-weight: 600; transition: all 0.3s ease;${builderStyle}">
                            ${content || 'Click Here'}
                        </a>
                    </div>`;
                
                case 'video':
                    if (content) {
                        return `<div class="flexipro-video${builderClass}" style="width: ${settings.width || '100%'}; height: ${settings.height || '400px'}; margin: 0 0 20px 0;${builderStyle}">
                            <iframe src="${content}" 
                                    width="100%" 
                                    height="100%" 
                                    frameborder="0" 
                                    allowfullscreen>
                            </iframe>
                        </div>`;
                    } else {
                        return `<div class="flexipro-video${builderClass}" style="width: ${settings.width || '100%'}; height: ${settings.height || '400px'}; background: #f0f0f0; display: flex; align-items: center; justify-content: center; border: 2px dashed #ccc; border-radius: 4px; margin: 0 0 20px 0;${builderStyle}">
                            <span>Click to add video URL</span>
                        </div>`;
                    }
                
                case 'spacer':
                    return `<div class="flexipro-spacer${builderClass}" style="height: ${settings.height || '50px'}; width: 100%; margin: 0 0 20px 0;${builderStyle}">
                        ${isBuilderMode ? `<span style="color: #999; font-size: 12px; display: block; text-align: center; padding: 10px;">Spacer (${settings.height || '50px'})</span>` : ''}
                    </div>`;
                
                case 'divider':
                    return `<div style="width: ${settings.width || '100%'}; height: ${settings.thickness || '1px'}; background: ${settings.color || '#ddd'}; margin: 20px auto;"></div>`;
                
                case 'icon':
                    return `<div style="text-align: ${settings.align || 'left'};">
                        <span class="${settings.icon || 'dashicons-star-filled'}" 
                              style="font-size: ${settings.size || '32px'}; color: ${settings.color || '#333'};">
                        </span>
                    </div>`;
                
                default:
                    return `<div style="padding: 20px; background: #f0f0f0; border: 2px dashed #ccc; text-align: center; color: #666; border-radius: 4px;">
                        <i class="dashicons dashicons-star-filled" style="font-size: 48px; margin-bottom: 10px; display: block;"></i>
                        <div>${elementType.charAt(0).toUpperCase() + elementType.slice(1)} Element</div>
                    </div>`;
            }
        },
        
        getDefaultSettings: function(elementType) {
            var defaults = {
                container: {
                    bg_color: '#f8f9fa',
                    padding: '20px',
                    margin: '0',
                    border_radius: '4px'
                },
                row: {
                    bg_color: '#fff',
                    padding: '15px',
                    margin: '0',
                    gap: '10px'
                },
                column: {
                    bg_color: '#fff',
                    padding: '15px',
                    margin: '0',
                    width: '1',
                    flex: '1'
                },
                section: {
                    bg_color: '#f8f9fa',
                    padding: '40px 20px',
                    margin: '0 0 20px 0',
                    border_radius: '6px'
                },
                text: {
                    align: 'left',
                    color: '#333',
                    font_size: '16px'
                },
                heading: {
                    tag: 'h2',
                    align: 'left',
                    color: '#333',
                    font_size: '32px'
                },
                image: {
                    align: 'left',
                    width: '100%'
                },
                button: {
                    style: 'primary',
                    align: 'left',
                    bg_color: '#3498db',
                    text_color: '#fff'
                },
                video: {
                    width: '100%',
                    height: '400px'
                },
                spacer: {
                    height: '50px'
                },
                divider: {
                    width: '100%',
                    thickness: '1px',
                    color: '#ddd'
                },
                icon: {
                    icon: 'dashicons-star-filled',
                    size: '32px',
                    color: '#333',
                    align: 'left'
                }
            };
            
            return defaults[elementType] || {};
        },
        
        selectElement: function(e, elementId) {
            if (e) {
                e.stopPropagation();
                elementId = $(e.currentTarget).data('id');
            }
            
            // Remove previous selection
            $('.builder-element').removeClass('selected');
            
            // Select current element
            if (elementId) {
                $('.builder-element[data-id="' + elementId + '"]').addClass('selected');
                this.currentElement = elementId;
                this.showElementSettings(elementId);
            }
        },
        
        deselectAll: function(e) {
            if (e && $(e.target).closest('.builder-element, .element-controls').length) {
                return;
            }
            
            $('.builder-element').removeClass('selected');
            this.currentElement = null;
            $('#element-settings').html('<p>Select an element to edit its settings</p>');
        },
        
        showElementSettings: function(elementId) {
            var element = this.getElementData(elementId);
            if (!element) return;
            
            var elementType = element.type;
            var settings = element.data.settings || {};
            
            var settingsHTML = `
                <div class="element-settings-header">
                    <h4>${elementType.charAt(0).toUpperCase() + elementType.slice(1)} Settings</h4>
                </div>
                <div class="settings-content">
                    ${this.getElementSettingsHTML(elementType, settings)}
                </div>
            `;
            
            $('#element-settings').html(settingsHTML);
        },
        
        getElementData: function(elementId) {
            for (var i = 0; i < this.builderData.elements.length; i++) {
                if (this.builderData.elements[i].id === elementId) {
                    return this.builderData.elements[i];
                }
            }
            return null;
        },
        
        getElementSettingsHTML: function(elementType, settings) {
            var html = '';
            
            // Common settings
            html += `
                <div class="setting-group">
                    <label>Background Color</label>
                    <input type="color" name="bg_color" value="${settings.bg_color || '#ffffff'}">
                </div>
                <div class="setting-group">
                    <label>Padding</label>
                    <input type="text" name="padding" value="${settings.padding || '20px'}">
                </div>
            `;
            
            // Element-specific settings
            switch (elementType) {
                case 'container':
                    html += `
                        <div class="setting-group">
                            <label>Background Color</label>
                            <input type="color" name="bg_color" value="${settings.bg_color || '#f8f9fa'}">
                        </div>
                        <div class="setting-group">
                            <label>Padding</label>
                            <input type="text" name="padding" value="${settings.padding || '20px'}">
                        </div>
                        <div class="setting-group">
                            <label>Margin</label>
                            <input type="text" name="margin" value="${settings.margin || '0'}">
                        </div>
                        <div class="setting-group">
                            <label>Border Radius</label>
                            <input type="text" name="border_radius" value="${settings.border_radius || '4px'}">
                        </div>
                    `;
                    break;
                
                case 'row':
                    html += `
                        <div class="setting-group">
                            <label>Background Color</label>
                            <input type="color" name="bg_color" value="${settings.bg_color || '#fff'}">
                        </div>
                        <div class="setting-group">
                            <label>Padding</label>
                            <input type="text" name="padding" value="${settings.padding || '15px'}">
                        </div>
                        <div class="setting-group">
                            <label>Gap Between Columns</label>
                            <input type="text" name="gap" value="${settings.gap || '10px'}">
                        </div>
                        <div class="setting-group">
                            <label>Margin</label>
                            <input type="text" name="margin" value="${settings.margin || '0'}">
                        </div>
                    `;
                    break;
                
                case 'column':
                    html += `
                        <div class="setting-group">
                            <label>Column Width (1-12)</label>
                            <select name="width">
                                <option value="1" ${settings.width === '1' ? 'selected' : ''}>1/12</option>
                                <option value="2" ${settings.width === '2' ? 'selected' : ''}>2/12</option>
                                <option value="3" ${settings.width === '3' ? 'selected' : ''}>3/12</option>
                                <option value="4" ${settings.width === '4' ? 'selected' : ''}>4/12</option>
                                <option value="6" ${settings.width === '6' ? 'selected' : ''}>6/12</option>
                                <option value="8" ${settings.width === '8' ? 'selected' : ''}>8/12</option>
                                <option value="9" ${settings.width === '9' ? 'selected' : ''}>9/12</option>
                                <option value="12" ${settings.width === '12' ? 'selected' : ''}>12/12</option>
                            </select>
                        </div>
                        <div class="setting-group">
                            <label>Background Color</label>
                            <input type="color" name="bg_color" value="${settings.bg_color || '#fff'}">
                        </div>
                        <div class="setting-group">
                            <label>Padding</label>
                            <input type="text" name="padding" value="${settings.padding || '15px'}">
                        </div>
                        <div class="setting-group">
                            <label>Margin</label>
                            <input type="text" name="margin" value="${settings.margin || '0'}">
                        </div>
                    `;
                    break;
                
                case 'section':
                    html += `
                        <div class="setting-group">
                            <label>Background Color</label>
                            <input type="color" name="bg_color" value="${settings.bg_color || '#f8f9fa'}">
                        </div>
                        <div class="setting-group">
                            <label>Padding</label>
                            <input type="text" name="padding" value="${settings.padding || '40px 20px'}">
                        </div>
                        <div class="setting-group">
                            <label>Margin</label>
                            <input type="text" name="margin" value="${settings.margin || '0 0 20px 0'}">
                        </div>
                        <div class="setting-group">
                            <label>Border Radius</label>
                            <input type="text" name="border_radius" value="${settings.border_radius || '6px'}">
                        </div>
                    `;
                    break;
                
                case 'text':
                    html += `
                        <div class="setting-group">
                            <label>Content</label>
                            <textarea name="content" rows="4">${settings.content || 'Click to edit text'}</textarea>
                        </div>
                        <div class="setting-group">
                            <label>Text Alignment</label>
                            <select name="align">
                                <option value="left" ${settings.align === 'left' ? 'selected' : ''}>Left</option>
                                <option value="center" ${settings.align === 'center' ? 'selected' : ''}>Center</option>
                                <option value="right" ${settings.align === 'right' ? 'selected' : ''}>Right</option>
                            </select>
                        </div>
                        <div class="setting-group">
                            <label>Text Color</label>
                            <input type="color" name="color" value="${settings.color || '#333'}">
                        </div>
                        <div class="setting-group">
                            <label>Font Size</label>
                            <input type="text" name="font_size" value="${settings.font_size || '16px'}">
                        </div>
                    `;
                    break;
                
                case 'heading':
                    html += `
                        <div class="setting-group">
                            <label>Heading Text</label>
                            <input type="text" name="text" value="${settings.text || 'Click to edit heading'}">
                        </div>
                        <div class="setting-group">
                            <label>Heading Tag</label>
                            <select name="tag">
                                <option value="h1" ${settings.tag === 'h1' ? 'selected' : ''}>H1</option>
                                <option value="h2" ${settings.tag === 'h2' ? 'selected' : ''}>H2</option>
                                <option value="h3" ${settings.tag === 'h3' ? 'selected' : ''}>H3</option>
                                <option value="h4" ${settings.tag === 'h4' ? 'selected' : ''}>H4</option>
                                <option value="h5" ${settings.tag === 'h5' ? 'selected' : ''}>H5</option>
                                <option value="h6" ${settings.tag === 'h6' ? 'selected' : ''}>H6</option>
                            </select>
                        </div>
                        <div class="setting-group">
                            <label>Text Alignment</label>
                            <select name="align">
                                <option value="left" ${settings.align === 'left' ? 'selected' : ''}>Left</option>
                                <option value="center" ${settings.align === 'center' ? 'selected' : ''}>Center</option>
                                <option value="right" ${settings.align === 'right' ? 'selected' : ''}>Right</option>
                            </select>
                        </div>
                        <div class="setting-group">
                            <label>Text Color</label>
                            <input type="color" name="color" value="${settings.color || '#333'}">
                        </div>
                        <div class="setting-group">
                            <label>Font Size</label>
                            <input type="text" name="font_size" value="${settings.font_size || '32px'}">
                        </div>
                    `;
                    break;
                
                case 'image':
                    html += `
                        <div class="setting-group">
                            <label>Image URL</label>
                            <input type="url" name="src" value="${settings.src || ''}" placeholder="https://example.com/image.jpg">
                        </div>
                        <div class="setting-group">
                            <label>Alt Text</label>
                            <input type="text" name="alt" value="${settings.alt || ''}">
                        </div>
                        <div class="setting-group">
                            <label>Alignment</label>
                            <select name="align">
                                <option value="left" ${settings.align === 'left' ? 'selected' : ''}>Left</option>
                                <option value="center" ${settings.align === 'center' ? 'selected' : ''}>Center</option>
                                <option value="right" ${settings.align === 'right' ? 'selected' : ''}>Right</option>
                            </select>
                        </div>
                        <div class="setting-group">
                            <label>Width</label>
                            <input type="text" name="width" value="${settings.width || '100%'}">
                        </div>
                    `;
                    break;
                
                case 'button':
                    html += `
                        <div class="setting-group">
                            <label>Button Text</label>
                            <input type="text" name="text" value="${settings.text || 'Click Here'}">
                        </div>
                        <div class="setting-group">
                            <label>Button URL</label>
                            <input type="url" name="url" value="${settings.url || '#'}">
                        </div>
                        <div class="setting-group">
                            <label>Background Color</label>
                            <input type="color" name="bg_color" value="${settings.bg_color || '#3498db'}">
                        </div>
                        <div class="setting-group">
                            <label>Text Color</label>
                            <input type="color" name="text_color" value="${settings.text_color || '#fff'}">
                        </div>
                        <div class="setting-group">
                            <label>Alignment</label>
                            <select name="align">
                                <option value="left" ${settings.align === 'left' ? 'selected' : ''}>Left</option>
                                <option value="center" ${settings.align === 'center' ? 'selected' : ''}>Center</option>
                                <option value="right" ${settings.align === 'right' ? 'selected' : ''}>Right</option>
                            </select>
                        </div>
                    `;
                    break;
                
                case 'spacer':
                    html += `
                        <div class="setting-group">
                            <label>Height</label>
                            <input type="text" name="height" value="${settings.height || '50px'}">
                        </div>
                    `;
                    break;
                
                case 'divider':
                    html += `
                        <div class="setting-group">
                            <label>Width</label>
                            <input type="text" name="width" value="${settings.width || '100%'}">
                        </div>
                        <div class="setting-group">
                            <label>Thickness</label>
                            <input type="text" name="thickness" value="${settings.thickness || '1px'}">
                        </div>
                        <div class="setting-group">
                            <label>Color</label>
                            <input type="color" name="color" value="${settings.color || '#ddd'}">
                        </div>
                    `;
                    break;
                
                case 'icon':
                    html += `
                        <div class="setting-group">
                            <label>Icon</label>
                            <select name="icon">
                                <option value="dashicons-star-filled" ${settings.icon === 'dashicons-star-filled' ? 'selected' : ''}>Star</option>
                                <option value="dashicons-heart" ${settings.icon === 'dashicons-heart' ? 'selected' : ''}>Heart</option>
                                <option value="dashicons-thumbs-up" ${settings.icon === 'dashicons-thumbs-up' ? 'selected' : ''}>Thumbs Up</option>
                                <option value="dashicons-phone" ${settings.icon === 'dashicons-phone' ? 'selected' : ''}>Phone</option>
                                <option value="dashicons-email" ${settings.icon === 'dashicons-email' ? 'selected' : ''}>Email</option>
                            </select>
                        </div>
                        <div class="setting-group">
                            <label>Size</label>
                            <input type="text" name="size" value="${settings.size || '32px'}">
                        </div>
                        <div class="setting-group">
                            <label>Color</label>
                            <input type="color" name="color" value="${settings.color || '#333'}">
                        </div>
                        <div class="setting-group">
                            <label>Alignment</label>
                            <select name="align">
                                <option value="left" ${settings.align === 'left' ? 'selected' : ''}>Left</option>
                                <option value="center" ${settings.align === 'center' ? 'selected' : ''}>Center</option>
                                <option value="right" ${settings.align === 'right' ? 'selected' : ''}>Right</option>
                            </select>
                        </div>
                    `;
                    break;
            }
            
            return html;
        },
        
        updateElement: function() {
            if (!this.currentElement) return;
            
            var element = this.getElementData(this.currentElement);
            if (!element) return;
            
            // Update element data based on form inputs
            var form = $(this).closest('.element-settings');
            var settings = {};
            
            form.find('input, select, textarea').each(function() {
                var $this = $(this);
                var name = $this.attr('name');
                var value = $this.val();
                
                if (name === 'content' || name === 'text') {
                    element.data.content = value;
                } else {
                    settings[name] = value;
                }
            });
            
            element.data.settings = settings;
            
            // Update element preview
            var elementEl = $('.builder-element[data-id="' + this.currentElement + '"]');
            elementEl.find('.element-content').html(this.getElementPreview(element));
        },
        
        deleteElement: function(e) {
            e.preventDefault();
            var element = $(this).closest('.builder-element');
            var elementId = element.data('id');
            
            if (confirm('Are you sure you want to delete this element?')) {
                // Remove from data
                for (var i = 0; i < this.builderData.elements.length; i++) {
                    if (this.builderData.elements[i].id === elementId) {
                        this.builderData.elements.splice(i, 1);
                        break;
                    }
                }
                
                // Remove from DOM
                element.remove();
                
                // Show placeholder if no elements
                if (this.builderData.elements.length === 0) {
                    this.showPlaceholder();
                }
                
                this.showNotification('Element deleted!', 'success');
            }
        },
        
        editElement: function(e) {
            e.preventDefault();
            // Edit functionality can be added here
            this.showNotification('Edit mode activated!', 'info');
        },
        
        saveBuilder: function(e) {
            e.preventDefault();
            this.showNotification('Builder data saved!', 'success');
        },
        
        previewBuilder: function(e) {
            e.preventDefault();
            var previewUrl = window.location.href + '?flexipro_preview=1';
            window.open(previewUrl, '_blank');
        },
        
        publishBuilder: function(e) {
            e.preventDefault();
            this.showNotification('Page published!', 'success');
        },
        
        closeBuilder: function(e) {
            console.log('Close builder called', e);
            e.preventDefault();
            e.stopPropagation();
            
            // Save content before closing
            this.saveContent();
            
            // Remove builder interface
            $('#flexipro-visual-builder').fadeOut(300, function() {
                $(this).remove();
            });
            
            $('body').removeClass('builder-open');
            this.isOpen = false;
            
            // Show success message
            this.showNotification('Visual Builder closed!', 'info');
        },
        
        saveContent: function() {
            console.log('Saving content...');
            
            if (typeof flexiproBuilder !== 'undefined' && flexiproBuilder.postId) {
                // Save to post meta
                $.ajax({
                    url: flexiproBuilder.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'flexipro_save_builder_data',
                        post_id: flexiproBuilder.postId,
                        builder_data: JSON.stringify(this.builderData),
                        nonce: flexiproBuilder.nonce
                    },
                    success: function(response) {
                        console.log('Content saved successfully:', response);
                    },
                    error: function() {
                        console.log('Error saving content');
                    }
                });
            } else {
                // Update the page content directly
                this.updatePageContent();
            }
        },
        
        updatePageContent: function() {
            console.log('Updating page content...');
            
            // Find the content area
            var $content = $('.entry-content, .post-content, .page-content, .content');
            
            if ($content.length === 0) {
                console.log('No content area found');
                return;
            }
            
            // Clear existing content
            $content.empty();
            
            // Render elements as HTML
            var html = '';
            this.builderData.elements.forEach(function(element) {
                html += this.renderElementAsHTML(element);
            }.bind(this));
            
            // Update content
            $content.html(html);
            
            console.log('Page content updated');
        },
        
        
        showPlaceholder: function() {
            $('.canvas-placeholder').show();
        },
        
        hidePlaceholder: function() {
            $('.canvas-placeholder').hide();
        },
        
        showNotification: function(message, type) {
            var notification = $('<div class="builder-notification ' + type + '">' + message + '</div>');
            $('body').append(notification);
            
            setTimeout(function() {
                notification.fadeOut(function() {
                    notification.remove();
                });
            }, 3000);
        },
        
        testAddElement: function(e) {
            e.preventDefault();
            console.log('Test add element clicked');
            
            var elementId = 'test_element_' + Date.now();
            var element = {
                id: elementId,
                type: 'text',
                data: {
                    content: 'Test element added!',
                    settings: this.getDefaultSettings('text')
                }
            };
            
            console.log('Test element created:', element);
            this.builderData.elements.push(element);
            this.renderElement(element);
            this.hidePlaceholder();
            this.showNotification('Test element added!', 'success');
        },
        
        // Drag and Drop Methods
        dragStart: function(e) {
            console.log('Drag started:', e.target);
            this.draggedElement = $(e.target).closest('.element-item');
            this.draggedElementType = this.draggedElement.data('type');
            e.originalEvent.dataTransfer.effectAllowed = 'copy';
            e.originalEvent.dataTransfer.setData('text/plain', this.draggedElementType);
            
            // Add visual feedback
            this.draggedElement.addClass('dragging');
            $('body').addClass('dragging');
        },
        
        dragOver: function(e) {
            e.preventDefault();
            e.originalEvent.dataTransfer.dropEffect = 'copy';
            
            // Add drop zone highlighting
            var $target = $(e.target).closest('.builder-canvas, .builder-container, .builder-section, .builder-row');
            if ($target.length) {
                $target.addClass('drop-zone-active');
            }
        },
        
        drop: function(e) {
            e.preventDefault();
            console.log('Drop event triggered');
            
            var $target = $(e.target).closest('.builder-canvas, .builder-container, .builder-section, .builder-row');
            var elementType = e.originalEvent.dataTransfer.getData('text/plain');
            
            console.log('Dropped on:', $target);
            console.log('Element type:', elementType);
            
            if (elementType && $target.length) {
                // Create element
                var elementId = 'element_' + Date.now();
                var element = {
                    id: elementId,
                    type: elementType,
                    data: {
                        content: 'Click to edit',
                        settings: this.getDefaultSettings(elementType)
                    }
                };
                
                this.builderData.elements.push(element);
                
                // Render element in the correct container
                if ($target.hasClass('builder-canvas')) {
                    this.renderElement(element);
                } else {
                    this.renderElementInContainer(element, $target);
                }
                
                this.hidePlaceholder();
                this.selectElement(null, elementId);
                this.showNotification(elementType.charAt(0).toUpperCase() + elementType.slice(1) + ' element added!', 'success');
            }
            
            // Remove drop zone highlighting
            $('.drop-zone-active').removeClass('drop-zone-active');
        },
        
        dragEnd: function(e) {
            console.log('Drag ended');
            this.draggedElement = null;
            this.draggedElementType = null;
            
            // Remove visual feedback
            $('.element-item').removeClass('dragging');
            $('body').removeClass('dragging');
            $('.drop-zone-active').removeClass('drop-zone-active');
        },
        
        renderElementInContainer: function(element, $container) {
            console.log('Rendering element in container:', element, $container);
            
            var elementHTML = `
                <div class="builder-element" data-id="${element.id}" data-type="${element.type}">
                    <div class="element-content">
                        ${this.getElementPreview(element)}
                    </div>
                    <div class="element-controls">
                        <button class="btn btn-sm edit" title="Edit">
                            <i class="dashicons dashicons-edit"></i>
                        </button>
                        <button class="btn btn-sm delete" title="Delete">
                            <i class="dashicons dashicons-trash"></i>
                        </button>
                    </div>
                </div>
            `;
            
            // Add to the container
            if ($container.hasClass('builder-container') || $container.hasClass('builder-section')) {
                $container.append(elementHTML);
            } else if ($container.hasClass('builder-row')) {
                $container.append(elementHTML);
            } else {
                // Fallback to canvas
                $('#builder-canvas').append(elementHTML);
            }
        },
        
        // Helper functions for column proportions
        getColumnFraction: function(width) {
            var fractions = {
                '1': '1/12',
                '2': '1/6',
                '3': '1/4',
                '4': '1/3',
                '6': '1/2',
                '8': '2/3',
                '9': '3/4',
                '12': '1/1'
            };
            return fractions[width] || width + '/12';
        },
        
        getColumnPercentage: function(width) {
            var percentages = {
                '1': '8.333',
                '2': '16.666',
                '3': '25',
                '4': '33.333',
                '6': '50',
                '8': '66.666',
                '9': '75',
                '12': '100'
            };
            return percentages[width] || (width * 8.333).toFixed(1);
        }
    };
    
    // Initialize when document is ready
    $(document).ready(function() {
        console.log('Document ready, initializing FlexiPro Builder...');
        FlexiProBuilder.init();
        
        // Test if admin bar button exists
        if ($('.flexipro-builder-trigger').length > 0) {
            console.log('Admin bar button found!');
            // Add direct click handler as backup
            $('.flexipro-builder-trigger').on('click', function(e) {
                e.preventDefault();
                console.log('Admin bar button clicked directly!');
                FlexiProBuilder.openBuilder(e);
            });
        } else {
            console.log('Admin bar button not found');
        }
        
        // Test if meta box button exists
        if ($('#open-visual-builder').length > 0) {
            console.log('Meta box button found!');
        } else {
            console.log('Meta box button not found');
        }
        
        // Also check for the admin bar button by ID
        if ($('#flexipro-visual-builder').length > 0) {
            console.log('Admin bar button by ID found!');
            $('#flexipro-visual-builder').on('click', function(e) {
                e.preventDefault();
                console.log('Admin bar button by ID clicked!');
                FlexiProBuilder.openBuilder(e);
            });
        }
    });
    
})(jQuery);