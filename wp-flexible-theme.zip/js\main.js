/**
 * FlexiPro Main JavaScript
 * 
 * @package FlexiPro
 * @version 1.0.0
 */

jQuery(document).ready(function($) {
    
    // Mobile Menu Toggle
    $('.mobile-menu-toggle').click(function() {
        $(this).toggleClass('active');
        $('.main-navigation').toggleClass('active');
        $('body').toggleClass('menu-open');
    });
    
    // Close mobile menu when clicking outside
    $(document).click(function(e) {
        if (!$(e.target).closest('.main-navigation, .mobile-menu-toggle').length) {
            $('.mobile-menu-toggle').removeClass('active');
            $('.main-navigation').removeClass('active');
            $('body').removeClass('menu-open');
        }
    });
    
    // Smooth Scrolling for Anchor Links
    $('a[href^="#"]').click(function(e) {
        var target = $(this.getAttribute('href'));
        if (target.length) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: target.offset().top - 80
            }, 800);
        }
    });
    
    // Sticky Header
    function updateStickyHeader() {
        var header = $('.site-header');
        var scrollTop = $(window).scrollTop();
        
        if (scrollTop > 100) {
            header.addClass('scrolled');
        } else {
            header.removeClass('scrolled');
        }
    }
    
    $(window).on('scroll', function() {
        updateStickyHeader();
    });
    
    // Back to Top Button
    function updateBackToTop() {
        var backToTop = $('.back-to-top');
        var scrollTop = $(window).scrollTop();
        
        if (scrollTop > 300) {
            backToTop.addClass('visible');
        } else {
            backToTop.removeClass('visible');
        }
    }
    
    $(window).on('scroll', function() {
        updateBackToTop();
    });
    
    $('.back-to-top').click(function(e) {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: 0
        }, 800);
    });
    
    // Preloader
    $(window).on('load', function() {
        $('.preloader').fadeOut(500);
    });
    
    // Search Form Enhancement
    $('.search-form').submit(function(e) {
        var searchInput = $(this).find('input[type="search"]');
        if (!searchInput.val().trim()) {
            e.preventDefault();
            searchInput.focus();
        }
    });
    
    // Newsletter Subscription
    $('.newsletter-form').submit(function(e) {
        e.preventDefault();
        
        var form = $(this);
        var email = form.find('input[type="email"]').val();
        var submitBtn = form.find('button[type="submit"]');
        var originalText = submitBtn.text();
        
        if (!email) {
            alert('Please enter your email address');
            return;
        }
        
        submitBtn.text('Subscribing...').prop('disabled', true);
        
        // Simulate AJAX call
        setTimeout(function() {
            form.find('.newsletter-message').remove();
            form.after('<div class="newsletter-message success">Thank you for subscribing!</div>');
            form[0].reset();
            submitBtn.text(originalText).prop('disabled', false);
        }, 1000);
    });
    
    // Contact Form Validation
    $('.contact-form').submit(function(e) {
        var form = $(this);
        var isValid = true;
        
        // Remove previous error classes
        form.find('.form-group').removeClass('error');
        form.find('.error-message').remove();
        
        // Validate required fields
        form.find('input[required], textarea[required]').each(function() {
            var field = $(this);
            var value = field.val().trim();
            
            if (!value) {
                field.closest('.form-group').addClass('error');
                field.after('<span class="error-message">This field is required</span>');
                isValid = false;
            }
        });
        
        // Validate email
        var emailField = form.find('input[type="email"]');
        if (emailField.length && emailField.val()) {
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(emailField.val())) {
                emailField.closest('.form-group').addClass('error');
                emailField.after('<span class="error-message">Please enter a valid email address</span>');
                isValid = false;
            }
        }
        
        if (!isValid) {
            e.preventDefault();
            form.find('.error').first().find('input, textarea').focus();
        }
    });
    
    // Animation on Scroll
    function isElementInViewport(el) {
        var rect = el.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
    
    function handleScrollAnimations() {
        $('.flexipro-animate').each(function() {
            var element = $(this);
            
            if (isElementInViewport(element[0]) && !element.hasClass('animated')) {
                element.addClass('animated');
            }
        });
    }
    
    // Throttle function for scroll events
    function throttle(func, wait) {
        var timeout;
        return function executedFunction() {
            var later = function() {
                clearTimeout(timeout);
                func();
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // Scroll event listener
    $(window).on('scroll', throttle(handleScrollAnimations, 100));
    
    // Initial check
    handleScrollAnimations();
    
    // Counter Animation
    function animateCounters() {
        $('.counter').each(function() {
            var counter = $(this);
            var target = parseInt(counter.data('target'));
            var duration = parseInt(counter.data('duration')) || 2000;
            
            if (isElementInViewport(counter[0]) && !counter.hasClass('animated')) {
                counter.addClass('animated');
                
                $({ count: 0 }).animate({ count: target }, {
                    duration: duration,
                    easing: 'swing',
                    step: function() {
                        counter.text(Math.floor(this.count));
                    },
                    complete: function() {
                        counter.text(target);
                    }
                });
            }
        });
    }
    
    $(window).on('scroll', throttle(animateCounters, 100));
    animateCounters();
    
    // Progress Bar Animation
    function animateProgressBars() {
        $('.progress-bar').each(function() {
            var progressBar = $(this);
            var progressFill = progressBar.find('.progress-fill');
            var percentage = progressFill.data('percentage');
            
            if (isElementInViewport(progressBar[0]) && !progressBar.hasClass('animated')) {
                progressBar.addClass('animated');
                progressFill.css('width', percentage + '%');
            }
        });
    }
    
    $(window).on('scroll', throttle(animateProgressBars, 100));
    animateProgressBars();
    
    // Image Lazy Loading
    function lazyLoadImages() {
        $('img[data-src]').each(function() {
            var img = $(this);
            if (isElementInViewport(img[0])) {
                img.attr('src', img.data('src')).removeAttr('data-src');
                img.addClass('loaded');
            }
        });
    }
    
    $(window).on('scroll', throttle(lazyLoadImages, 100));
    lazyLoadImages();
    
    // Parallax Effect
    function updateParallax() {
        $('.parallax-element').each(function() {
            var element = $(this);
            var speed = element.data('speed') || 0.5;
            var yPos = -(window.pageYOffset * speed);
            element.css('transform', 'translateY(' + yPos + 'px)');
        });
    }
    
    $(window).on('scroll', throttle(updateParallax, 10));
    
    // Lightbox for Images
    $('a[href$=".jpg"], a[href$=".jpeg"], a[href$=".png"], a[href$=".gif"]').click(function(e) {
        if ($(this).hasClass('lightbox')) {
            e.preventDefault();
            
            var imageUrl = $(this).attr('href');
            var imageTitle = $(this).find('img').attr('alt') || '';
            
            var lightboxHtml = '<div class="lightbox-overlay">';
            lightboxHtml += '<div class="lightbox-content">';
            lightboxHtml += '<button class="lightbox-close">&times;</button>';
            lightboxHtml += '<img src="' + imageUrl + '" alt="' + imageTitle + '">';
            if (imageTitle) {
                lightboxHtml += '<div class="lightbox-caption">' + imageTitle + '</div>';
            }
            lightboxHtml += '</div>';
            lightboxHtml += '</div>';
            
            $('body').append(lightboxHtml);
            $('body').addClass('lightbox-open');
        }
    });
    
    // Close Lightbox
    $(document).on('click', '.lightbox-close, .lightbox-overlay', function(e) {
        if (e.target === this) {
            $('.lightbox-overlay').remove();
            $('body').removeClass('lightbox-open');
        }
    });
    
    // Close Lightbox with Escape key
    $(document).keyup(function(e) {
        if (e.keyCode === 27) {
            $('.lightbox-overlay').remove();
            $('body').removeClass('lightbox-open');
        }
    });
    
    // Accordion
    $('.accordion-item .accordion-title').click(function() {
        var item = $(this).closest('.accordion-item');
        var content = item.find('.accordion-content');
        
        if (item.hasClass('active')) {
            item.removeClass('active');
            content.slideUp(300);
        } else {
            $('.accordion-item').removeClass('active');
            $('.accordion-content').slideUp(300);
            item.addClass('active');
            content.slideDown(300);
        }
    });
    
    // Tabs
    $('.tabs-nav .tab-link').click(function(e) {
        e.preventDefault();
        
        var tabId = $(this).data('tab');
        var tabContent = $('#' + tabId);
        
        $('.tab-link').removeClass('active');
        $(this).addClass('active');
        
        $('.tab-content').removeClass('active');
        tabContent.addClass('active');
    });
    
    // Toggle
    $('.toggle-title').click(function() {
        var toggle = $(this).closest('.toggle-item');
        var content = toggle.find('.toggle-content');
        
        toggle.toggleClass('active');
        content.slideToggle(300);
    });
    
    // Modal
    $('.modal-trigger').click(function(e) {
        e.preventDefault();
        var modalId = $(this).data('modal');
        $('#' + modalId).addClass('active');
        $('body').addClass('modal-open');
    });
    
    $('.modal-close, .modal-overlay').click(function() {
        $('.modal').removeClass('active');
        $('body').removeClass('modal-open');
    });
    
    // Close modal with Escape key
    $(document).keyup(function(e) {
        if (e.keyCode === 27) {
            $('.modal').removeClass('active');
            $('body').removeClass('modal-open');
        }
    });
    
    // Tooltip
    $('[data-tooltip]').hover(
        function() {
            var tooltip = $('<div class="tooltip">' + $(this).data('tooltip') + '</div>');
            $('body').append(tooltip);
            
            var offset = $(this).offset();
            tooltip.css({
                top: offset.top - tooltip.outerHeight() - 10,
                left: offset.left + ($(this).outerWidth() / 2) - (tooltip.outerWidth() / 2)
            });
        },
        function() {
            $('.tooltip').remove();
        }
    );
    
    // Social Share Buttons
    $('.social-share a').click(function(e) {
        e.preventDefault();
        
        var url = $(this).attr('href');
        var platform = $(this).data('platform');
        var shareUrl = '';
        
        switch (platform) {
            case 'facebook':
                shareUrl = 'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(url);
                break;
            case 'twitter':
                shareUrl = 'https://twitter.com/intent/tweet?url=' + encodeURIComponent(url);
                break;
            case 'linkedin':
                shareUrl = 'https://www.linkedin.com/sharing/share-offsite/?url=' + encodeURIComponent(url);
                break;
            case 'pinterest':
                shareUrl = 'https://pinterest.com/pin/create/button/?url=' + encodeURIComponent(url);
                break;
        }
        
        if (shareUrl) {
            window.open(shareUrl, 'share', 'width=600,height=400');
        }
    });
    
    // Video Background
    $('.video-background video').each(function() {
        var video = this;
        
        // Play video on hover
        $(video).closest('.video-background').hover(
            function() {
                video.play();
            },
            function() {
                video.pause();
            }
        );
    });
    
    // Initialize all components
    function initComponents() {
        handleScrollAnimations();
        lazyLoadImages();
        updateStickyHeader();
        updateBackToTop();
    }
    
    // Initialize on page load
    initComponents();
    
    // Re-initialize on window resize
    $(window).on('resize', throttle(initComponents, 250));
    
});
