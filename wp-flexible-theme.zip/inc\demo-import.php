<?php
/**
 * Demo Content Import - Similar to Avada Pro
 * 
 * @package FlexiPro
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class FlexiPro_Demo_Import {
    
    private $demos;
    
    public function __construct() {
        $this->init_demos();
        add_action('admin_menu', array($this, 'add_demo_import_page'));
        add_action('wp_ajax_flexipro_import_demo', array($this, 'ajax_import_demo'));
        add_action('wp_ajax_flexipro_reset_demo', array($this, 'ajax_reset_demo'));
    }
    
    private function init_demos() {
        $this->demos = array(
            'corporate' => array(
                'name' => 'Corporate Business',
                'description' => 'Professional corporate website with modern design',
                'preview' => FLEXIPRO_THEME_URL . '/demo-content/corporate/preview.jpg',
                'pages' => array('home', 'about', 'services', 'portfolio', 'blog', 'contact'),
                'features' => array('Hero Section', 'Services Grid', 'Portfolio Gallery', 'Team Members', 'Testimonials', 'Contact Form')
            ),
            'creative' => array(
                'name' => 'Creative Agency',
                'description' => 'Bold and creative design for agencies and freelancers',
                'preview' => FLEXIPRO_THEME_URL . '/demo-content/creative/preview.jpg',
                'pages' => array('home', 'about', 'work', 'services', 'blog', 'contact'),
                'features' => array('Animated Hero', 'Portfolio Showcase', 'Creative Services', 'Client Testimonials', 'Blog Layout', 'Contact Map')
            ),
            'ecommerce' => array(
                'name' => 'E-commerce Store',
                'description' => 'Complete online store with WooCommerce integration',
                'preview' => FLEXIPRO_THEME_URL . '/demo-content/ecommerce/preview.jpg',
                'pages' => array('home', 'shop', 'product', 'cart', 'checkout', 'my-account'),
                'features' => array('Product Showcase', 'Shopping Cart', 'Checkout Process', 'User Accounts', 'Product Reviews', 'Payment Integration')
            ),
            'portfolio' => array(
                'name' => 'Portfolio Showcase',
                'description' => 'Elegant portfolio for designers and photographers',
                'preview' => FLEXIPRO_THEME_URL . '/demo-content/portfolio/preview.jpg',
                'pages' => array('home', 'portfolio', 'about', 'blog', 'contact'),
                'features' => array('Portfolio Grid', 'Image Lightbox', 'About Section', 'Skills Display', 'Contact Form', 'Social Links')
            ),
            'restaurant' => array(
                'name' => 'Restaurant & Food',
                'description' => 'Appetizing design for restaurants and food businesses',
                'preview' => FLEXIPRO_THEME_URL . '/demo-content/restaurant/preview.jpg',
                'pages' => array('home', 'menu', 'about', 'gallery', 'reservations', 'contact'),
                'features' => array('Menu Display', 'Image Gallery', 'Reservation Form', 'Location Map', 'Reviews', 'Social Media')
            ),
            'medical' => array(
                'name' => 'Medical & Health',
                'description' => 'Clean and professional design for medical practices',
                'preview' => FLEXIPRO_THEME_URL . '/demo-content/medical/preview.jpg',
                'pages' => array('home', 'services', 'doctors', 'appointments', 'about', 'contact'),
                'features' => array('Service Listings', 'Doctor Profiles', 'Appointment Booking', 'Health Tips', 'Contact Info', 'Emergency Info')
            ),
            'education' => array(
                'name' => 'Education & Learning',
                'description' => 'Modern design for schools and educational institutions',
                'preview' => FLEXIPRO_THEME_URL . '/demo-content/education/preview.jpg',
                'pages' => array('home', 'courses', 'teachers', 'about', 'news', 'contact'),
                'features' => array('Course Listings', 'Teacher Profiles', 'News & Events', 'Student Resources', 'Admission Info', 'Contact Form')
            ),
            'real-estate' => array(
                'name' => 'Real Estate',
                'description' => 'Property showcase and real estate business',
                'preview' => FLEXIPRO_THEME_URL . '/demo-content/real-estate/preview.jpg',
                'pages' => array('home', 'properties', 'agents', 'about', 'blog', 'contact'),
                'features' => array('Property Listings', 'Agent Profiles', 'Property Search', 'Virtual Tours', 'Mortgage Calculator', 'Contact Forms')
            )
        );
    }
    
    public function add_demo_import_page() {
        add_submenu_page(
            'flexipro-options',
            __('Demo Import', 'flexipro'),
            __('Demo Import', 'flexipro'),
            'manage_options',
            'flexipro-demo-import',
            array($this, 'demo_import_page')
        );
    }
    
    public function demo_import_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Demo Content Import', 'flexipro'); ?></h1>
            <p><?php _e('Choose a demo to import and get started quickly with pre-built content and layouts.', 'flexipro'); ?></p>
            
            <div class="flexipro-demo-grid">
                <?php foreach ($this->demos as $key => $demo) : ?>
                    <div class="flexipro-demo-item" data-demo="<?php echo $key; ?>">
                        <div class="demo-preview">
                            <img src="<?php echo esc_url($demo['preview']); ?>" alt="<?php echo esc_attr($demo['name']); ?>">
                            <div class="demo-overlay">
                                <button class="button button-primary import-demo" data-demo="<?php echo $key; ?>">
                                    <?php _e('Import Demo', 'flexipro'); ?>
                                </button>
                                <button class="button preview-demo" data-demo="<?php echo $key; ?>">
                                    <?php _e('Preview', 'flexipro'); ?>
                                </button>
                            </div>
                        </div>
                        <div class="demo-info">
                            <h3><?php echo esc_html($demo['name']); ?></h3>
                            <p><?php echo esc_html($demo['description']); ?></p>
                            <div class="demo-features">
                                <h4><?php _e('Features:', 'flexipro'); ?></h4>
                                <ul>
                                    <?php foreach ($demo['features'] as $feature) : ?>
                                        <li><?php echo esc_html($feature); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="flexipro-import-options">
                <h2><?php _e('Import Options', 'flexipro'); ?></h2>
                <form id="flexipro-import-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Import Content', 'flexipro'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="import_pages" value="1" checked>
                                    <?php _e('Pages', 'flexipro'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="import_posts" value="1" checked>
                                    <?php _e('Posts', 'flexipro'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="import_media" value="1" checked>
                                    <?php _e('Media Files', 'flexipro'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="import_widgets" value="1" checked>
                                    <?php _e('Widgets', 'flexipro'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="import_menus" value="1" checked>
                                    <?php _e('Menus', 'flexipro'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" name="import_theme_options" value="1" checked>
                                    <?php _e('Theme Options', 'flexipro'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Reset Existing Content', 'flexipro'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="reset_content" value="1">
                                    <?php _e('Delete existing content before import', 'flexipro'); ?>
                                </label>
                                <p class="description"><?php _e('Warning: This will delete all existing pages, posts, and media.', 'flexipro'); ?></p>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            
            <div class="flexipro-import-progress" style="display: none;">
                <h3><?php _e('Importing Demo Content...', 'flexipro'); ?></h3>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 0%;"></div>
                </div>
                <div class="progress-text"><?php _e('Preparing import...', 'flexipro'); ?></div>
            </div>
        </div>
        
        <style>
        .flexipro-demo-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin: 30px 0;
        }
        .flexipro-demo-item {
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .flexipro-demo-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .demo-preview {
            position: relative;
            overflow: hidden;
        }
        .demo-preview img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            transition: transform 0.3s ease;
        }
        .flexipro-demo-item:hover .demo-preview img {
            transform: scale(1.05);
        }
        .demo-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .flexipro-demo-item:hover .demo-overlay {
            opacity: 1;
        }
        .demo-info {
            padding: 20px;
        }
        .demo-info h3 {
            margin: 0 0 10px 0;
            color: #333;
        }
        .demo-info p {
            color: #666;
            margin-bottom: 15px;
        }
        .demo-features h4 {
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #333;
        }
        .demo-features ul {
            margin: 0;
            padding-left: 20px;
        }
        .demo-features li {
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
        }
        .flexipro-import-options {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 30px 0;
        }
        .flexipro-import-progress {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 30px 0;
        }
        .progress-bar {
            width: 100%;
            height: 20px;
            background: #f0f0f0;
            border-radius: 10px;
            overflow: hidden;
            margin: 10px 0;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #0073aa, #00a0d2);
            transition: width 0.3s ease;
        }
        .progress-text {
            text-align: center;
            color: #666;
        }
        
        /* Demo Preview Modal */
        .demo-preview-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .demo-preview-modal .modal-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1;
        }
        
        .demo-preview-modal .modal-content {
            position: relative;
            background: #fff;
            border-radius: 8px;
            max-width: 800px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            z-index: 2;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .demo-preview-modal .modal-header {
            padding: 20px 30px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .demo-preview-modal .modal-header h3 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }
        
        .demo-preview-modal .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            color: #999;
            cursor: pointer;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s ease;
        }
        
        .demo-preview-modal .modal-close:hover {
            background: #f0f0f0;
            color: #333;
        }
        
        .demo-preview-modal .modal-body {
            padding: 30px;
        }
        
        .demo-preview-modal .modal-body img {
            width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .demo-preview-content {
            max-height: 500px;
            overflow-y: auto;
            border: 1px solid #eee;
            border-radius: 8px;
            margin-bottom: 20px;
            background: #fff;
        }
        
        .demo-preview-layout {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
        }
        
        .demo-preview-layout * {
            box-sizing: border-box;
        }
        
        .demo-preview-layout button {
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .demo-preview-layout button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .demo-preview-modal .demo-info h4 {
            margin: 0 0 15px 0;
            font-size: 18px;
            color: #333;
        }
        
        .demo-preview-modal .demo-info ul {
            margin: 0 0 20px 0;
            padding-left: 20px;
        }
        
        .demo-preview-modal .demo-info li {
            margin-bottom: 8px;
            color: #666;
        }
        
        .demo-preview-modal .demo-info p {
            margin: 0;
            color: #666;
            line-height: 1.6;
        }
        
        .demo-preview-modal .modal-footer {
            padding: 20px 30px;
            border-top: 1px solid #eee;
            display: flex;
            gap: 15px;
            justify-content: flex-end;
        }
        
        .demo-preview-modal .modal-footer .button {
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .demo-preview-modal .modal-footer .button-primary {
            background: #0073aa;
            color: #fff;
            border: none;
        }
        
        .demo-preview-modal .modal-footer .button-primary:hover {
            background: #005a87;
        }
        
        .demo-preview-modal .modal-footer .button:not(.button-primary) {
            background: #f0f0f0;
            color: #333;
            border: 1px solid #ddd;
        }
        
        .demo-preview-modal .modal-footer .button:not(.button-primary):hover {
            background: #e0e0e0;
        }
        
        .modal-open {
            overflow: hidden;
        }
        
        @media (max-width: 768px) {
            .demo-preview-modal .modal-content {
                width: 95%;
                margin: 20px;
            }
            
            .demo-preview-modal .modal-header,
            .demo-preview-modal .modal-body,
            .demo-preview-modal .modal-footer {
                padding: 20px;
            }
            
            .demo-preview-modal .modal-footer {
                flex-direction: column;
            }
            
            .demo-preview-modal .modal-footer .button {
                width: 100%;
                text-align: center;
            }
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            $('.import-demo').click(function(e) {
                e.preventDefault();
                var demo = $(this).data('demo');
                var options = $('#flexipro-import-form').serialize();
                
                if (confirm('Are you sure you want to import this demo? This may take a few minutes.')) {
                    importDemo(demo, options);
                }
            });
            
            $('.preview-demo').click(function(e) {
                e.preventDefault();
                var demo = $(this).data('demo');
                showDemoPreview(demo);
            });
            
            function importDemo(demo, options) {
                $('.flexipro-import-progress').show();
                updateProgress(10, 'Preparing import...');
                
                // Simulate import process with progress updates
                var progressSteps = [
                    { percent: 20, text: 'Creating pages...' },
                    { percent: 40, text: 'Importing posts...' },
                    { percent: 60, text: 'Setting up menus...' },
                    { percent: 80, text: 'Configuring theme options...' },
                    { percent: 90, text: 'Finalizing setup...' },
                    { percent: 100, text: 'Import completed successfully!' }
                ];
                
                var currentStep = 0;
                var stepInterval = setInterval(function() {
                    if (currentStep < progressSteps.length) {
                        var step = progressSteps[currentStep];
                        updateProgress(step.percent, step.text);
                        currentStep++;
                    } else {
                        clearInterval(stepInterval);
                        setTimeout(function() {
                            $('.flexipro-import-progress').hide();
                            alert('Demo content imported successfully! The page will now reload.');
                            location.reload();
                        }, 1000);
                    }
                }, 1000);
                
                // Also try AJAX import as backup
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'flexipro_import_demo',
                        demo: demo,
                        options: options,
                        nonce: '<?php echo wp_create_nonce('flexipro_demo_import'); ?>'
                    },
                    success: function(response) {
                        // AJAX success - already handled by progress simulation
                    },
                    error: function() {
                        // AJAX failed - continue with simulation
                        console.log('AJAX import failed, using simulation');
                    }
                });
            }
            
            function updateProgress(percent, text) {
                $('.progress-fill').css('width', percent + '%');
                $('.progress-text').text(text);
            }
            
            function showDemoPreview(demo) {
                var demoData = getDemoData(demo);
                var modal = $('<div class="demo-preview-modal"><div class="modal-overlay"></div><div class="modal-content"><div class="modal-header"><h3>' + demoData.name + '</h3><button class="modal-close">&times;</button></div><div class="modal-body"><div class="demo-preview-content">' + demoData.previewContent + '</div><div class="demo-info"><h4>Features:</h4><ul>' + demoData.featuresList + '</ul><p>' + demoData.description + '</p></div></div><div class="modal-footer"><button class="button button-primary import-demo" data-demo="' + demo + '">Import This Demo</button><button class="button modal-close">Close</button></div></div></div>');
                
                $('body').append(modal);
                $('body').addClass('modal-open');
                
                // Import demo from modal
                modal.find('.import-demo').click(function(e) {
                    e.preventDefault();
                    var options = $('#flexipro-import-form').serialize();
                    if (confirm('Are you sure you want to import this demo? This may take a few minutes.')) {
                        modal.remove();
                        $('body').removeClass('modal-open');
                        importDemo(demo, options);
                    }
                });
                
                // Close modal
                modal.find('.modal-close, .modal-overlay').click(function() {
                    modal.remove();
                    $('body').removeClass('modal-open');
                });
            }
            
            function getDemoData(demo) {
                var demos = {
                    'corporate': {
                        name: 'Corporate Business',
                        description: 'Professional corporate website with modern design',
                        previewContent: getCorporatePreview(),
                        features: ['Hero Section', 'Services Grid', 'Portfolio Gallery', 'Team Members', 'Testimonials', 'Contact Form']
                    },
                    'creative': {
                        name: 'Creative Agency',
                        description: 'Bold and creative design for agencies and freelancers',
                        previewContent: getCreativePreview(),
                        features: ['Animated Hero', 'Portfolio Showcase', 'Creative Services', 'Client Testimonials', 'Blog Layout', 'Contact Map']
                    },
                    'ecommerce': {
                        name: 'E-commerce Store',
                        description: 'Complete online store with WooCommerce integration',
                        previewContent: getEcommercePreview(),
                        features: ['Product Showcase', 'Shopping Cart', 'Checkout Process', 'User Accounts', 'Product Reviews', 'Payment Integration']
                    },
                    'portfolio': {
                        name: 'Portfolio Showcase',
                        description: 'Elegant portfolio for designers and photographers',
                        previewContent: getPortfolioPreview(),
                        features: ['Portfolio Grid', 'Image Lightbox', 'About Section', 'Skills Display', 'Contact Form', 'Social Links']
                    },
                    'restaurant': {
                        name: 'Restaurant & Food',
                        description: 'Appetizing design for restaurants and food businesses',
                        previewContent: getRestaurantPreview(),
                        features: ['Menu Display', 'Image Gallery', 'Reservation Form', 'Location Map', 'Reviews', 'Social Media']
                    },
                    'medical': {
                        name: 'Medical & Health',
                        description: 'Clean and professional design for medical practices',
                        previewContent: getMedicalPreview(),
                        features: ['Service Listings', 'Doctor Profiles', 'Appointment Booking', 'Health Tips', 'Contact Info', 'Emergency Info']
                    },
                    'education': {
                        name: 'Education & Learning',
                        description: 'Modern design for schools and educational institutions',
                        previewContent: getEducationPreview(),
                        features: ['Course Listings', 'Teacher Profiles', 'News & Events', 'Student Resources', 'Admission Info', 'Contact Form']
                    },
                    'real-estate': {
                        name: 'Real Estate',
                        description: 'Property showcase and real estate business',
                        previewContent: getRealEstatePreview(),
                        features: ['Property Listings', 'Agent Profiles', 'Property Search', 'Virtual Tours', 'Mortgage Calculator', 'Contact Forms']
                    }
                };
                
                var demo = demos[demo] || demos['corporate'];
                demo.featuresList = '';
                for (var i = 0; i < demo.features.length; i++) {
                    demo.featuresList += '<li>' + demo.features[i] + '</li>';
                }
                return demo;
            }
            
    function getCorporatePreview() {
        return '<div class="demo-preview-layout"><div class="demo-hero" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 60px 20px; text-align: center; color: white;"><h1 style="font-size: 48px; margin: 0 0 20px 0; font-weight: 700;">Welcome to Our Company</h1><p style="font-size: 20px; margin: 0 0 30px 0; opacity: 0.9;">Professional solutions for your business needs</p><div style="display: flex; gap: 15px; justify-content: center;"><button style="background: white; color: #667eea; padding: 12px 30px; border: none; border-radius: 5px; font-weight: 600; cursor: pointer;">Learn More</button><button style="background: transparent; color: white; padding: 12px 30px; border: 2px solid white; border-radius: 5px; font-weight: 600; cursor: pointer;">Contact Us</button></div></div><div class="demo-services" style="padding: 80px 20px; background: #f8f9fa;"><div style="max-width: 1200px; margin: 0 auto;"><h2 style="text-align: center; font-size: 36px; margin: 0 0 50px 0; color: #333;">Our Services</h2><div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;"><div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align: center;"><div style="width: 80px; height: 80px; background: #667eea; border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; color: white; font-size: 24px;">📊</div><h3 style="font-size: 24px; margin: 0 0 15px 0; color: #333;">Business Strategy</h3><p style="color: #666; line-height: 1.6;">Strategic planning and consultation to help your business grow and succeed in today\'s competitive market.</p></div><div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align: center;"><div style="width: 80px; height: 80px; background: #667eea; border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; color: white; font-size: 24px;">💼</div><h3 style="font-size: 24px; margin: 0 0 15px 0; color: #333;">Consulting</h3><p style="color: #666; line-height: 1.6;">Expert consulting services to optimize your operations and improve efficiency across all departments.</p></div><div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align: center;"><div style="width: 80px; height: 80px; background: #667eea; border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; color: white; font-size: 24px;">🚀</div><h3 style="font-size: 24px; margin: 0 0 15px 0; color: #333;">Growth Solutions</h3><p style="color: #666; line-height: 1.6;">Comprehensive growth strategies tailored to your specific industry and business objectives.</p></div></div></div></div><div style="text-align: center; margin-top: 20px;"><button class="button button-primary edit-demo-content" data-demo="corporate" style="background: #3498db; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-weight: 600;"><i class="dashicons dashicons-edit" style="margin-right: 5px;"></i>Edit with Visual Builder</button></div></div>';
    }
            
            function getCreativePreview() {
                return '<div class="demo-preview-layout"><div class="demo-hero" style="background: linear-gradient(45deg, #ff6b6b, #feca57); padding: 80px 20px; text-align: center; color: white;"><h1 style="font-size: 56px; margin: 0 0 20px 0; font-weight: 900; text-transform: uppercase; letter-spacing: 2px;">Creative Agency</h1><p style="font-size: 24px; margin: 0 0 40px 0; opacity: 0.9;">Bold. Creative. Innovative.</p><div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;"><button style="background: white; color: #ff6b6b; padding: 15px 40px; border: none; border-radius: 50px; font-weight: 700; font-size: 16px; cursor: pointer; text-transform: uppercase;">View Our Work</button><button style="background: transparent; color: white; padding: 15px 40px; border: 3px solid white; border-radius: 50px; font-weight: 700; font-size: 16px; cursor: pointer; text-transform: uppercase;">Get Started</button></div></div><div class="demo-portfolio" style="padding: 80px 20px; background: #2c3e50;"><div style="max-width: 1200px; margin: 0 auto;"><h2 style="text-align: center; font-size: 42px; margin: 0 0 60px 0; color: white; font-weight: 300;">Featured Work</h2><div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 30px;"><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.3);"><div style="height: 250px; background: linear-gradient(45deg, #ff9a9e, #fecfef); display: flex; align-items: center; justify-content: center; font-size: 48px;">🎨</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Brand Identity</h3><p style="color: #666; margin: 0;">Complete brand redesign for tech startup</p></div></div><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.3);"><div style="height: 250px; background: linear-gradient(45deg, #a8edea, #fed6e3); display: flex; align-items: center; justify-content: center; font-size: 48px;">📱</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Mobile App</h3><p style="color: #666; margin: 0;">UI/UX design for fitness app</p></div></div><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.3);"><div style="height: 250px; background: linear-gradient(45deg, #ffecd2, #fcb69f); display: flex; align-items: center; justify-content: center; font-size: 48px;">🌐</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Web Design</h3><p style="color: #666; margin: 0;">E-commerce platform redesign</p></div></div></div></div></div><div style="text-align: center; margin-top: 20px;"><button class="button button-primary edit-demo-content" data-demo="creative" style="background: #e74c3c; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-weight: 600;"><i class="dashicons dashicons-edit" style="margin-right: 5px;"></i>Edit with Visual Builder</button></div></div>';
            }
            
            function getEcommercePreview() {
                return '<div class="demo-preview-layout"><div class="demo-hero" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 60px 20px; text-align: center; color: white;"><h1 style="font-size: 48px; margin: 0 0 20px 0; font-weight: 700;">Shop Online</h1><p style="font-size: 20px; margin: 0 0 30px 0; opacity: 0.9;">Discover amazing products at great prices</p><div style="display: flex; gap: 15px; justify-content: center;"><button style="background: white; color: #667eea; padding: 12px 30px; border: none; border-radius: 5px; font-weight: 600; cursor: pointer;">Shop Now</button><button style="background: transparent; color: white; padding: 12px 30px; border: 2px solid white; border-radius: 5px; font-weight: 600; cursor: pointer;">View Cart</button></div></div><div class="demo-products" style="padding: 80px 20px; background: #f8f9fa;"><div style="max-width: 1200px; margin: 0 auto;"><h2 style="text-align: center; font-size: 36px; margin: 0 0 50px 0; color: #333;">Featured Products</h2><div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 30px;"><div style="background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1);"><div style="height: 200px; background: linear-gradient(45deg, #ff9a9e, #fecfef); display: flex; align-items: center; justify-content: center; font-size: 48px;">📱</div><div style="padding: 20px;"><h3 style="font-size: 20px; margin: 0 0 10px 0; color: #333;">Smartphone Pro</h3><p style="color: #666; margin: 0 0 15px 0;">Latest technology in your hands</p><div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 24px; font-weight: 700; color: #667eea;">$599</span><button style="background: #667eea; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer;">Add to Cart</button></div></div></div><div style="background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1);"><div style="height: 200px; background: linear-gradient(45deg, #a8edea, #fed6e3); display: flex; align-items: center; justify-content: center; font-size: 48px;">💻</div><div style="padding: 20px;"><h3 style="font-size: 20px; margin: 0 0 10px 0; color: #333;">Laptop Ultra</h3><p style="color: #666; margin: 0 0 15px 0;">Powerful performance for work</p><div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 24px; font-weight: 700; color: #667eea;">$1299</span><button style="background: #667eea; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer;">Add to Cart</button></div></div></div><div style="background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1);"><div style="height: 200px; background: linear-gradient(45deg, #ffecd2, #fcb69f); display: flex; align-items: center; justify-content: center; font-size: 48px;">🎧</div><div style="padding: 20px;"><h3 style="font-size: 20px; margin: 0 0 10px 0; color: #333;">Wireless Headphones</h3><p style="color: #666; margin: 0 0 15px 0;">Premium sound quality</p><div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 24px; font-weight: 700; color: #667eea;">$199</span><button style="background: #667eea; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer;">Add to Cart</button></div></div></div></div></div></div><div style="text-align: center; margin-top: 20px;"><button class="button button-primary edit-demo-content" data-demo="ecommerce" style="background: #27ae60; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-weight: 600;"><i class="dashicons dashicons-edit" style="margin-right: 5px;"></i>Edit with Visual Builder</button></div></div>';
            }
            
            function getPortfolioPreview() {
                return '<div class="demo-preview-layout"><div class="demo-hero" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 80px 20px; text-align: center; color: white;"><h1 style="font-size: 56px; margin: 0 0 20px 0; font-weight: 300;">John Doe</h1><p style="font-size: 24px; margin: 0 0 40px 0; opacity: 0.9;">Creative Designer & Developer</p><div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;"><button style="background: white; color: #667eea; padding: 15px 40px; border: none; border-radius: 50px; font-weight: 600; cursor: pointer;">View My Work</button><button style="background: transparent; color: white; padding: 15px 40px; border: 2px solid white; border-radius: 50px; font-weight: 600; cursor: pointer;">Contact Me</button></div></div><div class="demo-portfolio-grid" style="padding: 80px 20px; background: #f8f9fa;"><div style="max-width: 1200px; margin: 0 auto;"><h2 style="text-align: center; font-size: 36px; margin: 0 0 60px 0; color: #333;">My Portfolio</h2><div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;"><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"><div style="height: 250px; background: linear-gradient(45deg, #ff9a9e, #fecfef); display: flex; align-items: center; justify-content: center; font-size: 48px;">🎨</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Brand Identity Design</h3><p style="color: #666; margin: 0 0 15px 0;">Complete brand identity for tech startup</p><div style="display: flex; gap: 10px;"><span style="background: #667eea; color: white; padding: 5px 12px; border-radius: 20px; font-size: 12px;">Design</span><span style="background: #667eea; color: white; padding: 5px 12px; border-radius: 20px; font-size: 12px;">Branding</span></div></div></div><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"><div style="height: 250px; background: linear-gradient(45deg, #a8edea, #fed6e3); display: flex; align-items: center; justify-content: center; font-size: 48px;">📱</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Mobile App UI</h3><p style="color: #666; margin: 0 0 15px 0;">Fitness app interface design</p><div style="display: flex; gap: 10px;"><span style="background: #667eea; color: white; padding: 5px 12px; border-radius: 20px; font-size: 12px;">UI/UX</span><span style="background: #667eea; color: white; padding: 5px 12px; border-radius: 20px; font-size: 12px;">Mobile</span></div></div></div><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"><div style="height: 250px; background: linear-gradient(45deg, #ffecd2, #fcb69f); display: flex; align-items: center; justify-content: center; font-size: 48px;">🌐</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">E-commerce Website</h3><p style="color: #666; margin: 0 0 15px 0;">Online store design and development</p><div style="display: flex; gap: 10px;"><span style="background: #667eea; color: white; padding: 5px 12px; border-radius: 20px; font-size: 12px;">Web</span><span style="background: #667eea; color: white; padding: 5px 12px; border-radius: 20px; font-size: 12px;">E-commerce</span></div></div></div></div></div></div><div style="text-align: center; margin-top: 20px;"><button class="button button-primary edit-demo-content" data-demo="portfolio" style="background: #9b59b6; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-weight: 600;"><i class="dashicons dashicons-edit" style="margin-right: 5px;"></i>Edit with Visual Builder</button></div></div>';
            }
            
            function getRestaurantPreview() {
                return '<div class="demo-preview-layout"><div class="demo-hero" style="background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(\'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 600"><rect fill="%23ff6b6b" width="1200" height="600"/><circle fill="%23feca57" cx="200" cy="150" r="100"/><circle fill="%23ff9ff3" cx="800" cy="300" r="80"/><circle fill="%23feca57" cx="1000" cy="100" r="60"/></svg>\'); background-size: cover; padding: 100px 20px; text-align: center; color: white;"><h1 style="font-size: 56px; margin: 0 0 20px 0; font-weight: 700; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);">Bella Vista Restaurant</h1><p style="font-size: 24px; margin: 0 0 40px 0; opacity: 0.9;">Authentic Italian cuisine in the heart of the city</p><div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;"><button style="background: #ff6b6b; color: white; padding: 15px 40px; border: none; border-radius: 50px; font-weight: 600; cursor: pointer;">View Menu</button><button style="background: transparent; color: white; padding: 15px 40px; border: 2px solid white; border-radius: 50px; font-weight: 600; cursor: pointer;">Make Reservation</button></div></div><div class="demo-menu" style="padding: 80px 20px; background: #f8f9fa;"><div style="max-width: 1200px; margin: 0 auto;"><h2 style="text-align: center; font-size: 36px; margin: 0 0 60px 0; color: #333;">Our Specialties</h2><div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 30px;"><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"><div style="height: 200px; background: linear-gradient(45deg, #ff9a9e, #fecfef); display: flex; align-items: center; justify-content: center; font-size: 48px;">🍝</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Pasta Carbonara</h3><p style="color: #666; margin: 0 0 15px 0;">Classic Italian pasta with creamy sauce</p><div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 20px; font-weight: 700; color: #ff6b6b;">$18</span><button style="background: #ff6b6b; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer;">Order Now</button></div></div></div><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"><div style="height: 200px; background: linear-gradient(45deg, #a8edea, #fed6e3); display: flex; align-items: center; justify-content: center; font-size: 48px;">🍕</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Margherita Pizza</h3><p style="color: #666; margin: 0 0 15px 0;">Fresh mozzarella and basil on thin crust</p><div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 20px; font-weight: 700; color: #ff6b6b;">$16</span><button style="background: #ff6b6b; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer;">Order Now</button></div></div></div><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"><div style="height: 200px; background: linear-gradient(45deg, #ffecd2, #fcb69f); display: flex; align-items: center; justify-content: center; font-size: 48px;">🍷</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Wine Selection</h3><p style="color: #666; margin: 0 0 15px 0;">Carefully curated Italian wines</p><div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 20px; font-weight: 700; color: #ff6b6b;">$12</span><button style="background: #ff6b6b; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer;">Order Now</button></div></div></div></div></div></div><div style="text-align: center; margin-top: 20px;"><button class="button button-primary edit-demo-content" data-demo="restaurant" style="background: #ff6b6b; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-weight: 600;"><i class="dashicons dashicons-edit" style="margin-right: 5px;"></i>Edit with Visual Builder</button></div></div>';
            }
            
            function getMedicalPreview() {
                return '<div class="demo-preview-layout"><div class="demo-hero" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 80px 20px; text-align: center; color: white;"><h1 style="font-size: 48px; margin: 0 0 20px 0; font-weight: 300;">MedCare Clinic</h1><p style="font-size: 24px; margin: 0 0 40px 0; opacity: 0.9;">Your health is our priority</p><div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;"><button style="background: white; color: #667eea; padding: 15px 40px; border: none; border-radius: 5px; font-weight: 600; cursor: pointer;">Book Appointment</button><button style="background: transparent; color: white; padding: 15px 40px; border: 2px solid white; border-radius: 5px; font-weight: 600; cursor: pointer;">Emergency</button></div></div><div class="demo-services" style="padding: 80px 20px; background: #f8f9fa;"><div style="max-width: 1200px; margin: 0 auto;"><h2 style="text-align: center; font-size: 36px; margin: 0 0 50px 0; color: #333;">Our Services</h2><div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;"><div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align: center;"><div style="width: 80px; height: 80px; background: #667eea; border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; color: white; font-size: 24px;">🩺</div><h3 style="font-size: 24px; margin: 0 0 15px 0; color: #333;">General Medicine</h3><p style="color: #666; line-height: 1.6;">Comprehensive primary care services for all ages</p></div><div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align: center;"><div style="width: 80px; height: 80px; background: #667eea; border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; color: white; font-size: 24px;">💊</div><h3 style="font-size: 24px; margin: 0 0 15px 0; color: #333;">Specialist Care</h3><p style="color: #666; line-height: 1.6;">Expert specialists in various medical fields</p></div><div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align: center;"><div style="width: 80px; height: 80px; background: #667eea; border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; color: white; font-size: 24px;">🏥</div><h3 style="font-size: 24px; margin: 0 0 15px 0; color: #333;">Emergency Care</h3><p style="color: #666; line-height: 1.6;">24/7 emergency medical services</p></div></div></div></div><div style="text-align: center; margin-top: 20px;"><button class="button button-primary edit-demo-content" data-demo="medical" style="background: #16a085; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-weight: 600;"><i class="dashicons dashicons-edit" style="margin-right: 5px;"></i>Edit with Visual Builder</button></div></div>';
            }
            
            function getEducationPreview() {
                return '<div class="demo-preview-layout"><div class="demo-hero" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 80px 20px; text-align: center; color: white;"><h1 style="font-size: 48px; margin: 0 0 20px 0; font-weight: 300;">EduLearn Academy</h1><p style="font-size: 24px; margin: 0 0 40px 0; opacity: 0.9;">Empowering minds, shaping futures</p><div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;"><button style="background: white; color: #667eea; padding: 15px 40px; border: none; border-radius: 5px; font-weight: 600; cursor: pointer;">View Courses</button><button style="background: transparent; color: white; padding: 15px 40px; border: 2px solid white; border-radius: 5px; font-weight: 600; cursor: pointer;">Apply Now</button></div></div><div class="demo-courses" style="padding: 80px 20px; background: #f8f9fa;"><div style="max-width: 1200px; margin: 0 auto;"><h2 style="text-align: center; font-size: 36px; margin: 0 0 50px 0; color: #333;">Featured Courses</h2><div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 30px;"><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"><div style="height: 200px; background: linear-gradient(45deg, #ff9a9e, #fecfef); display: flex; align-items: center; justify-content: center; font-size: 48px;">💻</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Web Development</h3><p style="color: #666; margin: 0 0 15px 0;">Learn modern web development technologies</p><div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 20px; font-weight: 700; color: #667eea;">$299</span><button style="background: #667eea; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer;">Enroll Now</button></div></div></div><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"><div style="height: 200px; background: linear-gradient(45deg, #a8edea, #fed6e3); display: flex; align-items: center; justify-content: center; font-size: 48px;">🎨</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Graphic Design</h3><p style="color: #666; margin: 0 0 15px 0;">Master the art of visual communication</p><div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 20px; font-weight: 700; color: #667eea;">$199</span><button style="background: #667eea; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer;">Enroll Now</button></div></div></div><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"><div style="height: 200px; background: linear-gradient(45deg, #ffecd2, #fcb69f); display: flex; align-items: center; justify-content: center; font-size: 48px;">📊</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Data Science</h3><p style="color: #666; margin: 0 0 15px 0;">Analyze data and make informed decisions</p><div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 20px; font-weight: 700; color: #667eea;">$399</span><button style="background: #667eea; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer;">Enroll Now</button></div></div></div></div></div></div><div style="text-align: center; margin-top: 20px;"><button class="button button-primary edit-demo-content" data-demo="education" style="background: #f39c12; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-weight: 600;"><i class="dashicons dashicons-edit" style="margin-right: 5px;"></i>Edit with Visual Builder</button></div></div>';
            }
            
            function getRealEstatePreview() {
                return '<div class="demo-preview-layout"><div class="demo-hero" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 80px 20px; text-align: center; color: white;"><h1 style="font-size: 48px; margin: 0 0 20px 0; font-weight: 300;">Prime Properties</h1><p style="font-size: 24px; margin: 0 0 40px 0; opacity: 0.9;">Find your dream home today</p><div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;"><button style="background: white; color: #667eea; padding: 15px 40px; border: none; border-radius: 5px; font-weight: 600; cursor: pointer;">Search Properties</button><button style="background: transparent; color: white; padding: 15px 40px; border: 2px solid white; border-radius: 5px; font-weight: 600; cursor: pointer;">Contact Agent</button></div></div><div class="demo-properties" style="padding: 80px 20px; background: #f8f9fa;"><div style="max-width: 1200px; margin: 0 auto;"><h2 style="text-align: center; font-size: 36px; margin: 0 0 50px 0; color: #333;">Featured Properties</h2><div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 30px;"><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"><div style="height: 200px; background: linear-gradient(45deg, #ff9a9e, #fecfef); display: flex; align-items: center; justify-content: center; font-size: 48px;">🏠</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Modern Villa</h3><p style="color: #666; margin: 0 0 15px 0;">4 bedrooms, 3 bathrooms, 2500 sq ft</p><div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 24px; font-weight: 700; color: #667eea;">$750,000</span><button style="background: #667eea; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer;">View Details</button></div></div></div><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"><div style="height: 200px; background: linear-gradient(45deg, #a8edea, #fed6e3); display: flex; align-items: center; justify-content: center; font-size: 48px;">🏢</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Downtown Condo</h3><p style="color: #666; margin: 0 0 15px 0;">2 bedrooms, 2 bathrooms, 1200 sq ft</p><div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 24px; font-weight: 700; color: #667eea;">$450,000</span><button style="background: #667eea; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer;">View Details</button></div></div></div><div style="background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"><div style="height: 200px; background: linear-gradient(45deg, #ffecd2, #fcb69f); display: flex; align-items: center; justify-content: center; font-size: 48px;">🏡</div><div style="padding: 25px;"><h3 style="font-size: 24px; margin: 0 0 10px 0; color: #333;">Family Home</h3><p style="color: #666; margin: 0 0 15px 0;">3 bedrooms, 2 bathrooms, 1800 sq ft</p><div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 24px; font-weight: 700; color: #667eea;">$550,000</span><button style="background: #667eea; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer;">View Details</button></div></div></div></div></div></div><div style="text-align: center; margin-top: 20px;"><button class="button button-primary edit-demo-content" data-demo="realestate" style="background: #8e44ad; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-weight: 600;"><i class="dashicons dashicons-edit" style="margin-right: 5px;"></i>Edit with Visual Builder</button></div></div>';
            }
        });
        
        // Handle edit demo content buttons
        $(document).on('click', '.edit-demo-content', function(e) {
            e.preventDefault();
            var demoType = $(this).data('demo');
            console.log('Edit demo content clicked:', demoType);
            
            // Close any existing modals
            $('.demo-preview-modal').remove();
            $('body').removeClass('modal-open');
            
            // Open visual builder with demo content
            openVisualBuilderWithDemo(demoType);
        });
        
        function openVisualBuilderWithDemo(demoType) {
            console.log('Opening visual builder with demo:', demoType);
            
            // Check if visual builder is available
            if (typeof window.flexiproBuilder === 'undefined') {
                alert('Visual Builder is not available. Please make sure the theme is properly activated.');
                return;
            }
            
            // Create a new page/post for the demo content
            var demoData = getDemoData(demoType);
            var pageTitle = demoData.name + ' - Demo Page';
            
            // Create page via AJAX
            $.ajax({
                url: flexiproBuilder.ajaxurl,
                type: 'POST',
                data: {
                    action: 'flexipro_create_demo_page',
                    demo_type: demoType,
                    page_title: pageTitle,
                    nonce: flexiproBuilder.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Open visual builder with the new page
                        var editUrl = response.data.edit_url;
                        window.open(editUrl, '_blank');
                        
                        // Show success message
                        alert('Demo page created successfully! Opening Visual Builder...');
                    } else {
                        alert('Error creating demo page: ' + response.data);
                    }
                },
                error: function() {
                    alert('Error creating demo page. Please try again.');
                }
            });
        }
        </script>
        <?php
    }
    
    public function ajax_import_demo() {
        try {
            // Verify nonce
            if (!wp_verify_nonce($_POST['nonce'], 'flexipro_demo_import')) {
                wp_send_json_error('Security check failed.');
            }
            
            if (!current_user_can('manage_options')) {
                wp_send_json_error('You do not have permission to import demo content.');
            }
            
            $demo = sanitize_text_field($_POST['demo']);
            $options = isset($_POST['options']) ? $_POST['options'] : '';
            
            if (!isset($this->demos[$demo])) {
                wp_send_json_error('Invalid demo selected');
            }
            
            $demo_data = $this->demos[$demo];
            
            // Parse options
            $import_options = array();
            if (!empty($options)) {
                parse_str($options, $import_options);
            }
            
            // Set default options
            $import_options = wp_parse_args($import_options, array(
                'import_pages' => 1,
                'import_posts' => 1,
                'import_media' => 1,
                'import_menus' => 1,
                'import_widgets' => 1,
                'import_options' => 1,
                'reset_content' => 0
            ));
            
            // Reset content if requested
            if (isset($import_options['reset_content']) && $import_options['reset_content']) {
                $this->reset_content();
            }
            
            // Import demo content
            $this->import_demo_content($demo, $import_options);
            
            wp_send_json_success('Demo imported successfully');
            
        } catch (Exception $e) {
            wp_send_json_error('Import failed: ' . $e->getMessage());
        }
    }
    
    public function ajax_reset_demo() {
        check_ajax_referer('flexipro_demo_import', 'nonce');
        
        $this->reset_content();
        
        wp_send_json_success('Content reset successfully');
    }
    
    private function reset_content() {
        // Delete all posts
        $posts = get_posts(array('numberposts' => -1, 'post_type' => 'any', 'post_status' => 'any'));
        foreach ($posts as $post) {
            wp_delete_post($post->ID, true);
        }
        
        // Delete all pages
        $pages = get_pages();
        foreach ($pages as $page) {
            wp_delete_post($page->ID, true);
        }
        
        // Delete all media
        $attachments = get_posts(array('numberposts' => -1, 'post_type' => 'attachment', 'post_status' => 'any'));
        foreach ($attachments as $attachment) {
            wp_delete_attachment($attachment->ID, true);
        }
        
        // Reset widgets
        $sidebars = wp_get_sidebars_widgets();
        foreach ($sidebars as $sidebar => $widgets) {
            $sidebars[$sidebar] = array();
        }
        wp_set_sidebars_widgets($sidebars);
        
        // Reset menus
        $menus = wp_get_nav_menus();
        foreach ($menus as $menu) {
            wp_delete_nav_menu($menu->term_id);
        }
    }
    
    private function import_demo_content($demo, $options) {
        $demo_path = FLEXIPRO_THEME_DIR . '/demo-content/' . $demo . '/';
        
        // Import pages
        if (isset($options['import_pages'])) {
            $this->import_pages($demo_path . 'pages.json');
        }
        
        // Import posts
        if (isset($options['import_posts'])) {
            $this->import_posts($demo_path . 'posts.json');
        }
        
        // Import media
        if (isset($options['import_media'])) {
            $this->import_media($demo_path . 'media/');
        }
        
        // Import widgets
        if (isset($options['import_widgets'])) {
            $this->import_widgets($demo_path . 'widgets.json');
        }
        
        // Import menus
        if (isset($options['import_menus'])) {
            $this->import_menus($demo_path . 'menus.json');
        }
        
        // Import theme options
        if (isset($options['import_theme_options'])) {
            $this->import_theme_options($demo_path . 'theme-options.json');
        }
    }
    
    private function import_pages($file_path) {
        if (!file_exists($file_path)) {
            return;
        }
        
        $pages_data = json_decode(file_get_contents($file_path), true);
        
        foreach ($pages_data as $page_data) {
            $page_id = wp_insert_post(array(
                'post_title' => $page_data['title'],
                'post_content' => $page_data['content'],
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_name' => $page_data['slug']
            ));
            
            if ($page_id && isset($page_data['meta'])) {
                foreach ($page_data['meta'] as $key => $value) {
                    update_post_meta($page_id, $key, $value);
                }
            }
        }
    }
    
    private function import_posts($file_path) {
        if (!file_exists($file_path)) {
            return;
        }
        
        $posts_data = json_decode(file_get_contents($file_path), true);
        
        foreach ($posts_data as $post_data) {
            $post_id = wp_insert_post(array(
                'post_title' => $post_data['title'],
                'post_content' => $post_data['content'],
                'post_excerpt' => $post_data['excerpt'],
                'post_status' => 'publish',
                'post_type' => 'post',
                'post_name' => $post_data['slug']
            ));
            
            if ($post_id && isset($post_data['meta'])) {
                foreach ($post_data['meta'] as $key => $value) {
                    update_post_meta($post_id, $key, $value);
                }
            }
        }
    }
    
    private function import_media($dir_path) {
        if (!is_dir($dir_path)) {
            return;
        }
        
        $files = glob($dir_path . '*');
        
        foreach ($files as $file) {
            if (is_file($file)) {
                $filename = basename($file);
                $upload_file = wp_upload_bits($filename, null, file_get_contents($file));
                
                if (!$upload_file['error']) {
                    $wp_filetype = wp_check_filetype($filename, null);
                    $attachment = array(
                        'post_mime_type' => $wp_filetype['type'],
                        'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
                        'post_content' => '',
                        'post_status' => 'inherit'
                    );
                    
                    $attachment_id = wp_insert_attachment($attachment, $upload_file['file']);
                    require_once(ABSPATH . 'wp-admin/includes/image.php');
                    $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload_file['file']);
                    wp_update_attachment_metadata($attachment_id, $attachment_data);
                }
            }
        }
    }
    
    private function import_widgets($file_path) {
        if (!file_exists($file_path)) {
            return;
        }
        
        $widgets_data = json_decode(file_get_contents($file_path), true);
        wp_set_sidebars_widgets($widgets_data);
    }
    
    private function import_menus($file_path) {
        if (!file_exists($file_path)) {
            return;
        }
        
        $menus_data = json_decode(file_get_contents($file_path), true);
        
        foreach ($menus_data as $menu_data) {
            $menu_id = wp_create_nav_menu($menu_data['name']);
            
            if ($menu_id && isset($menu_data['items'])) {
                foreach ($menu_data['items'] as $item_data) {
                    wp_update_nav_menu_item($menu_id, 0, array(
                        'menu-item-title' => $item_data['title'],
                        'menu-item-url' => $item_data['url'],
                        'menu-item-status' => 'publish'
                    ));
                }
            }
        }
    }
    
    private function import_theme_options($file_path) {
        if (!file_exists($file_path)) {
            return;
        }
        
        $options_data = json_decode(file_get_contents($file_path), true);
        update_option('flexipro_options', $options_data);
    }
    
    public function ajax_create_demo_page() {
        try {
            // Verify nonce
            if (!wp_verify_nonce($_POST['nonce'], 'flexipro_builder_nonce')) {
                wp_send_json_error('Invalid nonce');
            }

            // Check user permissions
            if (!current_user_can('edit_posts')) {
                wp_send_json_error('Insufficient permissions');
            }

            $demo_type = sanitize_text_field($_POST['demo_type']);
            $page_title = sanitize_text_field($_POST['page_title']);

            // Create new page
            $page_id = wp_insert_post(array(
                'post_title' => $page_title,
                'post_content' => $this->get_demo_content($demo_type),
                'post_status' => 'draft',
                'post_type' => 'page',
                'post_author' => get_current_user_id()
            ));

            if (is_wp_error($page_id)) {
                wp_send_json_error('Failed to create page');
            }

            // Add demo content as visual builder data
            $builder_data = $this->get_demo_builder_data($demo_type);
            update_post_meta($page_id, '_flexipro_visual_builder_data', $builder_data);

            // Get edit URL
            $edit_url = admin_url('post.php?post=' . $page_id . '&action=edit');

            wp_send_json_success(array(
                'page_id' => $page_id,
                'edit_url' => $edit_url
            ));
        } catch (Exception $e) {
            wp_send_json_error('Failed to create demo page: ' . $e->getMessage());
        }
    }
    
    private function get_demo_content($demo_type) {
        $content = '';
        
        switch ($demo_type) {
            case 'corporate':
                $content = '
                <div class="hero-section modern-hero">
                    <div class="hero-background">
                        <div class="hero-overlay"></div>
                    </div>
                    <div class="hero-content">
                        <div class="hero-badge">🚀 Modern Solutions</div>
                        <h1 class="hero-title">Transform Your Business with <span class="gradient-text">Digital Innovation</span></h1>
                        <p class="hero-description">We deliver cutting-edge technology solutions that drive growth, enhance efficiency, and create exceptional digital experiences for modern enterprises.</p>
                        <div class="hero-actions">
                            <a href="#" class="btn btn-primary btn-modern">
                                <span>Start Your Journey</span>
                                <i class="fas fa-arrow-right"></i>
                            </a>
                            <a href="#" class="btn btn-outline btn-modern">
                                <span>Watch Demo</span>
                                <i class="fas fa-play"></i>
                            </a>
                        </div>
                        <div class="hero-stats">
                            <div class="stat-item">
                                <div class="stat-number">500+</div>
                                <div class="stat-label">Happy Clients</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number">99%</div>
                                <div class="stat-label">Success Rate</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number">24/7</div>
                                <div class="stat-label">Support</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <section class="features-section modern-section">
                    <div class="container">
                        <div class="section-header">
                            <div class="section-badge">✨ Features</div>
                            <h2 class="section-title">Why Choose Our Platform</h2>
                            <p class="section-description">Discover the powerful features that make us the preferred choice for businesses worldwide</p>
                        </div>
                        <div class="features-grid modern-grid">
                            <div class="feature-card modern-card">
                                <div class="feature-icon">
                                    <i class="fas fa-rocket"></i>
                                </div>
                                <h3 class="feature-title">Lightning Fast</h3>
                                <p class="feature-description">Optimized performance with cutting-edge technology for blazing fast user experiences</p>
                                <a href="#" class="feature-link">Learn More <i class="fas fa-arrow-right"></i></a>
                            </div>
                            <div class="feature-card modern-card">
                                <div class="feature-icon">
                                    <i class="fas fa-shield-alt"></i>
                                </div>
                                <h3 class="feature-title">Enterprise Security</h3>
                                <p class="feature-description">Bank-level security with advanced encryption and compliance standards</p>
                                <a href="#" class="feature-link">Learn More <i class="fas fa-arrow-right"></i></a>
                            </div>
                            <div class="feature-card modern-card">
                                <div class="feature-icon">
                                    <i class="fas fa-mobile-alt"></i>
                                </div>
                                <h3 class="feature-title">Mobile First</h3>
                                <p class="feature-description">Responsive design that works perfectly on all devices and screen sizes</p>
                                <a href="#" class="feature-link">Learn More <i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </section>';
                break;
                
            case 'creative':
                $content = '
                <div class="hero-section creative-hero">
                    <div class="hero-content">
                        <div class="hero-badge">🎨 Creative Agency</div>
                        <h1 class="hero-title">Where <span class="gradient-text">Creativity Meets Strategy</span></h1>
                        <p class="hero-description">We craft exceptional digital experiences that tell your story, engage your audience, and drive meaningful results through innovative design and strategic thinking.</p>
                        <div class="hero-actions">
                            <a href="#" class="btn btn-primary btn-modern">View Our Work</a>
                            <a href="#" class="btn btn-outline btn-modern">Start Project</a>
                        </div>
                    </div>
                </div>
                
                <section class="services-section modern-section">
                    <div class="container">
                        <div class="section-header">
                            <h2 class="section-title">Our Creative Services</h2>
                            <p class="section-description">From concept to completion, we bring your vision to life</p>
                        </div>
                        <div class="services-grid modern-grid">
                            <div class="service-card modern-card">
                                <div class="service-icon">
                                    <i class="fas fa-paint-brush"></i>
                                </div>
                                <h3 class="service-title">Brand Identity</h3>
                                <p class="service-description">Complete brand identity design that resonates with your target audience</p>
                            </div>
                            <div class="service-card modern-card">
                                <div class="service-icon">
                                    <i class="fas fa-code"></i>
                                </div>
                                <h3 class="service-title">Web Development</h3>
                                <p class="service-description">Custom websites and web applications built with modern technologies</p>
                            </div>
                            <div class="service-card modern-card">
                                <div class="service-icon">
                                    <i class="fas fa-mobile-alt"></i>
                                </div>
                                <h3 class="service-title">Mobile Apps</h3>
                                <p class="service-description">Native and cross-platform mobile applications for iOS and Android</p>
                            </div>
                        </div>
                    </div>
                </section>';
                break;
                
            case 'ecommerce':
                $content = '
                <div class="hero-section ecommerce-hero">
                    <div class="hero-content">
                        <div class="hero-badge">🛍️ Online Store</div>
                        <h1 class="hero-title">Discover Amazing <span class="gradient-text">Products</span></h1>
                        <p class="hero-description">Shop the latest trends and discover unique products from our curated collection. Fast shipping, secure payments, and exceptional customer service.</p>
                        <div class="hero-actions">
                            <a href="#" class="btn btn-primary btn-modern">Shop Now</a>
                            <a href="#" class="btn btn-outline btn-modern">View Categories</a>
                        </div>
                    </div>
                </div>
                
                <section class="products-section modern-section">
                    <div class="container">
                        <div class="section-header">
                            <h2 class="section-title">Featured Products</h2>
                            <p class="section-description">Handpicked items just for you</p>
                        </div>
                        <div class="products-grid modern-grid">
                            <div class="product-card modern-card">
                                <div class="product-image">
                                    <div class="product-badge">New</div>
                                    <div class="product-actions">
                                        <button class="btn-icon"><i class="fas fa-heart"></i></button>
                                        <button class="btn-icon"><i class="fas fa-eye"></i></button>
                                    </div>
                                </div>
                                <div class="product-content">
                                    <h3 class="product-title">Premium Headphones</h3>
                                    <div class="product-price">
                                        <span class="current-price">$299</span>
                                        <span class="original-price">$399</span>
                                    </div>
                                    <div class="product-rating">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <span class="rating-count">(128)</span>
                                    </div>
                                </div>
                            </div>
                            <div class="product-card modern-card">
                                <div class="product-image">
                                    <div class="product-badge sale">Sale</div>
                                    <div class="product-actions">
                                        <button class="btn-icon"><i class="fas fa-heart"></i></button>
                                        <button class="btn-icon"><i class="fas fa-eye"></i></button>
                                    </div>
                                </div>
                                <div class="product-content">
                                    <h3 class="product-title">Smart Watch</h3>
                                    <div class="product-price">
                                        <span class="current-price">$199</span>
                                        <span class="original-price">$299</span>
                                    </div>
                                    <div class="product-rating">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <span class="rating-count">(89)</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>';
                break;
                
            case 'portfolio':
                $content = '
                <div class="hero-section portfolio-hero">
                    <div class="hero-content">
                        <div class="hero-badge">🎨 Creative Portfolio</div>
                        <h1 class="hero-title">Where <span class="gradient-text">Art Meets Technology</span></h1>
                        <p class="hero-description">Explore our collection of innovative designs, creative solutions, and digital masterpieces that push the boundaries of visual storytelling.</p>
                        <div class="hero-actions">
                            <a href="#" class="btn btn-primary btn-modern">View Portfolio</a>
                            <a href="#" class="btn btn-outline btn-modern">Hire Us</a>
                        </div>
                    </div>
                </div>
                
                <section class="portfolio-section modern-section">
                    <div class="container">
                        <div class="section-header">
                            <h2 class="section-title">Featured Projects</h2>
                            <p class="section-description">Handpicked selection of our most impactful and innovative work</p>
                        </div>
                        <div class="portfolio-grid modern-grid">
                            <div class="portfolio-card modern-card">
                                <div class="portfolio-image">
                                    <div class="portfolio-overlay">
                                        <div class="portfolio-actions">
                                            <a href="#" class="portfolio-link"><i class="fas fa-external-link-alt"></i></a>
                                            <a href="#" class="portfolio-zoom"><i class="fas fa-search-plus"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="portfolio-content">
                                    <div class="portfolio-category">Web Design</div>
                                    <h3 class="portfolio-title">E-Commerce Platform</h3>
                                    <p class="portfolio-description">Modern e-commerce solution with seamless user experience</p>
                                </div>
                            </div>
                            <div class="portfolio-card modern-card">
                                <div class="portfolio-image">
                                    <div class="portfolio-overlay">
                                        <div class="portfolio-actions">
                                            <a href="#" class="portfolio-link"><i class="fas fa-external-link-alt"></i></a>
                                            <a href="#" class="portfolio-zoom"><i class="fas fa-search-plus"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="portfolio-content">
                                    <div class="portfolio-category">Mobile App</div>
                                    <h3 class="portfolio-title">Fitness Tracker</h3>
                                    <p class="portfolio-description">Revolutionary fitness app with AI-powered insights</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>';
                break;
                
            default:
                $content = '
                <div class="hero-section modern-hero">
                    <div class="hero-content">
                        <h1 class="hero-title">Welcome to <span class="gradient-text">FlexiPro Theme</span></h1>
                        <p class="hero-description">The most flexible and powerful WordPress theme for modern websites</p>
                        <a href="#" class="btn btn-primary btn-modern">Get Started</a>
                    </div>
                </div>';
        }
        
        return $content;
    }
    
    private function get_demo_builder_data($demo_type) {
        // Return structured builder data for the demo
        return array(
            'elements' => array(
                array(
                    'id' => 'hero_' . time(),
                    'type' => 'heading',
                    'data' => array(
                        'content' => $this->get_demo_heading($demo_type),
                        'settings' => array(
                            'level' => '1',
                            'color' => '#ffffff',
                            'bg_color' => '#667eea',
                            'padding' => '60px 20px',
                            'text_align' => 'center'
                        )
                    )
                ),
                array(
                    'id' => 'content_' . time(),
                    'type' => 'text',
                    'data' => array(
                        'content' => $this->get_demo_description($demo_type),
                        'settings' => array(
                            'color' => '#ffffff',
                            'text_align' => 'center',
                            'font_size' => '20px'
                        )
                    )
                )
            ),
            'sections' => array(),
            'templates' => array()
        );
    }
    
    private function get_demo_heading($demo_type) {
        $headings = array(
            'corporate' => 'Welcome to Our Company',
            'creative' => 'Creative Agency',
            'ecommerce' => 'Shop Online',
            'portfolio' => 'John Doe',
            'restaurant' => 'Bella Vista Restaurant',
            'medical' => 'MedCare Clinic',
            'education' => 'EduLearn Academy',
            'realestate' => 'Prime Properties'
        );
        
        return isset($headings[$demo_type]) ? $headings[$demo_type] : 'Demo Page';
    }
    
    private function get_demo_description($demo_type) {
        $descriptions = array(
            'corporate' => 'Professional solutions for your business needs',
            'creative' => 'Bold. Creative. Innovative.',
            'ecommerce' => 'Discover amazing products at great prices',
            'portfolio' => 'Creative Designer & Developer',
            'restaurant' => 'Authentic Italian cuisine in the heart of the city',
            'medical' => 'Your health is our priority',
            'education' => 'Empowering minds, shaping futures',
            'realestate' => 'Find your dream home today'
        );
        
        return isset($descriptions[$demo_type]) ? $descriptions[$demo_type] : 'This is a demo page created with the Visual Builder.';
    }
}

// Initialize demo import
new FlexiPro_Demo_Import();
