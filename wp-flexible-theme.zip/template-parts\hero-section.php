<?php
/**
 * Hero Section Template Part
 * 
 * @package FlexiPro
 * @version 1.0.0
 */

$hero_title = get_theme_mod('flexipro_hero_title', 'Welcome to FlexiPro');
$hero_subtitle = get_theme_mod('flexipro_hero_subtitle', 'A powerful and flexible WordPress theme for modern websites');
$hero_button_text = get_theme_mod('flexipro_hero_button_text', 'Get Started');
$hero_button_url = get_theme_mod('flexipro_hero_button_url', '#');
$hero_background = get_theme_mod('flexipro_hero_background', '');
?>

<section class="hero-section" <?php if ($hero_background) : ?>style="background-image: url('<?php echo esc_url($hero_background); ?>');"<?php endif; ?>>
    <div class="hero-overlay"></div>
    <div class="container">
        <div class="hero-content">
            <h1 class="hero-title"><?php echo esc_html($hero_title); ?></h1>
            <p class="hero-subtitle"><?php echo esc_html($hero_subtitle); ?></p>
            <div class="hero-buttons">
                <a href="<?php echo esc_url($hero_button_url); ?>" class="btn btn-primary btn-large">
                    <?php echo esc_html($hero_button_text); ?>
                </a>
                <a href="#about" class="btn btn-outline btn-large">Learn More</a>
            </div>
        </div>
    </div>
</section>

<style>
.hero-section {
    position: relative;
    min-height: 100vh;
    display: flex;
    align-items: center;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    text-align: center;
    overflow: hidden;
}

.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.4);
    z-index: 1;
}

.hero-content {
    position: relative;
    z-index: 2;
    max-width: 800px;
    margin: 0 auto;
}

.hero-title {
    font-size: 3.5rem;
    font-weight: 700;
    margin-bottom: 1.5rem;
    line-height: 1.1;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
}

.hero-subtitle {
    font-size: 1.25rem;
    margin-bottom: 2.5rem;
    opacity: 0.9;
    line-height: 1.6;
}

.hero-buttons {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
}

.hero-buttons .btn {
    padding: 15px 30px;
    font-size: 16px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    border-radius: 50px;
    transition: all 0.3s ease;
}

.hero-buttons .btn-primary {
    background: #fff;
    color: #333;
    border: 2px solid #fff;
}

.hero-buttons .btn-primary:hover {
    background: transparent;
    color: #fff;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}

.hero-buttons .btn-outline {
    background: transparent;
    color: #fff;
    border: 2px solid #fff;
}

.hero-buttons .btn-outline:hover {
    background: #fff;
    color: #333;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}

@media (max-width: 768px) {
    .hero-title {
        font-size: 2.5rem;
    }
    
    .hero-subtitle {
        font-size: 1.1rem;
    }
    
    .hero-buttons {
        flex-direction: column;
        align-items: center;
    }
    
    .hero-buttons .btn {
        width: 100%;
        max-width: 300px;
    }
}

@media (max-width: 480px) {
    .hero-title {
        font-size: 2rem;
    }
    
    .hero-subtitle {
        font-size: 1rem;
    }
}
</style>
