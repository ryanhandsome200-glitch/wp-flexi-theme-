<?php
/**
 * The template for displaying the footer
 *
 * @package FlexiPro
 * @version 1.0.0
 */
?>

    </div><!-- #content -->

    <footer id="colophon" class="site-footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-widget">
                    <h3><?php _e('About Us', 'flexipro'); ?></h3>
                    <p><?php _e('FlexiPro is a powerful multipurpose WordPress theme designed to help you create stunning websites with ease.', 'flexipro'); ?></p>
                    <?php
                    $options = get_option('flexipro_options', array());
                    if (!empty($options['social_facebook']) || !empty($options['social_twitter']) || !empty($options['social_instagram']) || !empty($options['social_linkedin'])) {
                        echo '<div class="social-links">';
                        if (!empty($options['social_facebook'])) {
                            echo '<a href="' . esc_url($options['social_facebook']) . '" target="_blank"><i class="fab fa-facebook"></i></a>';
                        }
                        if (!empty($options['social_twitter'])) {
                            echo '<a href="' . esc_url($options['social_twitter']) . '" target="_blank"><i class="fab fa-twitter"></i></a>';
                        }
                        if (!empty($options['social_instagram'])) {
                            echo '<a href="' . esc_url($options['social_instagram']) . '" target="_blank"><i class="fab fa-instagram"></i></a>';
                        }
                        if (!empty($options['social_linkedin'])) {
                            echo '<a href="' . esc_url($options['social_linkedin']) . '" target="_blank"><i class="fab fa-linkedin"></i></a>';
                        }
                        echo '</div>';
                    }
                    ?>
                </div>

                <div class="footer-widget">
                    <h3><?php _e('Quick Links', 'flexipro'); ?></h3>
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'footer',
                        'menu_class'     => 'footer-menu',
                        'container'      => false,
                        'fallback_cb'    => false,
                    ));
                    ?>
                </div>

                <div class="footer-widget">
                    <h3><?php _e('Recent Posts', 'flexipro'); ?></h3>
                    <?php
                    $recent_posts = wp_get_recent_posts(array(
                        'numberposts' => 3,
                        'post_status' => 'publish'
                    ));
                    if ($recent_posts) {
                        echo '<ul class="recent-posts">';
                        foreach ($recent_posts as $post) {
                            echo '<li><a href="' . get_permalink($post['ID']) . '">' . $post['post_title'] . '</a></li>';
                        }
                        echo '</ul>';
                    }
                    ?>
                </div>

                <div class="footer-widget">
                    <h3><?php _e('Contact Info', 'flexipro'); ?></h3>
                    <div class="contact-info">
                        <p><i class="fas fa-envelope"></i> info@example.com</p>
                        <p><i class="fas fa-phone"></i> +1 (555) 123-4567</p>
                        <p><i class="fas fa-map-marker-alt"></i> 123 Main Street, City, State 12345</p>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <div class="footer-bottom-content">
                    <div class="copyright">
                        <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. <?php _e('All rights reserved.', 'flexipro'); ?></p>
                    </div>
                    <div class="footer-links">
                        <a href="<?php echo esc_url(get_privacy_policy_url()); ?>"><?php _e('Privacy Policy', 'flexipro'); ?></a>
                        <a href="#"><?php _e('Terms of Service', 'flexipro'); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
